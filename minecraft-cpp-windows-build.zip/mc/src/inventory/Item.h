#pragma once
// Item registry, stacks, tool/food/armor properties, block drops.
#include "../world/Block.h"
#include "../core/Random.h"
#include <string>
#include <vector>
#include <unordered_map>

namespace mc {

using ItemId = uint16_t;
constexpr ItemId ITEM_NONE = 0;
constexpr ItemId ITEM_FIRST_NONBLOCK = 1000;

struct ItemInfo {
    ItemId id = 0; std::string name; int maxStack = 64; int maxDamage = 0;
    BlockId block = 0;                    // placeable block (0 = none)
    ToolType tool = ToolType::None; int tier = 0; float speed = 1.0f; float attack = 1.0f;
    int armorSlot = -1;                   // 0 boots, 1 leggings, 2 chestplate, 3 helmet
    int armorPoints = 0;
    int food = 0; float saturation = 0;
    int fuel = 0;                         // burn ticks in a furnace
    int texture = 0;                      // index into the shared texture array
    BlockId fluidBucket = 0;              // water_bucket / lava_bucket
};

struct ItemStack {
    ItemId id = 0; int count = 0; int damage = 0;
    ItemStack() = default;
    ItemStack(ItemId i, int c = 1, int d = 0) : id(i), count(c), damage(d) {}
    bool empty() const { return id == 0 || count <= 0; }
    void clear() { id = 0; count = 0; damage = 0; }
    bool sameKind(const ItemStack& o) const { return id == o.id && damage == o.damage; }
};

class Items {
public:
    static void init();
    static const ItemInfo& get(ItemId id) { static ItemInfo none; auto it = byId_.find(id); return it == byId_.end() ? none : table_[it->second]; }
    static ItemId byName(const std::string& n);
    static ItemId ofBlock(BlockId b) { return (ItemId)b; }
    static const std::vector<ItemInfo>& all() { return table_; }
    static bool isTag(const std::string& tag, ItemId id);
    static void tagMembers(const std::string& tag, std::vector<ItemId>& out);

    // Mining
    static bool canHarvest(const BlockInfo& b, const ItemStack& tool);
    static float breakDelta(const BlockInfo& b, const ItemStack& tool, bool onGround, bool underwater); // progress per tick, >=1 means instant
    static void rollDrops(const BlockInfo& b, const ItemStack& tool, Rng& rng, std::vector<ItemStack>& out);
private:
    static std::vector<ItemInfo> table_;
    static std::unordered_map<ItemId, size_t> byId_;
};

} // namespace mc
