#include "SaveSystem.h"
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>

namespace fs = std::filesystem;
namespace mc {

SaveSystem::SaveSystem(const std::string& d) : dir_(d) { std::error_code ec; fs::create_directories(fs::path(d) / "region", ec); }
std::string SaveSystem::regionPath(int rx, int rz) const { return (fs::path(dir_) / "region" / ("r." + std::to_string(rx) + "." + std::to_string(rz) + ".mcr")).string(); }

static void putU16(std::vector<uint8_t>& v, uint16_t x) { v.push_back(x & 255); v.push_back(x >> 8); }

// section: flag, then RLE (state u16, run u16) pairs covering 4096 cells
static void encodeChunk(const Chunk& c, std::vector<uint8_t>& out) {
    for (int si = 0; si < SECTION_COUNT; ++si) {
        const BlockState* d = c.sectionData(si);
        if (!d || c.sectionEmpty(si)) { out.push_back(0); continue; }
        out.push_back(1);
        size_t countPos = out.size(); putU16(out, 0); uint16_t runs = 0;
        int i = 0;
        while (i < 4096) { int j = i + 1; while (j < 4096 && d[j] == d[i] && j - i < 65535) ++j; putU16(out, d[i]); putU16(out, (uint16_t)(j - i)); ++runs; i = j; }
        out[countPos] = runs & 255; out[countPos + 1] = runs >> 8;
    }
}
static bool decodeChunk(const std::vector<uint8_t>& in, Chunk& c) {
    size_t p = 0;
    for (int si = 0; si < SECTION_COUNT; ++si) {
        if (p >= in.size()) return false;
        if (!in[p++]) { for (int i = 0; i < 4096; ++i) c.set(i & 15, WORLD_MIN_Y + si * 16 + (i >> 8), (i >> 4) & 15, 0); continue; }
        if (p + 2 > in.size()) return false;
        int runs = in[p] | (in[p + 1] << 8); p += 2; int cell = 0;
        for (int r = 0; r < runs; ++r) {
            if (p + 4 > in.size()) return false;
            BlockState s = (BlockState)(in[p] | (in[p + 1] << 8)); int n = in[p + 2] | (in[p + 3] << 8); p += 4;
            for (int k = 0; k < n && cell < 4096; ++k, ++cell) c.set(cell & 15, WORLD_MIN_Y + si * 16 + (cell >> 8), (cell >> 4) & 15, s);
        }
    }
    return true;
}

bool SaveSystem::loadChunk(int cx, int cz, Chunk& out) {
    std::lock_guard<std::mutex> l(m_);
    int rx = cx >> 5, rz = cz >> 5, idx = (cz & 31) * 32 + (cx & 31);
    std::ifstream f(regionPath(rx, rz), std::ios::binary); if (!f) return false;
    uint32_t hdr[2]; f.seekg((std::streamoff)idx * 8); f.read((char*)hdr, 8);
    if (!f || hdr[1] == 0) return false;
    std::vector<uint8_t> buf(hdr[1]); f.seekg(hdr[0]); f.read((char*)buf.data(), hdr[1]);
    if (!f) return false;
    return decodeChunk(buf, out);
}

void SaveSystem::saveChunk(const Chunk& c) {
    std::vector<uint8_t> buf; encodeChunk(c, buf);
    std::lock_guard<std::mutex> l(m_);
    int rx = c.cx >> 5, rz = c.cz >> 5, idx = (c.cz & 31) * 32 + (c.cx & 31);
    std::string path = regionPath(rx, rz);
    if (!fs::exists(path)) { std::ofstream n(path, std::ios::binary); std::vector<char> z(8192, 0); n.write(z.data(), z.size()); }
    std::fstream f(path, std::ios::in | std::ios::out | std::ios::binary);
    f.seekg(0, std::ios::end); uint32_t off = (uint32_t)f.tellg();
    f.seekp(off); f.write((const char*)buf.data(), (std::streamsize)buf.size());
    uint32_t hdr[2] = {off, (uint32_t)buf.size()}; f.seekp((std::streamoff)idx * 8); f.write((const char*)hdr, 8);
}

template <class T> static void wr(std::ofstream& f, const T& v) { f.write((const char*)&v, sizeof(T)); }
template <class T> static bool rd(std::ifstream& f, T& v) { f.read((char*)&v, sizeof(T)); return (bool)f; }

bool SaveSystem::saveLevel(const LevelData& ld, const Player* p) {
    std::lock_guard<std::mutex> l(m_);
    std::ofstream f((fs::path(dir_) / "level.dat").string(), std::ios::binary); if (!f) return false;
    f.write("MCL1", 4); wr(f, (uint32_t)ld.version); wr(f, ld.seed); wr(f, ld.gameTime); wr(f, ld.dayTime); wr(f, (uint8_t)ld.mode);
    uint32_t n = (uint32_t)ld.name.size(); wr(f, n); f.write(ld.name.data(), n);
    uint8_t hasP = p ? 1 : 0; wr(f, hasP);
    if (p) {
        wr(f, p->pos.x); wr(f, p->pos.y); wr(f, p->pos.z); wr(f, p->yaw); wr(f, p->pitch); wr(f, p->health); wr(f, p->food); wr(f, p->saturation);
        wr(f, (int32_t)p->xpLevel); wr(f, p->xpProgress); wr(f, (int32_t)p->xpTotal); wr(f, (int32_t)p->inv.selected); wr(f, (uint8_t)p->flying);
        wr(f, (int32_t)p->spawn.x); wr(f, (int32_t)p->spawn.y); wr(f, (int32_t)p->spawn.z);
        for (const ItemStack& s : p->inv.slots) { wr(f, s.id); wr(f, (int16_t)s.count); wr(f, (int16_t)s.damage); }
    }
    return (bool)f;
}

bool SaveSystem::loadLevel(LevelData& ld, Player* p) {
    std::lock_guard<std::mutex> l(m_);
    std::ifstream f((fs::path(dir_) / "level.dat").string(), std::ios::binary); if (!f) return false;
    char magic[4]; f.read(magic, 4); if (!f || std::memcmp(magic, "MCL1", 4)) return false;
    uint32_t ver; uint8_t mode; uint32_t n;
    if (!rd(f, ver) || !rd(f, ld.seed) || !rd(f, ld.gameTime) || !rd(f, ld.dayTime) || !rd(f, mode) || !rd(f, n)) return false;
    ld.mode = (GameMode)mode; ld.name.resize(n); f.read(&ld.name[0], n);
    uint8_t hasP = 0; rd(f, hasP); ld.hasPlayer = hasP;
    if (hasP && p) {
        int32_t xl, xt, sel; uint8_t fly; int32_t sx, sy, sz;
        rd(f, p->pos.x); rd(f, p->pos.y); rd(f, p->pos.z); rd(f, p->yaw); rd(f, p->pitch); rd(f, p->health); rd(f, p->food); rd(f, p->saturation);
        rd(f, xl); rd(f, p->xpProgress); rd(f, xt); rd(f, sel); rd(f, fly); rd(f, sx); rd(f, sy); rd(f, sz);
        p->xpLevel = xl; p->xpTotal = xt; p->inv.selected = sel; p->flying = fly; p->spawn = BlockPos(sx, sy, sz); p->prevPos = p->pos; p->mode = ld.mode;
        for (ItemStack& s : p->inv.slots) { int16_t c, d; rd(f, s.id); rd(f, c); rd(f, d); s.count = c; s.damage = d; }
    }
    return true;
}

bool SaveSystem::readLevelHeader(const std::string& worldDir, LevelData& out) {
    SaveSystem s(worldDir); return s.loadLevel(out, nullptr);
}

std::vector<std::string> SaveSystem::listWorlds(const std::string& savesDir) {
    std::vector<std::string> r; std::error_code ec;
    if (!fs::exists(savesDir, ec)) return r;
    for (auto& e : fs::directory_iterator(savesDir, ec)) if (e.is_directory() && fs::exists(e.path() / "level.dat")) r.push_back(e.path().filename().string());
    std::sort(r.begin(), r.end()); return r;
}

} // namespace mc
