#pragma once
// AABB collision against block shapes (vanilla-style axis sweep with step-up and sneak edge protection) + voxel raycast.
#include "../world/World.h"
#include <vector>

namespace mc {

struct AABB {
    double x0 = 0, y0 = 0, z0 = 0, x1 = 0, y1 = 0, z1 = 0;
    AABB() = default;
    AABB(double ax, double ay, double az, double bx, double by, double bz) : x0(ax), y0(ay), z0(az), x1(bx), y1(by), z1(bz) {}
    AABB offset(double dx, double dy, double dz) const { return {x0 + dx, y0 + dy, z0 + dz, x1 + dx, y1 + dy, z1 + dz}; }
    AABB expand(double dx, double dy, double dz) const {
        return {dx < 0 ? x0 + dx : x0, dy < 0 ? y0 + dy : y0, dz < 0 ? z0 + dz : z0, dx > 0 ? x1 + dx : x1, dy > 0 ? y1 + dy : y1, dz > 0 ? z1 + dz : z1};
    }
    AABB inflate(double v) const { return {x0 - v, y0 - v, z0 - v, x1 + v, y1 + v, z1 + v}; }
    bool intersects(const AABB& o) const { return x1 > o.x0 && x0 < o.x1 && y1 > o.y0 && y0 < o.y1 && z1 > o.z0 && z0 < o.z1; }
};

void collectCollisions(const World& w, const AABB& region, std::vector<AABB>& out);
bool hasCollision(const World& w, const AABB& box);

struct MoveResult { Vec3d moved; bool hitX = false, hitY = false, hitZ = false, onGround = false; };
MoveResult moveEntity(const World& w, AABB& box, Vec3d d, double stepHeight, bool sneakEdge, bool wasOnGround);

struct RayHit { bool hit = false; BlockPos pos; int face = 0; Vec3d point; double dist = 0; };
RayHit raycastBlocks(const World& w, const Vec3d& origin, const Vec3d& dir, double maxDist, bool hitFluids = false);

} // namespace mc
