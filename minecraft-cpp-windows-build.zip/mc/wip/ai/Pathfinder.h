#pragma once
// A* pathfinding over the block grid for walking mobs: 1-block step-ups, drops of up to maxDrop blocks,
// clearance for the mob's body, optional water avoidance. Returns the closest reachable node when the goal is out of reach.
#include "../world/World.h"
#include <vector>

namespace mc {

struct PathRequest {
    BlockPos start, goal;
    int maxNodes = 700, maxRange = 40;
    int height = 2;              // body height in blocks (clearance)
    int maxDrop = 3;
    bool avoidWater = true, swimmer = false;
};
struct PathResult { std::vector<BlockPos> nodes; bool reached = false; int expanded = 0; };

bool pathStandable(const World& w, int x, int y, int z, int height, bool swimmer, bool avoidWater);
PathResult findPath(const World& w, const PathRequest& req);

} // namespace mc
