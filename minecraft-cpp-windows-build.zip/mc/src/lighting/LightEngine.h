#pragma once
// Sky + block light with incremental add/remove flood fill across chunk borders.
#include "../world/World.h"
#include <vector>

namespace mc {

class LightEngine {
public:
    explicit LightEngine(World& w) : world_(w) {}
    void initChunk(Chunk& c);                                               // full initial lighting (3x3 must be decorated)
    void onBlockChanged(const BlockPos& p, BlockState oldS, BlockState newS); // incremental update
private:
    struct Node { int x, y, z; uint8_t level; };
    int getSky(int x, int y, int z) const;
    int getBlk(int x, int y, int z) const;
    void setSky(int x, int y, int z, int v);
    void setBlk(int x, int y, int z, int v);
    void floodAdd(std::vector<Node>& q, bool sky);
    void floodRemove(std::vector<Node>& rq, std::vector<Node>& addQ, bool sky);
    void touch(int x, int z);
    World& world_;
};

} // namespace mc
