#pragma once
// GLFW window + input state (polled once per frame).
#include <string>
#include <vector>

struct GLFWwindow;

namespace mc {

namespace Key { constexpr int Space = 32, Escape = 256, Enter = 257, Backspace = 259, F3 = 292, F4 = 293, F11 = 300, LeftShift = 340, LeftCtrl = 341; }   // GLFW key codes

class Window {
public:
    bool create(int w, int h, const std::string& title);
    void destroy();
    bool shouldClose() const;
    void requestClose();
    void swap();
    void poll();                                   // pumps events, updates edge-triggered state
    void setCursorLocked(bool locked);
    bool cursorLocked() const { return locked_; }
    void setVsync(bool on);
    void toggleFullscreen();
    void* procAddress(const char* name) const;
    int width = 1280, height = 720;                // framebuffer size in pixels
    // keyboard / mouse
    bool key(int k) const { return k >= 0 && k < 512 && keys_[k]; }
    bool keyPressed(int k) const { return k >= 0 && k < 512 && pressed_[k]; }
    bool mouseDown(int b) const { return b >= 0 && b < 8 && mouse_[b]; }
    bool mousePressed(int b) const { return b >= 0 && b < 8 && mousePressed_[b]; }
    bool mouseReleased(int b) const { return b >= 0 && b < 8 && mouseReleased_[b]; }
    double mouseX = 0, mouseY = 0, dx = 0, dy = 0, scroll = 0;
    std::string typed;                             // UTF-8 text typed this frame
    std::vector<int> keyEvents;                    // key presses + repeats this frame
    int glMajor = 0, glMinor = 0;
private:
    static void onKey(GLFWwindow*, int, int, int, int);
    static void onMouse(GLFWwindow*, int, int, int);
    static void onCursor(GLFWwindow*, double, double);
    static void onScroll(GLFWwindow*, double, double);
    static void onChar(GLFWwindow*, unsigned);
    static void onResize(GLFWwindow*, int, int);
    GLFWwindow* win_ = nullptr; bool locked_ = false, fullscreen_ = false, first_ = true;
    bool keys_[512] = {}, pressed_[512] = {}, mouse_[8] = {}, mousePressed_[8] = {}, mouseReleased_[8] = {};
    double lastX_ = 0, lastY_ = 0, accDx_ = 0, accDy_ = 0, accScroll_ = 0; int wx_ = 0, wy_ = 0, ww_ = 0, wh_ = 0;
    std::string accTyped_; std::vector<int> accKeys_; bool accPressed_[512] = {}, accMouseP_[8] = {}, accMouseR_[8] = {};
};

} // namespace mc
