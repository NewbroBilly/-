// Declarations-only stand-in for GLFW 3.3 (sandbox syntax checking only; the real build fetches GLFW).
#pragma once
extern "C" {
typedef struct GLFWwindow GLFWwindow; typedef struct GLFWmonitor GLFWmonitor;
typedef struct GLFWvidmode { int width, height, redBits, greenBits, blueBits, refreshRate; } GLFWvidmode;
typedef void (*GLFWglproc)(void);
#define GLFW_TRUE 1
#define GLFW_FALSE 0
#define GLFW_PRESS 1
#define GLFW_RELEASE 0
#define GLFW_REPEAT 2
#define GLFW_CONTEXT_VERSION_MAJOR 0x00022002
#define GLFW_CONTEXT_VERSION_MINOR 0x00022003
#define GLFW_OPENGL_PROFILE 0x00022008
#define GLFW_OPENGL_CORE_PROFILE 0x00032001
#define GLFW_OPENGL_FORWARD_COMPAT 0x00022006
#define GLFW_CURSOR 0x00033001
#define GLFW_CURSOR_NORMAL 0x00034001
#define GLFW_CURSOR_DISABLED 0x00034003
#define GLFW_RAW_MOUSE_MOTION 0x00033005
#define GLFW_SAMPLES 0x0002100D
#define GLFW_KEY_SPACE 32
#define GLFW_KEY_ESCAPE 256
#define GLFW_KEY_ENTER 257
#define GLFW_KEY_TAB 258
#define GLFW_KEY_BACKSPACE 259
#define GLFW_KEY_DELETE 261
#define GLFW_KEY_RIGHT 262
#define GLFW_KEY_LEFT 263
#define GLFW_KEY_DOWN 264
#define GLFW_KEY_UP 265
#define GLFW_KEY_F1 290
#define GLFW_KEY_F2 291
#define GLFW_KEY_F3 292
#define GLFW_KEY_F11 300
#define GLFW_KEY_LEFT_SHIFT 340
#define GLFW_KEY_LEFT_CONTROL 341
#define GLFW_KEY_RIGHT_SHIFT 344
#define GLFW_MOUSE_BUTTON_LEFT 0
#define GLFW_MOUSE_BUTTON_RIGHT 1
#define GLFW_MOUSE_BUTTON_MIDDLE 2
int glfwInit(void); void glfwTerminate(void); void glfwWindowHint(int, int);
GLFWwindow* glfwCreateWindow(int, int, const char*, GLFWmonitor*, GLFWwindow*); void glfwDestroyWindow(GLFWwindow*);
void glfwMakeContextCurrent(GLFWwindow*); void glfwSwapInterval(int); void glfwSwapBuffers(GLFWwindow*); void glfwPollEvents(void);
int glfwWindowShouldClose(GLFWwindow*); void glfwSetWindowShouldClose(GLFWwindow*, int); void glfwGetFramebufferSize(GLFWwindow*, int*, int*); void glfwGetWindowSize(GLFWwindow*, int*, int*);
typedef void (*GLFWkeyfun)(GLFWwindow*, int, int, int, int); typedef void (*GLFWmousebuttonfun)(GLFWwindow*, int, int, int); typedef void (*GLFWcursorposfun)(GLFWwindow*, double, double);
typedef void (*GLFWscrollfun)(GLFWwindow*, double, double); typedef void (*GLFWcharfun)(GLFWwindow*, unsigned int); typedef void (*GLFWframebuffersizefun)(GLFWwindow*, int, int);
GLFWkeyfun glfwSetKeyCallback(GLFWwindow*, GLFWkeyfun); GLFWmousebuttonfun glfwSetMouseButtonCallback(GLFWwindow*, GLFWmousebuttonfun); GLFWcursorposfun glfwSetCursorPosCallback(GLFWwindow*, GLFWcursorposfun);
GLFWscrollfun glfwSetScrollCallback(GLFWwindow*, GLFWscrollfun); GLFWcharfun glfwSetCharCallback(GLFWwindow*, GLFWcharfun); GLFWframebuffersizefun glfwSetFramebufferSizeCallback(GLFWwindow*, GLFWframebuffersizefun);
void glfwSetInputMode(GLFWwindow*, int, int); int glfwRawMouseMotionSupported(void); GLFWglproc glfwGetProcAddress(const char*);
void glfwSetWindowUserPointer(GLFWwindow*, void*); void* glfwGetWindowUserPointer(GLFWwindow*); double glfwGetTime(void);
GLFWmonitor* glfwGetPrimaryMonitor(void); const GLFWvidmode* glfwGetVideoMode(GLFWmonitor*); void glfwSetWindowMonitor(GLFWwindow*, GLFWmonitor*, int, int, int, int, int);
void glfwGetCursorPos(GLFWwindow*, double*, double*); void glfwSetWindowTitle(GLFWwindow*, const char*);
}
