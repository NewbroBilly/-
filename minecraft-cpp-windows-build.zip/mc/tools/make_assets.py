#!/usr/bin/env python3
"""Builds assets/ for the game from a Minecraft-style resource pack.
Usage: make_assets.py <pack>/assets/minecraft/textures <out assets dir> <needed.txt> [--rgba]
 - textures found in the pack are copied (animated strips -> first frame)
 - missing textures are drawn procedurally (own artwork, so the game runs with any partial pack)
 - --rgba additionally writes raw sidecars used by the sandbox test renderer
"""
import os, sys, random, shutil, struct
from PIL import Image, ImageDraw, ImageFont

PACK, OUT, NEED = sys.argv[1], sys.argv[2], sys.argv[3]
RGBA = '--rgba' in sys.argv
S = 16
rnd = random.Random(1234)

def noise(base, var=14, a=255, seed=0):
    r = random.Random(seed); im = Image.new('RGBA', (S, S))
    for y in range(S):
        for x in range(S):
            d = r.randint(-var, var); im.putpixel((x, y), tuple(max(0, min(255, c + d)) for c in base) + (a,))
    return im

def stripes(base, dark, period=4, seed=0):
    im = noise(base, 8, seed=seed)
    for y in range(S):
        if (y // 2) % 2 == 0:
            for x in range(S):
                p = im.getpixel((x, y)); im.putpixel((x, y), tuple(int(c * 0.82) for c in p[:3]) + (255,))
    return im

def blob_ore(base_im, color, seed):
    im = base_im.copy(); r = random.Random(seed)
    for _ in range(5):
        cx, cy = r.randint(2, 13), r.randint(2, 13)
        for dx, dy in [(0, 0), (1, 0), (0, 1), (1, 1)]:
            if r.random() < 0.85: im.putpixel((cx + dx, cy + dy), color + (255,))
    return im

def transparent(): return Image.new('RGBA', (S, S), (0, 0, 0, 0))

COL = {'white_wool': (233, 236, 236), 'red_wool': (161, 39, 34), 'blue_wool': (53, 57, 157), 'green_wool': (84, 109, 27), 'yellow_wool': (248, 197, 39),
       'terracotta': (152, 94, 67), 'orange_terracotta': (161, 83, 37), 'yellow_terracotta': (186, 133, 35), 'brown_terracotta': (77, 51, 36),
       'red_terracotta': (143, 61, 46), 'white_terracotta': (209, 178, 161), 'light_gray_terracotta': (135, 107, 98)}

def gen(name):
    n = name.split('/', 1)[1]; kind = name.split('/', 1)[0]
    seed = sum(ord(c) for c in n)
    if kind == 'block':
        if n in COL: return noise(COL[n], 6 if 'wool' in n else 4, seed=seed)
        if n == 'dirt': return noise((134, 96, 67), 14, seed=seed)
        if n == 'grass_block_top': return noise((150, 150, 150), 18, seed=seed)
        if n == 'podzol_side':
            im = noise((134, 96, 67), 14, seed=seed)
            for x in range(S):
                for y in range(3 + (x * 7) % 3): im.putpixel((x, y), (92, 62, 30, 255))
            return im
        if n == 'water_still':
            im = Image.new('RGBA', (S, S)); r = random.Random(7)
            for y in range(S):
                for x in range(S):
                    v = 205 + int(18 * ((x * 3 + y * 5) % 7 == 0)) + r.randint(-6, 6); im.putpixel((x, y), (v - 20, v - 8, 255, 175))
            return im
        if n == 'lava_still':
            im = noise((230, 110, 20), 26, seed=3)
            for i in range(14): im.putpixel(((i * 5) % S, (i * 3 + 2) % S), (255, 215, 80, 255))
            return im
        if n == 'deepslate': return stripes((72, 72, 78), 0, seed=seed)
        if n == 'cobbled_deepslate': return noise((64, 64, 70), 22, seed=seed)
        if n == 'tuff': return noise((108, 110, 98), 16, seed=seed)
        if n == 'sea_lantern':
            im = noise((185, 215, 205), 10, seed=seed)
            for y in range(S):
                for x in range(S):
                    if x % 8 in (0, 7) or y % 8 in (0, 7): im.putpixel((x, y), (140, 180, 175, 255))
            return im
        if n == 'iron_block':
            im = noise((218, 218, 218), 5, seed=seed)
            for i in range(S):
                for p in [(i, 0), (i, S - 1), (0, i), (S - 1, i)]: im.putpixel(p, (190, 190, 190, 255))
            return im
        if n == 'deepslate_copper_ore': return blob_ore(stripes((72, 72, 78), 0, seed=5), (214, 128, 90), seed)
        if n.startswith('chest_'):
            im = noise((162, 114, 53), 8, seed=seed)
            for i in range(S):
                im.putpixel((i, 0), (110, 74, 30, 255)); im.putpixel((i, S - 1), (110, 74, 30, 255)); im.putpixel((0, i), (110, 74, 30, 255)); im.putpixel((S - 1, i), (110, 74, 30, 255))
            if n == 'chest_front':
                for y in range(5, 9):
                    for x in (7, 8): im.putpixel((x, y), (60, 60, 60, 255))
                im.putpixel((7, 8), (200, 200, 200, 255)); im.putpixel((8, 8), (200, 200, 200, 255))
            return im
        if n == 'torch':
            im = transparent()
            for y in range(6, 16):
                for x in (7, 8): im.putpixel((x, y), (126, 94, 44, 255))
            for y in range(3, 6):
                for x in (7, 8): im.putpixel((x, y), (255, 210 if y > 3 else 120, 60, 255))
            return im
        if n == 'sugar_cane':
            im = transparent(); r = random.Random(11)
            for x in (3, 8, 12):
                for y in range(S):
                    if (y + x) % 5 != 0: im.putpixel((x, y), (140 + r.randint(0, 40),) * 3 + (255,))
                    else: im.putpixel((x, y), (95, 95, 95, 255))
            return im
        if n.startswith('destroy_stage_'):
            k = int(n.split('_')[-1]); im = transparent(); d = ImageDraw.Draw(im); r = random.Random(99)
            for i in range(k + 1):
                x, y = r.randint(3, 12), r.randint(3, 12)
                for _ in range(2 + i):
                    nx, ny = x + r.randint(-2, 2), y + r.randint(-2, 2); d.line((x, y, nx, ny), fill=(0, 0, 0, 200)); x, y = nx, ny
            return im
    else:
        base = {'stick': (124, 92, 46), 'raw_iron': (200, 160, 130), 'raw_gold': (235, 200, 70), 'raw_copper': (200, 110, 80), 'leather': (150, 90, 40),
                'wheat_seeds': (90, 150, 50), 'arrow': (150, 150, 150), 'blaze_rod': (240, 160, 20), 'mutton': (170, 60, 60), 'bow': (130, 90, 40)}.get(n, (200, 0, 200))
        im = transparent(); r = random.Random(seed)
        if n in ('stick', 'blaze_rod', 'arrow'):
            for i in range(3, 14): im.putpixel((i, 16 - i), base + (255,)); im.putpixel((i, 15 - i), tuple(int(c * 0.8) for c in base) + (255,))
        elif n == 'bow':
            for i in range(2, 14): im.putpixel((3 + abs(8 - i) // 2 * -1 + 4, i), base + (255,)); im.putpixel((12, i), (220, 220, 220, 255))
        elif n == 'wheat_seeds':
            for _ in range(7): im.putpixel((r.randint(3, 12), r.randint(3, 12)), base + (255,))
        else:
            cx, cy = 8, 8
            for y in range(S):
                for x in range(S):
                    if (x - cx) ** 2 + (y - cy) ** 2 < 28 + r.randint(-6, 6): im.putpixel((x, y), tuple(max(0, min(255, c + r.randint(-18, 18))) for c in base) + (255,))
        return im
    return Image.new('RGBA', (S, S), (255, 0, 255, 255))

def load_pack(name):
    f = os.path.join(PACK, name + '.png')
    if not os.path.exists(f): return None
    im = Image.open(f).convert('RGBA')
    if im.height > im.width: im = im.crop((0, 0, im.width, im.width))      # animated strip -> first frame
    return im

os.makedirs(OUT, exist_ok=True)
names = [l.strip() for l in open(NEED) if l.strip()]
copied = gen_n = 0
dirt = None
for n in names:
    im = None
    if n == 'block/grass_block_side':
        d = load_pack('block/dirt') or gen('block/dirt'); ov = load_pack('block/grass_block_side_overlay')
        if ov is None: ov = Image.new('RGBA', (S, S), (255, 255, 255, 0))
        im = d.copy().resize(ov.size, Image.NEAREST)
        for y in range(ov.height):
            for x in range(ov.width):
                p = ov.getpixel((x, y))
                if p[3] > 0: l = int(sum(p[:3]) / 3); im.putpixel((x, y), (l, l, l, 255))
                else: c = im.getpixel((x, y)); im.putpixel((x, y), c[:3] + (0,))
        gen_n += 1
    else:
        im = load_pack(n)
        if im is None: im = gen(n); gen_n += 1
        else: copied += 1
    path = os.path.join(OUT, 'textures', n + '.png'); os.makedirs(os.path.dirname(path), exist_ok=True); im.save(path)
    if RGBA:
        with open(path + '.rgba', 'wb') as f: f.write(struct.pack('<ii', im.width, im.height)); f.write(im.tobytes())
print('textures: %d from the pack, %d generated' % (copied, gen_n))

# GUI sheets used by the HUD / menus (copied when present in the pack)
for g in ['gui/widgets', 'gui/container/inventory', 'gui/container/crafting_table', 'gui/container/furnace', 'gui/container/generic_54', 'gui/title/minecraft', 'gui/options_background']:
    f = os.path.join(PACK, g + '.png')
    if os.path.exists(f):
        dst = os.path.join(OUT, 'textures', g + '.png'); os.makedirs(os.path.dirname(dst), exist_ok=True); shutil.copy(f, dst)
        if RGBA:
            im = Image.open(f).convert('RGBA')
            with open(dst + '.rgba', 'wb') as ff: ff.write(struct.pack('<ii', im.width, im.height)); ff.write(im.tobytes())

# Bitmap font atlas: 16x16 cells of 8x12 px: ASCII 32..126, Cyrillic A..ya, Yo, yo, a few symbols
def glyph_list():
    g = [chr(c) for c in range(32, 127)] + [chr(c) for c in range(0x410, 0x450)] + ['Ё', 'ё', '•', '°', '×', '←', '→', '↑', '↓', '♥']
    return g
FONTS = ['/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf', '/usr/share/fonts/truetype/liberation/LiberationMono-Regular.ttf']
fpath = next((f for f in FONTS if os.path.exists(f)), None)
if fpath:
    font = ImageFont.truetype(fpath, 11); atlas = Image.new('RGBA', (128, 192), (0, 0, 0, 0))
    for i, ch in enumerate(glyph_list()):
        cell = Image.new('L', (8, 12), 0); d = ImageDraw.Draw(cell); d.fontmode = '1'; d.text((0, -1), ch, font=font, fill=255)
        cx, cy = (i % 16) * 8, (i // 16) * 12
        for y in range(12):
            for x in range(8):
                if cell.getpixel((x, y)) > 100: atlas.putpixel((cx + x, cy + y), (255, 255, 255, 255))
    os.makedirs(os.path.join(OUT, 'font'), exist_ok=True); atlas.save(os.path.join(OUT, 'font', 'font.png'))
    if RGBA:
        with open(os.path.join(OUT, 'font', 'font.png.rgba'), 'wb') as f: f.write(struct.pack('<ii', 128, 192)); f.write(atlas.tobytes())
    print('font atlas written from', os.path.basename(fpath))
else: print('WARNING: no TTF font found, font atlas not generated')
