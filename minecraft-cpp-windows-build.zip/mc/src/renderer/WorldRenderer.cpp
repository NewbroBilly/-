#include "WorldRenderer.h"
#include "../terrain/Biome.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <deque>

namespace mc {

static constexpr uint32_t MAX_QUADS = 1u << 17;

SkyState computeSky(double dayTicks, bool underwater) {
    double a = std::fmod(dayTicks, 24000.0) / 24000.0 * 6.283185307179586;
    SkyState s; s.sunDir = glm::normalize(glm::vec3((float)std::cos(a), (float)std::sin(a), 0.25f));
    float sy = s.sunDir.y;
    float day = (float)smoothstep(-0.12, 0.18, sy);
    glm::vec3 dayTop(0.40f, 0.62f, 1.0f), dayHor(0.72f, 0.84f, 1.0f), nightTop(0.005f, 0.008f, 0.03f), nightHor(0.02f, 0.025f, 0.07f);
    auto mix3 = [](glm::vec3 x, glm::vec3 y, float t) { return x * (1 - t) + y * t; };
    s.top = mix3(nightTop, dayTop, day); s.horizon = mix3(nightHor, dayHor, day);
    float dusk = (float)(1.0 - smoothstep(0.0, 0.32, std::fabs(sy))) * 0.9f;   // orange glow near sunrise/sunset
    s.horizon = mix3(s.horizon, glm::vec3(1.0f, 0.55f, 0.28f), dusk * (sy > -0.2f ? 1.0f : 0.0f));
    s.skyLevel = 0.30f + 0.70f * day; s.night = 1.0f - day;
    if (underwater) { s.horizon = glm::vec3(0.08f, 0.22f, 0.45f) * (0.35f + 0.65f * day); s.top = s.horizon; }
    return s;
}

static GLuint makeBuffer(GLenum target, GLsizeiptr size, const void* data, GLenum usage) { GLuint b; glGenBuffers(1, &b); glBindBuffer(target, b); glBufferData(target, size, data, usage); return b; }

bool WorldRenderer::init(const std::string& assetDir, ThreadPool* pool) {
    pool_ = pool; Blocks::init();
    for (int i = 0; i < 10; ++i) destroyLayer_[i] = Blocks::textureIndex("block/destroy_stage_" + std::to_string(i));
    std::vector<std::string> names = Blocks::textureNames();
    // item textures are registered lazily by Items::init(); callers must have initialised it before init()
    if (!tex_.build(assetDir, names)) return false;
    if (!terrain_.compile(SHADER_TERRAIN_VS, SHADER_TERRAIN_FS, "terrain") || !sky_.compile(SHADER_SKY_VS, SHADER_SKY_FS, "sky") || !line_.compile(SHADER_LINE_VS, SHADER_LINE_FS, "line")) return false;
    std::vector<uint32_t> idx((size_t)MAX_QUADS * 6);
    for (uint32_t q = 0; q < MAX_QUADS; ++q) { uint32_t b = q * 4, *i = &idx[q * 6]; i[0] = b; i[1] = b + 1; i[2] = b + 2; i[3] = b + 2; i[4] = b + 3; i[5] = b; }
    ibo_ = makeBuffer(GL_ELEMENT_ARRAY_BUFFER, (GLsizeiptr)(idx.size() * 4), idx.data(), GL_STATIC_DRAW);
    glGenVertexArrays(1, &dummyVao_);
    glGenVertexArrays(1, &dynVao_); glGenBuffers(1, &dynVbo_); setupVao(dynVao_, dynVbo_);
    glGenVertexArrays(1, &lineVao_); glGenBuffers(1, &lineVbo_);
    glBindVertexArray(lineVao_); glBindBuffer(GL_ARRAY_BUFFER, lineVbo_); glBufferData(GL_ARRAY_BUFFER, 24 * 3 * 4, nullptr, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 12, (const void*)0);
    glBindVertexArray(0);
    return true;
}

void WorldRenderer::setupVao(GLuint vao, GLuint vbo) {
    glBindVertexArray(vao); glBindBuffer(GL_ARRAY_BUFFER, vbo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo_);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 32, (const void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 32, (const void*)12);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, 32, (const void*)20);
    glEnableVertexAttribArray(3); glVertexAttribPointer(3, 4, GL_UNSIGNED_BYTE, GL_TRUE, 32, (const void*)24);
    glEnableVertexAttribArray(4); glVertexAttribPointer(4, 1, GL_UNSIGNED_SHORT, GL_FALSE, 32, (const void*)28);
}

void WorldRenderer::freeGpu(ChunkGpu& g) {
    for (int p = 0; p < PASS_COUNT; ++p) { if (g.vao[p]) glDeleteVertexArrays(1, &g.vao[p]); if (g.vbo[p]) glDeleteBuffers(1, &g.vbo[p]); }
}

void WorldRenderer::shutdown() {
    for (auto& kv : gpu_) freeGpu(*kv.second); gpu_.clear();
    tex_.destroy(); terrain_.destroy(); sky_.destroy(); line_.destroy();
}

void WorldRenderer::onChunkUnloaded(int cx, int cz) {
    ChunkPos p(cx, cz); auto it = gpu_.find(p); if (it != gpu_.end()) { freeGpu(*it->second); gpu_.erase(it); }
    meshedVersion_.erase(p);
}

void WorldRenderer::update(World& w, const Vec3d& cam) {
    // 1. upload finished meshes (limited per frame)
    std::vector<std::unique_ptr<MeshOutput>> ready; { std::lock_guard<std::mutex> l(m_); ready.swap(done_); }
    for (auto& m : ready) { inflight_.erase(ChunkPos(m->cx, m->cz)); if (w.chunk(m->cx, m->cz)) upload(std::move(m)); }
    // 2. schedule new snapshots, nearest first
    if ((int)inflight_.size() >= maxJobs) { stats.meshesPending = (int)inflight_.size(); return; }
    std::vector<std::pair<double, Chunk*>> cand;
    for (auto& kv : w.chunks()) {
        Chunk* c = kv.second.get();
        if (c->status.load() != ChunkStatus::Lit || !c->meshDirty || inflight_.count(kv.first)) continue;
        bool ok = true;
        for (int dz = -1; dz <= 1 && ok; ++dz) for (int dx = -1; dx <= 1; ++dx) { Chunk* n = w.chunk(c->cx + dx, c->cz + dz); if (!n || n->status.load() != ChunkStatus::Lit) { ok = false; break; } }
        if (!ok) continue;
        double dx = c->cx * 16 + 8 - cam.x, dz = c->cz * 16 + 8 - cam.z; cand.push_back({dx * dx + dz * dz, c});
    }
    std::sort(cand.begin(), cand.end(), [](auto& a, auto& b) { return a.first < b.first; });
    int built = 0;
    for (auto& e : cand) {
        if ((int)inflight_.size() >= maxJobs || built >= 4) break;
        Chunk* c = e.second; c->meshDirty = false; ++c->meshVersion;
        std::shared_ptr<MeshInput> in = buildMeshInput(w, *c); uint32_t ver = c->meshVersion;
        inflight_.insert(ChunkPos(c->cx, c->cz)); ++built;
        pool_->submit([this, in, ver] { auto out = std::make_unique<MeshOutput>(); out->version = ver; meshChunk(*in, *out); std::lock_guard<std::mutex> l(m_); done_.push_back(std::move(out)); });
    }
    stats.meshesPending = (int)inflight_.size();
}

void WorldRenderer::upload(std::unique_ptr<MeshOutput> m) {
    ChunkPos p(m->cx, m->cz);
    auto& slot = gpu_[p]; if (!slot) slot = std::make_unique<ChunkGpu>();
    ChunkGpu& g = *slot; g.cx = m->cx; g.cz = m->cz;
    for (int s = 0; s < SECTION_COUNT; ++s) g.vis[s] = m->secVis[s];
    for (int pass = 0; pass < PASS_COUNT; ++pass) {
        auto& v = m->verts[pass]; size_t quads = std::min<size_t>(v.size() / 4, MAX_QUADS);
        for (int s = 0; s <= SECTION_COUNT; ++s) g.first[pass][s] = std::min<uint32_t>(m->secFirstQuad[pass][s], (uint32_t)quads);
        g.has[pass] = quads > 0;
        if (!quads) continue;
        if (!g.vao[pass]) { glGenVertexArrays(1, &g.vao[pass]); glGenBuffers(1, &g.vbo[pass]); setupVao(g.vao[pass], g.vbo[pass]); }
        glBindBuffer(GL_ARRAY_BUFFER, g.vbo[pass]); glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(quads * 4 * sizeof(Vertex)), v.data(), GL_STATIC_DRAW);
    }
    ++stats.chunksMeshed;
}

// ------------------------------------------------------------------ culling
void WorldRenderer::collectVisible(const FrameParams& fp, std::vector<Draw>& out) {
    glm::mat4 m = vp_;
    for (int i = 0; i < 6; ++i) {
        int row = i / 2; float sgn = (i & 1) ? -1.f : 1.f;
        for (int k = 0; k < 4; ++k) frustum_[i][k] = m[k][3] + sgn * m[k][row];
        float l = std::sqrt(frustum_[i][0] * frustum_[i][0] + frustum_[i][1] * frustum_[i][1] + frustum_[i][2] * frustum_[i][2]);
        for (int k = 0; k < 4; ++k) frustum_[i][k] /= l;
    }
    auto inFrustum = [&](double x0, double y0, double z0, double x1, double y1, double z1) {
        for (int i = 0; i < 6; ++i) {
            const float* f = frustum_[i];
            float px = f[0] >= 0 ? (float)x1 : (float)x0, py = f[1] >= 0 ? (float)y1 : (float)y0, pz = f[2] >= 0 ? (float)z1 : (float)z0;
            if (f[0] * px + f[1] * py + f[2] * pz + f[3] < 0) return false;
        }
        return true;
    };
    auto secBox = [&](int cx, int sy, int cz, double b[6]) {
        b[0] = cx * 16 - fp.cam.x; b[1] = WORLD_MIN_Y + sy * 16 - fp.cam.y; b[2] = cz * 16 - fp.cam.z; b[3] = b[0] + 16; b[4] = b[1] + 16; b[5] = b[2] + 16;
    };
    std::unordered_map<ChunkGpu*, uint32_t> masks;
    int ccx = floorInt(fp.cam.x) >> 4, ccz = floorInt(fp.cam.z) >> 4;
    int csy = clampv((floorInt(fp.cam.y) - WORLD_MIN_Y) >> 4, 0, SECTION_COUNT - 1);
    auto startIt = gpu_.find(ChunkPos(ccx, ccz));
    int total = 0;
    if (fp.occlusion && startIt != gpu_.end()) {
        struct Node { int cx, sy, cz; int from; int dirs; };
        std::deque<Node> q; std::unordered_set<uint64_t> seen;
        auto key = [](int cx, int sy, int cz) { return ((uint64_t)(uint32_t)(cx + 100000) << 32) | ((uint64_t)(uint32_t)(cz + 100000) << 8) | (uint64_t)sy; };
        q.push_back({ccx, csy, ccz, -1, 0}); seen.insert(key(ccx, csy, ccz));
        while (!q.empty()) {
            Node n = q.front(); q.pop_front();
            ChunkGpu* g = gpu_[ChunkPos(n.cx, n.cz)].get(); masks[g] |= 1u << n.sy; ++total;
            uint16_t vis = g->vis[n.sy];
            for (int f = 0; f < 6; ++f) {
                if (n.from >= 0 && !((vis >> visPairBit(n.from, f)) & 1)) continue;
                if (n.dirs & (1 << DIR_OPP[f])) continue;
                int nx = n.cx + DIR_DX[f], ny = n.sy + DIR_DY[f], nz = n.cz + DIR_DZ[f];
                if (ny < 0 || ny >= SECTION_COUNT) continue;
                if (!gpu_.count(ChunkPos(nx, nz))) continue;
                if (!seen.insert(key(nx, ny, nz)).second) continue;
                double b[6]; secBox(nx, ny, nz, b);
                if (!inFrustum(b[0], b[1], b[2], b[3], b[4], b[5])) continue;
                q.push_back({nx, ny, nz, DIR_OPP[f], n.dirs | (1 << f)});
            }
        }
    } else {
        for (auto& kv : gpu_) for (int s = kv.second->has[0] || kv.second->has[1] || kv.second->has[2] ? 0 : SECTION_COUNT; s < SECTION_COUNT; ++s) {
            double b[6]; secBox(kv.first.x, s, kv.first.z, b);
            if (inFrustum(b[0], b[1], b[2], b[3], b[4], b[5])) { masks[kv.second.get()] |= 1u << s; ++total; }
        }
    }
    int all = 0; for (auto& kv : gpu_) for (int s = 0; s < SECTION_COUNT; ++s) if (kv.second->first[0][s + 1] > kv.second->first[0][s] || kv.second->first[1][s + 1] > kv.second->first[1][s] || kv.second->first[2][s + 1] > kv.second->first[2][s]) ++all;
    stats.sectionsCulled = std::max(0, all - total);
    for (auto& kv : masks) { double dx = kv.first->cx * 16 + 8 - fp.cam.x, dz = kv.first->cz * 16 + 8 - fp.cam.z; out.push_back({kv.first, kv.second, dx * dx + dz * dz}); }
}

void WorldRenderer::drawPass(const std::vector<Draw>& list, int pass, const FrameParams& fp) {
    glUniform1i(terrain_.loc("uPass"), pass);
    for (const Draw& d : list) {
        ChunkGpu* g = d.g; if (!g->has[pass]) continue;
        glBindVertexArray(g->vao[pass]);
        glUniform3f(terrain_.loc("uOffset"), (float)(g->cx * 16 - fp.cam.x), (float)(WORLD_MIN_Y - fp.cam.y), (float)(g->cz * 16 - fp.cam.z));
        int s = 0;
        while (s < SECTION_COUNT) {
            if (!((d.mask >> s) & 1) || g->first[pass][s + 1] == g->first[pass][s]) { ++s; continue; }
            uint32_t first = g->first[pass][s], end = g->first[pass][s + 1]; int e = s + 1;
            while (e < SECTION_COUNT && ((d.mask >> e) & 1)) { end = g->first[pass][e + 1]; ++e; }
            glDrawElements(GL_TRIANGLES, (GLsizei)((end - first) * 6), GL_UNSIGNED_INT, (const void*)((size_t)first * 6 * 4));
            stats.quads += end - first; ++stats.sectionsDrawn; s = e;
        }
    }
}

void WorldRenderer::render(World&, const FrameParams& fp) {
    stats.chunksDrawn = 0; stats.sectionsDrawn = 0; stats.quads = 0;
    vp_ = fp.proj * fp.rotView;
    SkyState sky = computeSky(fp.dayTicks, fp.underwater);
    glViewport(0, 0, fp.width, fp.height);
    glClearColor(sky.horizon.x, sky.horizon.y, sky.horizon.z, 1.0f);
    glDepthMask(GL_TRUE); glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    // sky
    glDisable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND);
    sky_.use(); glm::mat4 inv = glm::inverse(vp_);
    glUniformMatrix4fv(sky_.loc("uInvViewProj"), 1, GL_FALSE, glm::value_ptr(inv));
    glUniform3f(sky_.loc("uSunDir"), sky.sunDir.x, sky.sunDir.y, sky.sunDir.z);
    glUniform3f(sky_.loc("uTop"), sky.top.x, sky.top.y, sky.top.z); glUniform3f(sky_.loc("uHorizon"), sky.horizon.x, sky.horizon.y, sky.horizon.z);
    glUniform1f(sky_.loc("uNight"), fp.underwater ? 0.0f : sky.night);
    glBindVertexArray(dummyVao_); glDrawArrays(GL_TRIANGLES, 0, 3);
    // terrain
    glEnable(GL_DEPTH_TEST); glDepthFunc(GL_LEQUAL); glFrontFace(GL_CCW); glCullFace(GL_BACK);
    terrain_.use(); tex_.bind(0); glUniform1i(terrain_.loc("uTex"), 0);
    glUniformMatrix4fv(terrain_.loc("uViewProj"), 1, GL_FALSE, glm::value_ptr(vp_));
    glUniform1f(terrain_.loc("uSkyLevel"), sky.skyLevel); glUniform1f(terrain_.loc("uTime"), fp.time);
    float fogEnd = fp.underwater ? 22.0f : fp.renderDistanceBlocks * 0.96f, fogStart = fp.underwater ? 0.0f : fp.renderDistanceBlocks * 0.62f;
    glUniform3f(terrain_.loc("uFogColor"), sky.horizon.x, sky.horizon.y, sky.horizon.z); glUniform1f(terrain_.loc("uFogStart"), fogStart); glUniform1f(terrain_.loc("uFogEnd"), fogEnd);
    std::vector<Draw> list; collectVisible(fp, list);
    stats.chunksDrawn = (int)list.size();
    std::sort(list.begin(), list.end(), [](const Draw& a, const Draw& b) { return a.d2 < b.d2; });
    glDisable(GL_BLEND); glEnable(GL_CULL_FACE);
    drawPass(list, PASS_OPAQUE, fp);
    glDisable(GL_CULL_FACE);
    drawPass(list, PASS_CUTOUT, fp);
    glEnable(GL_CULL_FACE); glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); glDepthMask(GL_FALSE);
    std::reverse(list.begin(), list.end());
    drawPass(list, PASS_TRANSLUCENT, fp);
    glDepthMask(GL_TRUE); glDisable(GL_BLEND); glBindVertexArray(0);
}

void WorldRenderer::drawSelection(const FrameParams& fp, const BlockPos& p, const float b[6]) {
    const float e = 0.003f;
    float x0 = b[0] - e, y0 = b[1] - e, z0 = b[2] - e, x1 = b[3] + e, y1 = b[4] + e, z1 = b[5] + e;
    float c[8][3] = {{x0, y0, z0}, {x1, y0, z0}, {x1, y0, z1}, {x0, y0, z1}, {x0, y1, z0}, {x1, y1, z0}, {x1, y1, z1}, {x0, y1, z1}};
    static const int E[12][2] = {{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
    float v[24][3]; for (int i = 0; i < 12; ++i) for (int k = 0; k < 2; ++k) for (int a = 0; a < 3; ++a) v[i * 2 + k][a] = c[E[i][k]][a];
    line_.use(); glm::mat4 m = fp.proj * fp.rotView;
    glUniformMatrix4fv(line_.loc("uViewProj"), 1, GL_FALSE, glm::value_ptr(m));
    glUniform3f(line_.loc("uOffset"), (float)(p.x - fp.cam.x), (float)(p.y - fp.cam.y), (float)(p.z - fp.cam.z)); glUniform4f(line_.loc("uColor"), 0, 0, 0, 0.65f);
    glBindVertexArray(lineVao_); glBindBuffer(GL_ARRAY_BUFFER, lineVbo_); glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(v), v);
    glEnable(GL_DEPTH_TEST); glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); glLineWidth(2.0f);
    glDrawArrays(GL_LINES, 0, 24); glDisable(GL_BLEND); glBindVertexArray(0);
}

void WorldRenderer::drawCrack(const FrameParams& fp, const BlockPos& p, int stage) {
    if (stage < 0 || stage > 9) return;
    std::vector<Vertex> v; const float e = 0.002f;
    for (int d = 0; d < 6; ++d) {
        static const float P[6][4][3] = {{{1, 0, 1}, {1, 0, 0}, {1, 1, 0}, {1, 1, 1}}, {{0, 0, 0}, {0, 0, 1}, {0, 1, 1}, {0, 1, 0}}, {{0, 1, 1}, {1, 1, 1}, {1, 1, 0}, {0, 1, 0}},
                                         {{0, 0, 0}, {1, 0, 0}, {1, 0, 1}, {0, 0, 1}}, {{0, 0, 1}, {1, 0, 1}, {1, 1, 1}, {0, 1, 1}}, {{1, 0, 0}, {0, 0, 0}, {0, 1, 0}, {1, 1, 0}}};
        static const float UV[4][2] = {{0, 1}, {1, 1}, {1, 0}, {0, 0}};
        for (int c = 0; c < 4; ++c) {
            Vertex x{}; x.x = P[d][c][0] + DIR_DX[d] * e; x.y = P[d][c][1] + DIR_DY[d] * e; x.z = P[d][c][2] + DIR_DZ[d] * e; x.u = UV[c][0]; x.v = UV[c][1];
            x.sky = 255; x.blk = 255; x.ao = 255; x.shade = 255; x.r = x.g = x.b = 255; x.a = 0; x.layer = (uint16_t)destroyLayer_[stage]; v.push_back(x);
        }
    }
    terrain_.use(); tex_.bind(0); glUniform1i(terrain_.loc("uTex"), 0);
    glm::mat4 m = fp.proj * fp.rotView; glUniformMatrix4fv(terrain_.loc("uViewProj"), 1, GL_FALSE, glm::value_ptr(m));
    glUniform3f(terrain_.loc("uOffset"), (float)(p.x - fp.cam.x), (float)(p.y - fp.cam.y), (float)(p.z - fp.cam.z));
    glUniform1f(terrain_.loc("uSkyLevel"), 1.0f); glUniform3f(terrain_.loc("uFogColor"), 0, 0, 0); glUniform1f(terrain_.loc("uFogStart"), 1e6f); glUniform1f(terrain_.loc("uFogEnd"), 2e6f); glUniform1i(terrain_.loc("uPass"), 2);
    glBindVertexArray(dynVao_); glBindBuffer(GL_ARRAY_BUFFER, dynVbo_); glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(v.size() * sizeof(Vertex)), v.data(), GL_STREAM_DRAW);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); glDepthMask(GL_FALSE); glEnable(GL_POLYGON_OFFSET_FILL); glPolygonOffset(-1.0f, -1.0f);
    glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, nullptr);
    glDisable(GL_POLYGON_OFFSET_FILL); glDepthMask(GL_TRUE); glDisable(GL_BLEND); glBindVertexArray(0);
}

} // namespace mc

namespace mc {
void WorldRenderer::clearChunks() { for (auto& kv : gpu_) freeGpu(*kv.second); gpu_.clear(); meshedVersion_.clear(); inflight_.clear(); stats.chunksMeshed = 0; }

void WorldRenderer::drawDynamic(const FrameParams& fp, const std::vector<Vertex>& v, double dayTicks) {
    if (v.empty()) return;
    size_t quads = std::min<size_t>(v.size() / 4, MAX_QUADS);
    SkyState sky = computeSky(dayTicks, false);
    terrain_.use(); tex_.bind(0); glUniform1i(terrain_.loc("uTex"), 0);
    glm::mat4 m = fp.proj * fp.rotView; glUniformMatrix4fv(terrain_.loc("uViewProj"), 1, GL_FALSE, glm::value_ptr(m));
    glUniform3f(terrain_.loc("uOffset"), 0, 0, 0); glUniform1f(terrain_.loc("uSkyLevel"), sky.skyLevel);
    glUniform3f(terrain_.loc("uFogColor"), sky.horizon.x, sky.horizon.y, sky.horizon.z); glUniform1f(terrain_.loc("uFogStart"), fp.renderDistanceBlocks * 0.62f); glUniform1f(terrain_.loc("uFogEnd"), fp.renderDistanceBlocks * 0.96f);
    glUniform1i(terrain_.loc("uPass"), 1);
    glBindVertexArray(dynVao_); glBindBuffer(GL_ARRAY_BUFFER, dynVbo_); glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(quads * 4 * sizeof(Vertex)), v.data(), GL_STREAM_DRAW);
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND);
    glDrawElements(GL_TRIANGLES, (GLsizei)(quads * 6), GL_UNSIGNED_INT, nullptr);
    glBindVertexArray(0);
}
}
