#pragma once
#include <cstdint>
#include <string>
#include <vector>
namespace mc {
// Loads a PNG (via stb_image) into RGBA8. In sandbox builds without stb a "<file>.rgba" sidecar (w,h as int32 + raw pixels) is used.
bool loadImageRGBA(const std::string& path, int& w, int& h, std::vector<uint8_t>& rgba);
}
