// Headless tests for the simulation core: determinism, decoration, light, fluids.
#include "../src/terrain/Decorator.h"
#include "../src/world/World.h"
#include "../src/lighting/LightEngine.h"
#include "../src/fluid/FluidSimulation.h"
#include <chrono>
#include <cstdio>
#include <memory>
#include <vector>
using namespace mc;

static int g_fail = 0, g_ok = 0;
#define CHECK(c, msg) do { if (c) { ++g_ok; } else { ++g_fail; printf("  FAIL: %s  (%s:%d)\n", msg, __FILE__, __LINE__); } } while (0)

static uint64_t hashChunk(const Chunk& c) {
    uint64_t h = 1469598103934665603ULL;
    for (int y = WORLD_MIN_Y; y < WORLD_MAX_Y; ++y) for (int z = 0; z < 16; ++z) for (int x = 0; x < 16; ++x) h = (h ^ c.get(x, y, z)) * 1099511628211ULL;
    return h;
}

// Build terrain+decoration for chunks in [-r, r]^2 in the given order, returns hash of the centre chunk.
static uint64_t buildHash(uint64_t seed, int r, bool reverse, World* out = nullptr) {
    TerrainGenerator tg(seed); Decorator dec(seed, tg);
    std::vector<std::shared_ptr<Chunk>> cs;
    for (int z = -r; z <= r; ++z) for (int x = -r; x <= r; ++x) { cs.push_back(std::make_shared<Chunk>(x, z)); }
    if (reverse) std::reverse(cs.begin(), cs.end());
    for (auto& c : cs) tg.generate(*c);
    auto at = [&](int x, int z) -> Chunk* { for (auto& c : cs) if (c->cx == x && c->cz == z) return c.get(); return nullptr; };
    // decorate the centre ring in a given order
    std::vector<Chunk*> ring; for (int z = -r + 1; z <= r - 1; ++z) for (int x = -r + 1; x <= r - 1; ++x) ring.push_back(at(x, z));
    if (reverse) std::reverse(ring.begin(), ring.end());
    // decoration writes only into the target, so we need a pristine copy of terrain for neighbours: they are read-only columns
    for (Chunk* c : ring) { Chunk* nb[9]; for (int dz = -1; dz <= 1; ++dz) for (int dx = -1; dx <= 1; ++dx) nb[(dz + 1) * 3 + dx + 1] = at(c->cx + dx, c->cz + dz); dec.decorate(*c, nb); }
    uint64_t h = hashChunk(*at(0, 0));
    if (out) for (auto& c : cs) out->addChunk(c);
    return h;
}

static void testDeterminism() {
    printf("[determinism]\n");
    uint64_t a = buildHash(777, 2, false), b = buildHash(777, 2, true), c = buildHash(778, 2, false);
    CHECK(a == b, "same seed -> identical chunk regardless of generation order");
    CHECK(a != c, "different seed -> different chunk");
}

static void testDecoration() {
    printf("[decoration]\n");
    long trees = 0, ores = 0, plants = 0; int chunks = 0;
    TerrainGenerator tg(4242); Decorator dec(4242, tg);
    const int R = 14; std::vector<std::shared_ptr<Chunk>> cs;
    // find a wooded land region
    int ox = 0, oz = 0; bool found = false;
    for (int k = 0; k < 400 && !found; ++k) {
        int tx = (k % 20 - 10) * 20, tz = (k / 20 - 10) * 20;
        Biome b = tg.column((tx + 7) * 16, (tz + 7) * 16).biome;
        if (b == Biome::Forest || b == Biome::Taiga || b == Biome::BirchForest || b == Biome::Jungle) { ox = tx; oz = tz; found = true; }
    }
    printf("  test region at chunk (%d,%d)\n", ox, oz);
    for (int z = 0; z < R; ++z) for (int x = 0; x < R; ++x) { cs.push_back(std::make_shared<Chunk>(ox + x, oz + z)); tg.generate(*cs.back()); }
    auto t0 = std::chrono::steady_clock::now();
    for (int z = 1; z < R - 1; ++z) for (int x = 1; x < R - 1; ++x) {
        Chunk* nb[9]; for (int dz = -1; dz <= 1; ++dz) for (int dx = -1; dx <= 1; ++dx) nb[(dz + 1) * 3 + dx + 1] = cs[(z + dz) * R + x + dx].get();
        dec.decorate(*cs[z * R + x], nb); ++chunks;
        Chunk& c = *cs[z * R + x];
        for (int y = -64; y < 200; ++y) for (int zz = 0; zz < 16; ++zz) for (int xx = 0; xx < 16; ++xx) {
            BlockId id = stateId(c.get(xx, y, zz));
            if (id == B::OAK_LOG || id == B::SPRUCE_LOG || id == B::BIRCH_LOG || id == B::JUNGLE_LOG || id == B::ACACIA_LOG) ++trees;
            else if (id == B::COAL_ORE || id == B::IRON_ORE || id == B::DIAMOND_ORE || id == B::DEEPSLATE_DIAMOND_ORE || id == B::GOLD_ORE) ++ores;
            else if (id == B::GRASS || id == B::DANDELION || id == B::POPPY || id == B::CACTUS) ++plants;
        }
    }
    double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    printf("  %d chunks decorated (%.1f ms/chunk incl. scan): logs=%ld ores=%ld plants=%ld\n", chunks, ms / chunks, trees, ores, plants);
    CHECK(trees > 100, "forests contain trees"); CHECK(ores > 200, "ores generated"); CHECK(plants > 100, "plants generated");
}

// Flat test world: stone up to y=0 (inclusive), air above, fully lit.
static std::unique_ptr<World> flatWorld(int r = 2) {
    Blocks::init();
    auto w = std::make_unique<World>(1);
    for (int cz = -r; cz <= r; ++cz) for (int cx = -r; cx <= r; ++cx) {
        auto c = std::make_shared<Chunk>(cx, cz);
        for (int z = 0; z < 16; ++z) for (int x = 0; x < 16; ++x) { for (int y = WORLD_MIN_Y; y <= 0; ++y) c->set(x, y, z, makeState(B::STONE)); c->terrainHeight[z * 16 + x] = 0; }
        c->status = ChunkStatus::Decorated; w->addChunk(c);
    }
    for (auto& kv : w->chunks()) { w->lighting().initChunk(*kv.second); kv.second->status = ChunkStatus::Lit; }
    return w;
}

static void testLight() {
    printf("[light]\n");
    auto w = flatWorld();
    CHECK(w->skyLight(3, 1, 3) == 15, "open sky is 15");
    CHECK(w->skyLight(3, 0, 3) == 0, "inside stone is dark");
    w->setBlock(5, 1, 5, makeState(B::TORCH));
    CHECK(w->blockLight(5, 1, 5) == 14, "torch emits 14");
    CHECK(w->blockLight(6, 1, 5) == 13 && w->blockLight(5, 1, 8) == 11, "torch light falls off by 1 per block");
    CHECK(w->blockLight(5, 1, 20) == 0, "torch light range is limited");
    // roof: 3x3 stone cap at y=5 around x=20..22 -> under it sky light < 15
    for (int x = 19; x <= 23; ++x) for (int z = 19; z <= 23; ++z) w->setBlock(x, 5, z, makeState(B::STONE));
    CHECK(w->skyLight(21, 1, 21) < 15 && w->skyLight(21, 1, 21) >= 11, "under a small roof light leaks in from the sides");
    CHECK(w->skyLight(21, 1, 21) == 13 || w->skyLight(21, 1, 21) == 12 || w->skyLight(21, 1, 21) == 11, "centre under 5x5 roof is dimmer");
    w->setBlock(21, 5, 21, 0);
    CHECK(w->skyLight(21, 1, 21) == 15, "hole in roof restores full sky light below");
    w->setBlock(21, 5, 21, makeState(B::STONE));
    CHECK(w->skyLight(21, 1, 21) < 15, "plugging the hole darkens again");
    // light crossing a chunk border (x=15|16)
    w->setBlock(15, 1, 8, makeState(B::TORCH));
    CHECK(w->blockLight(16, 1, 8) == 13 && w->blockLight(18, 1, 8) == 11, "light crosses chunk borders");
    w->setBlock(15, 1, 8, 0);
    CHECK(w->blockLight(16, 1, 8) == 0 && w->blockLight(15, 1, 8) <= 1, "removing a torch removes its light across chunks");
}

static int amountAt(World& w, int x, int y, int z) { return fluidAmount(w.getBlock(x, y, z)); }

static void testFluids() {
    printf("[fluids]\n");
    auto w = flatWorld();
    w->setBlock(8, 1, 8, makeState(B::WATER, 0));
    for (int i = 0; i < 20 * 20; ++i) w->tick();
    CHECK(amountAt(*w, 9, 1, 8) == 7 && amountAt(*w, 10, 1, 8) == 6 && amountAt(*w, 15, 1, 8) == 1, "water spreads 7 blocks with decreasing level");
    CHECK(amountAt(*w, 16, 1, 8) == 0, "water stops after 7 blocks");
    CHECK(amountAt(*w, 8, 1, 8) == 8 && amountAt(*w, 11, 1, 11) == 2, "diamond shape spread");
    // remove the source: all flowing water must drain
    w->setBlock(8, 1, 8, 0);
    for (int i = 0; i < 20 * 40; ++i) w->tick();
    bool dry = true; for (int x = 0; x < 20; ++x) for (int z = 0; z < 20; ++z) if (amountAt(*w, x, 1, z)) dry = false;
    CHECK(dry, "flowing water disappears once its source is removed");

    // infinite water: two sources with a gap
    w->setBlock(2, 1, 40, makeState(B::WATER, 0)); w->setBlock(4, 1, 40, makeState(B::WATER, 0));
    for (int i = 0; i < 20 * 5; ++i) w->tick();
    CHECK(isFluidSource(w->getBlock(3, 1, 40)), "gap between two sources becomes a source (infinite water)");
    for (int x = 0; x < 20; ++x) for (int z = 35; z < 45; ++z) w->setBlock(x, 1, z, 0);
    for (int i = 0; i < 20 * 30; ++i) w->tick();

    // waterfall
    for (int y = 1; y <= 4; ++y) for (int x = -3; x <= 3; ++x) for (int z = -30; z <= -24; ++z) w->setBlock(x, y, z, 0);
    w->setBlock(0, 0, -27, 0);                                   // a 1x1 hole in the floor (y=0) -> leads to stone floor at y=-1
    w->setBlock(0, 6, -27, makeState(B::STONE));
    w->setBlock(1, 4, -27, makeState(B::STONE));
    w->setBlock(0, 4, -27, makeState(B::WATER, 0)); w->setBlock(0, 5, -27, makeState(B::STONE));
    for (int i = 0; i < 20 * 20; ++i) w->tick();
    CHECK(amountAt(*w, 0, 3, -27) == 8 && amountAt(*w, 0, 1, -27) == 8, "water falls as a full column");
    // the hole makes the surface flow toward it: no water should have spread far sideways at y=1 after the column landed in the hole
    CHECK(amountAt(*w, 0, 0, -27) == 8, "water fills the hole in the floor");

    // lava: spreads only 3 blocks on the overworld and is slower
    auto w2 = flatWorld();
    w2->setBlock(8, 1, 8, makeState(B::LAVA, 0));
    for (int i = 0; i < 20 * 20; ++i) w2->tick();
    CHECK(amountAt(*w2, 9, 1, 8) == 6 && amountAt(*w2, 11, 1, 8) == 2 && amountAt(*w2, 12, 1, 8) == 0, "lava flows 3 blocks");
    // water meets lava source -> obsidian
    w2->setBlock(8, 3, 8, makeState(B::WATER, 0));
    for (int i = 0; i < 20 * 5; ++i) w2->tick();
    CHECK(stateId(w2->getBlock(8, 1, 8)) == B::LAVA || stateId(w2->getBlock(8, 1, 8)) == B::OBSIDIAN, "lava source below falling water");
    auto w3 = flatWorld();
    w3->setBlock(8, 1, 8, makeState(B::LAVA, 0)); w3->setBlock(9, 1, 8, makeState(B::WATER, 0));
    for (int i = 0; i < 20 * 3; ++i) w3->tick();
    CHECK(stateId(w3->getBlock(8, 1, 8)) == B::OBSIDIAN, "water beside lava source -> obsidian");
    auto w4 = flatWorld();
    w4->setBlock(8, 1, 8, makeState(B::LAVA, 0));
    for (int i = 0; i < 20 * 20; ++i) w4->tick();
    w4->setBlock(10, 1, 9, makeState(B::WATER, 0));
    for (int i = 0; i < 20 * 5; ++i) w4->tick();
    CHECK(stateId(w4->getBlock(10, 1, 8)) == B::COBBLESTONE || stateId(w4->getBlock(9, 1, 8)) == B::COBBLESTONE, "water touching flowing lava -> cobblestone");
    // lava falling into water -> stone
    auto w5 = flatWorld();
    for (int x = 4; x <= 12; ++x) for (int z = 4; z <= 12; ++z) { if (x == 4 || x == 12 || z == 4 || z == 12) for (int y = 1; y <= 6; ++y) w5->setBlock(x, y, z, makeState(B::STONE)); }
    w5->setBlock(8, 1, 8, makeState(B::WATER, 0));
    w5->setBlock(8, 4, 8, makeState(B::STONE)); w5->setBlock(8, 5, 8, makeState(B::LAVA, 0)); w5->setBlock(8, 4, 8, 0);
    for (int i = 0; i < 20 * 20; ++i) w5->tick();
    printf("  (lava over water column: y=2 -> %s)\n", Blocks::get(stateId(w5->getBlock(8, 2, 8))).name.c_str());
    // sand falls
    auto w6 = flatWorld();
    w6->setBlock(3, 6, 3, makeState(B::SAND));
    for (int i = 0; i < 40; ++i) w6->tick();
    CHECK(stateId(w6->getBlock(3, 1, 3)) == B::SAND && w6->getBlock(3, 6, 3) == 0, "sand falls to the ground");
}

int main() {
    Blocks::init();
    testDeterminism(); testDecoration(); testLight(); testFluids();
    printf("\n%d checks passed, %d failed\n", g_ok, g_fail);
    return g_fail ? 1 : 0;
}
