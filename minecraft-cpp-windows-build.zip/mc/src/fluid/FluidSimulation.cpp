#include "FluidSimulation.h"

namespace mc {

int FluidSimulation::tickDelay(BlockId f) const { return f == B::WATER ? 5 : (w_.ultrawarm ? 10 : 30); }
int FluidSimulation::dropOff(BlockId f) const { return f == B::WATER ? 1 : (w_.ultrawarm ? 1 : 2); }
int FluidSimulation::slopeFindDistance(BlockId f) const { return f == B::WATER ? 4 : (w_.ultrawarm ? 4 : 2); }

bool FluidSimulation::canHold(BlockState s) {
    const BlockInfo& b = blockOf(s);
    if (s == 0 || b.fluid) return true;
    if (b.id == B::SUGAR_CANE || b.id == B::LADDER) return false;
    return !b.solid;
}

BlockState FluidSimulation::flowing(BlockId f, int amount, bool falling) const {
    return falling ? makeState(f, 8) : makeState(f, 8 - amount);
}

// The fluid state this cell should have given its neighbours (0 = empty).
BlockState FluidSimulation::newLiquid(BlockId f, const BlockPos& p) const {
    int highest = 0, sources = 0;
    for (int d : HORIZ_DIRS) {
        BlockState n = w_.getBlock(p.x + DIR_DX[d], p.y, p.z + DIR_DZ[d]);
        if (stateId(n) == f) { if (stateMeta(n) == 0) ++sources; highest = std::max(highest, fluidAmount(n)); }
    }
    if (canConvertToSource(f) && sources >= 2) {
        BlockState below = w_.getBlock(p.x, p.y - 1, p.z);
        if (isWall(below) || (stateId(below) == f && stateMeta(below) == 0)) return makeState(f, 0);
    }
    if (stateId(w_.getBlock(p.x, p.y + 1, p.z)) == f) return flowing(f, 8, true);
    int amount = highest - dropOff(f);
    if (amount <= 0) return 0;
    return flowing(f, amount, false);
}

bool FluidSimulation::isHole(BlockId f, const BlockPos&, BlockState below) const {
    if (isWall(below)) return false;
    return stateId(below) == f ? true : canHold(below);
}

bool FluidSimulation::canReplaceWith(BlockState to, BlockId f, int dir) const {
    const BlockInfo& b = blockOf(to);
    if (!b.fluid) return true;
    if (stateId(to) == B::WATER) return dir == DIR_DOWN && f != B::WATER;
    return f == B::WATER && fluidAmount(to) >= 4;      // flowing lava of height >= 4/9 can be displaced by water
}

bool FluidSimulation::canSpreadTo(BlockId f, int dir, BlockState toState) const {
    return canReplaceWith(toState, f, dir) && !isWall(toState) && canHold(toState);
}

void FluidSimulation::spreadTo(BlockId f, const BlockPos& to, int dir, BlockState toState, BlockState newState) {
    if (f == B::LAVA && dir == DIR_DOWN && stateId(toState) == B::WATER) {       // lava falling into water -> stone
        w_.setBlock(to, makeState(B::STONE), SET_ALL);
        return;
    }
    if (toState != 0 && !blockOf(toState).fluid && w_.onBlockBroken) w_.onBlockBroken(to, toState);
    w_.setBlock(to, newState, SET_ALL);
}

int FluidSimulation::sourceNeighbours(BlockId f, const BlockPos& p) const {
    int n = 0;
    for (int d : HORIZ_DIRS) { BlockState s = w_.getBlock(p.x + DIR_DX[d], p.y, p.z + DIR_DZ[d]); if (stateId(s) == f && stateMeta(s) == 0) ++n; }
    return n;
}

int FluidSimulation::slopeDistance(BlockId f, const BlockPos& p, int dist, int fromDir) const {
    int minDist = 1000;
    for (int d : HORIZ_DIRS) {
        if (d == fromDir) continue;
        BlockPos r(p.x + DIR_DX[d], p.y, p.z + DIR_DZ[d]);
        BlockState rs = w_.getBlock(r);
        bool pass = !(stateId(rs) == f && stateMeta(rs) == 0) && !isWall(rs) && canHold(rs);
        if (!pass) continue;
        if (isHole(f, r, w_.getBlock(r.x, r.y - 1, r.z))) return dist;
        if (dist < slopeFindDistance(f)) {
            int dd = slopeDistance(f, r, dist + 1, DIR_OPP[d]);
            if (dd < minDist) minDist = dd;
        }
    }
    return minDist;
}

std::vector<FluidSimulation::SpreadEntry> FluidSimulation::getSpread(BlockId f, const BlockPos& p) const {
    int minCost = 1000;
    std::vector<SpreadEntry> out;
    for (int d : HORIZ_DIRS) {
        BlockPos r(p.x + DIR_DX[d], p.y, p.z + DIR_DZ[d]);
        BlockState rs = w_.getBlock(r);
        bool pass = !(stateId(rs) == f && stateMeta(rs) == 0) && !isWall(rs) && canHold(rs);
        if (!pass) continue;
        BlockState nl = newLiquid(f, r);
        int cost = isHole(f, r, w_.getBlock(r.x, r.y - 1, r.z)) ? 0 : slopeDistance(f, r, 1, DIR_OPP[d]);
        if (cost < minCost) { out.clear(); }
        if (cost <= minCost) { out.push_back({d, nl}); minCost = cost; }
    }
    return out;
}

void FluidSimulation::spreadToSides(const BlockPos& p, BlockState cur) {
    BlockId f = stateId(cur);
    int amount = fluidAmount(cur) - dropOff(f);
    if (stateMeta(cur) >= 8) amount = 7;
    if (amount <= 0) return;
    for (const SpreadEntry& e : getSpread(f, p)) {
        BlockPos r(p.x + DIR_DX[e.dir], p.y, p.z + DIR_DZ[e.dir]);
        BlockState rs = w_.getBlock(r);
        if (e.state != 0 && canSpreadTo(f, e.dir, rs)) spreadTo(f, r, e.dir, rs, e.state);
    }
}

void FluidSimulation::spread(const BlockPos& p, BlockState cur) {
    if (!blockOf(cur).fluid) return;
    BlockId f = stateId(cur);
    BlockPos below(p.x, p.y - 1, p.z);
    BlockState bs = w_.getBlock(below);
    BlockState nb = newLiquid(f, below);
    if (below.y >= WORLD_MIN_Y && nb != 0 && canSpreadTo(f, DIR_DOWN, bs)) {
        spreadTo(f, below, DIR_DOWN, bs, nb);
        if (sourceNeighbours(f, p) >= 3) spreadToSides(p, cur);
    } else if (stateMeta(cur) == 0 || !isHole(f, p, bs)) {
        spreadToSides(p, cur);
    }
}

void FluidSimulation::tick(const BlockPos& p) {
    BlockState cur = w_.getBlock(p);
    BlockId f = stateId(cur);
    if (!blockOf(cur).fluid) return;
    if (f == B::LAVA && lavaReact(p)) return;
    if (stateMeta(cur) != 0) {                         // flowing: re-evaluate level from neighbours
        BlockState nl = newLiquid(f, p);
        if (nl == 0) { w_.setBlock(p, 0, SET_ALL); return; }
        if (nl != cur) { w_.setBlock(p, nl, SET_ALL); cur = nl; w_.scheduleTick(p, tickDelay(f), TickType::Fluid); }
    }
    spread(p, cur);
}

// Lava touching water (above or beside it) turns into obsidian (source) or cobblestone (flowing).
bool FluidSimulation::lavaReact(const BlockPos& p) {
    BlockState cur = w_.getBlock(p);
    if (stateId(cur) != B::LAVA) return false;
    static const int check[5] = {DIR_UP, DIR_NORTH, DIR_SOUTH, DIR_EAST, DIR_WEST};
    for (int d : check) {
        if (stateId(w_.getBlock(p.x + DIR_DX[d], p.y + DIR_DY[d], p.z + DIR_DZ[d])) == B::WATER) {
            w_.setBlock(p, makeState(stateMeta(cur) == 0 ? B::OBSIDIAN : B::COBBLESTONE), SET_ALL);
            return true;
        }
    }
    return false;
}

} // namespace mc
