// Headless tests: crafting, menus, furnace, player physics, raycast, mining rules.
#include "../src/player/Player.h"
#include "../src/lighting/LightEngine.h"
#include <cstdio>
using namespace mc;
static int g_fail = 0, g_ok = 0;
#define CHECK(c, msg) do { if (c) ++g_ok; else { ++g_fail; printf("  FAIL: %s (line %d)\n", msg, __LINE__); } } while (0)

static std::unique_ptr<World> flat(int r = 2) {
    auto w = std::make_unique<World>(1);
    for (int cz = -r; cz <= r; ++cz) for (int cx = -r; cx <= r; ++cx) { auto c = std::make_shared<Chunk>(cx, cz);
        for (int z = 0; z < 16; ++z) for (int x = 0; x < 16; ++x) for (int y = WORLD_MIN_Y; y <= 0; ++y) c->set(x, y, z, makeState(B::STONE));
        w->addChunk(c); }
    for (auto& kv : w->chunks()) w->lighting().initChunk(*kv.second);
    return w;
}
static ItemId I(const char* n) { return Items::byName(n); }

int main() {
    Blocks::init(); Items::init(); Recipes::init();
    printf("[crafting]\n");
    ItemStack out; ItemStack g[9];
    g[0] = ItemStack(I("oak_log"), 1);
    CHECK(Recipes::match(g, 3, 3, out) && out.id == I("oak_planks") && out.count == 4, "log -> 4 planks");
    g[0].clear(); g[4] = ItemStack(I("oak_planks"), 1); g[7] = ItemStack(I("birch_planks"), 1);
    CHECK(Recipes::match(g, 3, 3, out) && out.id == I("stick") && out.count == 4, "2 planks (any wood) -> sticks, position independent");
    for (auto& s : g) s.clear(); for (int i : {0, 1, 3, 4}) g[i] = ItemStack(I("spruce_planks"), 1);
    CHECK(Recipes::match(g, 3, 3, out) && out.id == I("crafting_table"), "2x2 planks -> crafting table");
    for (auto& s : g) s.clear(); for (int i : {0, 1, 2}) g[i] = ItemStack(I("iron_ingot"), 1); g[4] = g[7] = ItemStack(I("stick"), 1);
    CHECK(Recipes::match(g, 3, 3, out) && out.id == I("iron_pickaxe"), "iron pickaxe");
    for (auto& s : g) s.clear(); for (int i : {0, 1, 3, 4, 6}) g[i] = ItemStack(I("diamond"), 1); g[7] = ItemStack(I("diamond"), 1); g[5] = ItemStack(I("stick"), 1);
    CHECK(!Recipes::match(g, 3, 3, out), "invalid pattern does not craft");
    for (auto& s : g) s.clear(); for (int i : {0, 3}) g[i] = ItemStack(I("coal"), 1); g[0] = ItemStack(I("coal"), 1); g[3] = ItemStack(I("stick"), 1);
    CHECK(Recipes::match(g, 3, 3, out) && out.id == I("torch") && out.count == 4, "torches");
    // mirrored axe: "MM","MS"," S" and its mirror
    for (auto& x : g) x.clear(); g[1] = g[2] = ItemStack(I("cobblestone"), 1); g[4] = ItemStack(I("stick"), 1); g[5] = ItemStack(I("cobblestone"), 1); g[7] = ItemStack(I("stick"), 1);
    CHECK(Recipes::match(g, 3, 3, out) && out.id == I("stone_axe"), "mirrored axe recipe");
    const SmeltRecipe* sr = Recipes::smelt(I("raw_iron")); CHECK(sr && sr->out == I("iron_ingot"), "raw iron smelts");

    printf("[menus]\n");
    Player p; p.inv.slots[0] = ItemStack(I("oak_log"), 3);
    auto m = Menu::playerMenu(p.inv);
    int hotbar0 = m->invFirst + 27;
    m->click(hotbar0, 0, false);                      // pick up 3 logs
    CHECK(m->cursor.count == 3 && p.inv.slots[0].empty(), "left click picks up the stack");
    m->click(m->gridFirst, 1, false);                 // place 1 log into grid
    CHECK(m->slots[0].stack->id == I("oak_planks") && m->slots[0].stack->count == 4, "grid shows craft result");
    m->click(hotbar0, 0, false);                      // put the 2 remaining logs back
    m->click(0, 0, false);                            // take result
    CHECK(m->cursor.id == I("oak_planks") && m->cursor.count == 4, "result moves to cursor");
    CHECK(m->slots[m->gridFirst].stack->empty(), "ingredient consumed");
    m->click(hotbar0 + 1, 0, false);
    CHECK(p.inv.slots[1].count == 4, "cursor placed into slot");
    m->click(hotbar0 + 1, 1, false); CHECK(m->cursor.count == 2 && p.inv.slots[1].count == 2, "right click splits half");
    m->click(hotbar0 + 2, 0, false); CHECK(p.inv.slots[2].count == 2, "place split half");
    p.inv.slots[3] = ItemStack(I("iron_helmet"), 1);
    m->click(m->invFirst + 27 + 3, 0, true);          // shift-click armor
    CHECK(!p.inv.slots[Inventory::ARMOR0 + 3].empty(), "shift-click equips armor");
    ItemStack bad(I("dirt"), 1); m->cursor = bad; m->click(5, 0, false); CHECK(m->cursor.id == I("dirt"), "dirt cannot go into an armor slot");
    m->close(p.inv);
    CHECK(p.inv.count(I("dirt")) == 1, "closing returns the cursor to inventory");
    Inventory inv2; ItemStack big(I("cobblestone"), 150); int left = inv2.add(big); CHECK(left == 0 && inv2.count(I("cobblestone")) == 150, "add splits into stacks of 64");

    printf("[furnace]\n");
    FurnaceState f; f.input = ItemStack(I("raw_iron"), 2); f.fuel = ItemStack(I("coal"), 1);
    for (int i = 0; i < 420; ++i) f.tick();
    CHECK(f.output.id == I("iron_ingot") && f.output.count == 2 && f.input.empty(), "furnace smelts 2 iron in 400 ticks with 1 coal");

    printf("[mining]\n");
    ItemStack none, wood(I("wooden_pickaxe"), 1), iron(I("iron_pickaxe"), 1);
    const BlockInfo& stone = Blocks::get(B::STONE); const BlockInfo& dirt = Blocks::get(B::DIRT); const BlockInfo& obs = Blocks::get(B::OBSIDIAN);
    CHECK(!Items::canHarvest(stone, none) && Items::canHarvest(stone, wood), "stone needs a pickaxe");
    CHECK(!Items::canHarvest(obs, iron), "obsidian needs diamond");
    float t = 1.0f / Items::breakDelta(stone, wood, true, false) / 20.0f; CHECK(t > 1.1f && t < 1.2f, "stone with wooden pickaxe ~1.15s");
    float t2 = 1.0f / Items::breakDelta(dirt, none, true, false) / 20.0f; CHECK(t2 > 0.7f && t2 < 0.8f, "dirt by hand 0.75s");
    CHECK(Items::breakDelta(dirt, none, false, false) < Items::breakDelta(dirt, none, true, false) / 4.0f, "mining in the air is 5x slower");
    Rng rng(5); std::vector<ItemStack> drops; Items::rollDrops(stone, wood, rng, drops); CHECK(drops.size() == 1 && drops[0].id == I("cobblestone"), "stone drops cobblestone");
    drops.clear(); Items::rollDrops(Blocks::get(B::DIAMOND_ORE), iron, rng, drops); CHECK(drops.size() == 1 && drops[0].id == I("diamond"), "diamond ore drops a diamond");
    drops.clear(); Items::rollDrops(Blocks::get(B::DIAMOND_ORE), wood, rng, drops); CHECK(drops.empty(), "no drop with a too weak tool");

    printf("[player physics]\n");
    auto w = flat();
    Player pl; pl.pos = pl.prevPos = Vec3d(0.5, 10, 0.5);
    PlayerInput idle;
    for (int i = 0; i < 40; ++i) pl.tick(*w, idle);
    CHECK(pl.onGround && std::fabs(pl.pos.y - 1.0) < 1e-6, "falls and stands on the floor (y=1)");
    CHECK(pl.health < 20.0f && pl.fallDamageTaken == 6, "fall damage: 9 blocks -> ceil(9-3)=6");
    pl.respawn(); pl.pos = pl.prevPos = Vec3d(0.5, 1, 0.5); pl.onGround = true;
    PlayerInput walk; walk.forward = 1;
    for (int i = 0; i < 20; ++i) pl.tick(*w, walk);
    double d = std::sqrt(pl.pos.x * pl.pos.x + (pl.pos.z - 0.5) * (pl.pos.z - 0.5));
    printf("  walk20=%.2f\n", d);
    CHECK(d > 3.0 && d < 4.8, "walking speed ~4.3 blocks/s");
    PlayerInput run = walk; run.sprint = true; Player p2; p2.pos = p2.prevPos = Vec3d(0.5, 1, 0.5); p2.onGround = true;
    for (int i = 0; i < 20; ++i) p2.tick(*w, run);
    double d2 = std::sqrt(p2.pos.x * p2.pos.x + (p2.pos.z - 0.5) * (p2.pos.z - 0.5));
    printf("  sprint20=%.2f\n", d2);
    CHECK(d2 > d * 1.25 && d2 < 6.3, "sprinting speed ~5.6 blocks/s");
    // jump height ~1.25
    Player p3; p3.pos = p3.prevPos = Vec3d(0.5, 1, 0.5); p3.onGround = true; PlayerInput jmp; jmp.jump = true; double maxY = 1;
    for (int i = 0; i < 30; ++i) { p3.tick(*w, jmp); maxY = std::max(maxY, p3.pos.y); jmp.jump = i > 12 ? true : false; }
    CHECK(maxY - 1.0 > 1.1 && maxY - 1.0 < 1.35, "jump height ~1.25 blocks");
    // wall + step: a 1-block step cannot be walked up, half slab can
    w->setBlock(0, 1, 5, makeState(B::STONE));
    Player p4; p4.pos = p4.prevPos = Vec3d(0.5, 1, 3.5); p4.onGround = true; PlayerInput fw; fw.forward = 1;
    for (int i = 0; i < 40; ++i) p4.tick(*w, fw);
    CHECK(p4.pos.z < 5.0 && p4.pos.y < 1.01, "full block blocks walking");
    w->setBlock(1, 1, 5, makeState(B::OAK_SLAB, 0));
    Player p5; p5.pos = p5.prevPos = Vec3d(1.5, 1, 3.5); p5.onGround = true;
    for (int i = 0; i < 25; ++i) p5.tick(*w, fw);
    CHECK(p5.pos.z > 5.5, "half slab is stepped over automatically");
    // sneaking at an edge does not fall
    for (int x = -3; x <= 3; ++x) for (int z = 10; z <= 14; ++z) w->setBlock(x, 0, z, 0);
    Player p6; p6.pos = p6.prevPos = Vec3d(0.5, 1, 8.5); p6.onGround = true; PlayerInput sn; sn.forward = 1; sn.sneak = true;
    for (int i = 0; i < 80; ++i) p6.tick(*w, sn);
    CHECK(p6.pos.y > 0.99 && p6.pos.z < 10.35, "sneaking stops at the edge");
    // water: swimming + drowning
    for (int x = -8; x <= -2; ++x) for (int z = -8; z <= -2; ++z) for (int y = 1; y <= 6; ++y) w->setBlock(x, y, z, makeState(B::WATER, 0), 0);
    Player p7; p7.pos = p7.prevPos = Vec3d(-5, 5, -5);
    for (int i = 0; i < 60; ++i) p7.tick(*w, idle);
    CHECK(p7.inWater && p7.pos.y < 2.5 && p7.fallDamageTaken == 0, "sinks slowly in water, no fall damage");
    for (int i = 0; i < 400; ++i) p7.tick(*w, idle);
    CHECK(p7.health < 20.0f, "drowning damage after the air runs out");
    // creative flight
    Player p8; p8.setMode(GameMode::Creative); p8.pos = p8.prevPos = Vec3d(0.5, 1, 0.5); p8.flying = true; PlayerInput up; up.jump = true;
    for (int i = 0; i < 20; ++i) p8.tick(*w, up);
    CHECK(p8.pos.y > 4.0, "creative flying rises");
    Player p9; p9.setMode(GameMode::Spectator); p9.pos = p9.prevPos = Vec3d(0.5, 1, 0.5); PlayerInput dn; dn.sneak = true;
    for (int i = 0; i < 30; ++i) p9.tick(*w, dn);
    CHECK(p9.pos.y < -2.0, "spectator passes through blocks");
    // hunger
    Player h; h.food = 5; h.exhaustion = 4.0f; h.saturation = 0; h.pos = h.prevPos = Vec3d(0.5, 1, 0.5); h.onGround = true; h.tick(*w, idle);
    CHECK(h.food == 4.0f, "exhaustion drains food");
    printf("[raycast]\n");
    RayHit rh = raycastBlocks(*w, Vec3d(0.5, 3.5, 0.5), Vec3d(0, -1, 0), 10);
    CHECK(rh.hit && rh.pos.y == 0 && rh.face == DIR_UP, "ray hits the floor top face");
    rh = raycastBlocks(*w, Vec3d(0.5, 1.5, 3.5), Vec3d(0, 0, 1), 10);
    CHECK(rh.hit && rh.pos == BlockPos(0, 1, 5) && rh.face == DIR_NORTH, "ray hits the stone block's north face");
    rh = raycastBlocks(*w, Vec3d(0.5, 1.5, 3.5), Vec3d(0, 0, 1), 1.0); CHECK(!rh.hit, "reach limit respected");
    printf("\n%d checks passed, %d failed\n", g_ok, g_fail);
    return g_fail ? 1 : 0;
}
