#pragma once
// CPU chunk meshing (no OpenGL): greedy meshing of cubes with smooth light + ambient occlusion,
// special shapes (plants, boxes, fluids) and per-section cave-visibility bits for occlusion culling.
#include "../world/World.h"
#include <memory>
#include <vector>

namespace mc {

struct Vertex {
    float x, y, z;          // chunk-local position
    float u, v;             // texture coordinates in tile units (repeat)
    uint8_t sky, blk, ao, shade;   // normalised 0..255
    uint8_t r, g, b, a;     // tint (a: 255 multiply, 128 mask by texture alpha, 0 none)
    uint16_t layer, pad;    // texture array layer
};
static_assert(sizeof(Vertex) == 32, "vertex layout");

enum Pass : int { PASS_OPAQUE = 0, PASS_CUTOUT = 1, PASS_TRANSLUCENT = 2, PASS_COUNT = 3 };

// Immutable copy of a chunk and its 1-block border, built on the main thread, meshed on a worker.
struct MeshInput {
    int cx = 0, cz = 0;
    int firstSection = 0, lastSection = -1;                 // non-empty section range (inclusive)
    static constexpr int W = 18;
    std::vector<BlockState> blocks;                         // [(y*W + (z+1))*W + (x+1)], y in [0,384)
    std::vector<uint8_t> light;                             // sky<<4|block, same layout
    uint8_t biome[W * W];
    BlockState at(int x, int y, int z) const {
        if (y < 0) return makeState(B::BEDROCK); if (y >= WORLD_HEIGHT) return 0;
        return blocks[((size_t)y * W + (z + 1)) * W + (x + 1)];
    }
    uint8_t lightAt(int x, int y, int z) const {
        if (y < 0) return 0; if (y >= WORLD_HEIGHT) return 15 << 4;
        return light[((size_t)y * W + (z + 1)) * W + (x + 1)];
    }
};

struct MeshOutput {
    int cx = 0, cz = 0; uint32_t version = 0;
    std::vector<Vertex> verts[PASS_COUNT];
    uint32_t secFirstQuad[PASS_COUNT][SECTION_COUNT + 1] = {};   // quad range of every section per pass
    uint16_t secVis[SECTION_COUNT] = {};                         // 15-bit face connectivity
    bool empty() const { return verts[0].empty() && verts[1].empty() && verts[2].empty(); }
};

std::shared_ptr<MeshInput> buildMeshInput(const World& w, const Chunk& c);
void meshChunk(const MeshInput& in, MeshOutput& out);
inline int visPairBit(int a, int b) { if (a > b) std::swap(a, b); return a * 6 - a * (a + 1) / 2 + (b - a - 1); }
uint32_t biomeTint(int kind, int biome);      // kind 0 grass, 1 foliage, 2 water -> 0xRRGGBB

} // namespace mc
