#include "Settings.h"
#include <fstream>
#include <sstream>

namespace mc {

void Settings::load(const std::string& path) {
    std::ifstream f(path); std::string line;
    while (std::getline(f, line)) {
        auto eq = line.find('='); if (eq == std::string::npos) continue;
        std::string k = line.substr(0, eq), v = line.substr(eq + 1);
        try {
            if (k == "lang") lang = v; else if (k == "renderDistance") renderDistance = std::stoi(v); else if (k == "fov") fov = std::stof(v);
            else if (k == "sensitivity") sensitivity = std::stof(v); else if (k == "volume") volume = std::stof(v); else if (k == "guiScale") guiScale = std::stoi(v);
            else if (k == "vsync") vsync = v == "1"; else if (k == "fullscreen") fullscreen = v == "1"; else if (k == "occlusion") occlusion = v == "1";
        } catch (...) {}
    }
    if (renderDistance < 3) renderDistance = 3; if (renderDistance > 32) renderDistance = 32;
}

void Settings::save(const std::string& path) const {
    std::ofstream f(path);
    f << "lang=" << lang << "\nrenderDistance=" << renderDistance << "\nfov=" << fov << "\nsensitivity=" << sensitivity << "\nvolume=" << volume << "\nguiScale=" << guiScale
      << "\nvsync=" << vsync << "\nfullscreen=" << fullscreen << "\nocclusion=" << occlusion << "\n";
}

std::unordered_map<std::string, std::string> Lang::map_;

void Lang::load(const std::string& dir, const std::string& code) {
    map_.clear(); std::ifstream f(dir + "/lang/" + code + ".txt"); std::string line;
    while (std::getline(f, line)) { if (line.empty() || line[0] == '#') continue; auto eq = line.find('='); if (eq == std::string::npos) continue; if (!line.empty() && line.back() == '\r') line.pop_back(); map_[line.substr(0, eq)] = line.substr(eq + 1); }
}
const std::string& Lang::tr(const std::string& key) { static std::string tmp; auto it = map_.find(key); if (it != map_.end()) return it->second; tmp = key; return tmp; }
std::string Lang::trf(const std::string& key, const std::string& a) { std::string s = tr(key); auto p = s.find("%s"); if (p != std::string::npos) s.replace(p, 2, a); return s; }

} // namespace mc
