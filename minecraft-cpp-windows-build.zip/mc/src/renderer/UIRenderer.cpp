#include "UIRenderer.h"
#include "ImageLoader.h"
#include <cstring>

namespace mc {

bool UIRenderer::init(const std::string& dir, const TextureArray* arr) {
    dir_ = dir; arr_ = arr;
    if (!sh_prog_.compile(SHADER_UI_VS, SHADER_UI_FS, "ui")) return false;
    glGenVertexArrays(1, &vao_); glGenBuffers(1, &vbo_);
    glBindVertexArray(vao_); glBindBuffer(GL_ARRAY_BUFFER, vbo_); glBufferData(GL_ARRAY_BUFFER, 1 << 16, nullptr, GL_STREAM_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(V), (const void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(V), (const void*)8);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(V), (const void*)16);
    glEnableVertexAttribArray(3); glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, sizeof(V), (const void*)20);
    glBindVertexArray(0);
    int w, h; font_ = loadSheet("../font/font", w, h);
    return font_ != 0;
}

void UIRenderer::shutdown() { for (auto& kv : sheets_) glDeleteTextures(1, &kv.second.id); sheets_.clear(); sh_prog_.destroy(); }

GLuint UIRenderer::loadSheet(const std::string& rel, int& w, int& h) {
    auto it = sheets_.find(rel); if (it != sheets_.end()) { w = it->second.w; h = it->second.h; return it->second.id; }
    std::vector<uint8_t> px; int iw, ih;
    if (!loadImageRGBA(dir_ + "/textures/" + rel + ".png", iw, ih, px)) { sheets_[rel] = {0, 0, 0}; w = h = 0; return 0; }
    GLuint id; glGenTextures(1, &id); glBindTexture(GL_TEXTURE_2D, id); glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, iw, ih, 0, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    sheets_[rel] = {id, iw, ih}; w = iw; h = ih; return id;
}

void UIRenderer::begin(int w, int h) { sw_ = w; sh_ = h; verts_.clear(); curSheet_ = 0; }
void UIRenderer::end() { flush(); }

void UIRenderer::flush() {
    if (verts_.empty()) return;
    glViewport(0, 0, sw_, sh_);
    glDisable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    sh_prog_.use(); glUniform2f(sh_prog_.loc("uScreen"), (float)sw_, (float)sh_);
    if (arr_) arr_->bind(0);
    glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_2D, curSheet_ ? curSheet_ : font_);
    glUniform1i(sh_prog_.loc("uArr"), 0); glUniform1i(sh_prog_.loc("uSheet"), 1);
    glBindVertexArray(vao_); glBindBuffer(GL_ARRAY_BUFFER, vbo_);
    glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(verts_.size() * sizeof(V)), verts_.data(), GL_STREAM_DRAW);
    glDrawArrays(GL_TRIANGLES, 0, (GLsizei)verts_.size());
    glBindVertexArray(0); glActiveTexture(GL_TEXTURE0); glDisable(GL_BLEND); glEnable(GL_DEPTH_TEST);
    verts_.clear();
}

void UIRenderer::quad(const float p[8], const float uv[8], float mode, float layer, uint32_t c) {
    uint8_t r = (c >> 24) & 255, g = (c >> 16) & 255, b = (c >> 8) & 255, a = c & 255;
    static const int order[6] = {0, 1, 2, 2, 3, 0};
    for (int i : order) verts_.push_back({p[i * 2], p[i * 2 + 1], uv[i * 2], uv[i * 2 + 1], r, g, b, a, mode, layer});
}

void UIRenderer::rect(float x, float y, float w, float h, uint32_t rgba) {
    float p[8] = {x, y, x + w, y, x + w, y + h, x, y + h}, uv[8] = {0, 0, 1, 0, 1, 1, 0, 1}; quad(p, uv, 0, 0, rgba);
}
void UIRenderer::sheet(GLuint tex, float x, float y, float w, float h, float u0, float v0, float u1, float v1, uint32_t rgba) {
    if (tex != curSheet_) { flush(); curSheet_ = tex; }
    float p[8] = {x, y, x + w, y, x + w, y + h, x, y + h}, uv[8] = {u0, v0, u1, v0, u1, v1, u0, v1}; quad(p, uv, 2, 0, rgba);
}
void UIRenderer::tile(int layer, float x, float y, float w, float h, uint32_t rgba) {
    float p[8] = {x, y, x + w, y, x + w, y + h, x, y + h}, uv[8] = {0, 0, 1, 0, 1, 1, 0, 1}; quad(p, uv, 1, (float)layer, rgba);
}

void UIRenderer::blockIcon(BlockId id, float x, float y, float s) {
    const BlockInfo& b = Blocks::get(id);
    uint32_t tint = b.tint == Tint::Grass ? 0x91BD59FF : b.tint == Tint::Foliage ? 0x77AB2FFF : b.fixedTint != 0xFFFFFF ? ((b.fixedTint << 8) | 0xFF) : 0xFFFFFFFF;
    if (b.shape == Shape::Cross || b.shape == Shape::None || (b.shape == Shape::Box && b.id == B::TORCH) || b.id == B::LADDER || b.id == B::SNOW_LAYER) {
        tile(b.tex[DIR_SOUTH], x, y, s, s, b.tint == Tint::None && b.fixedTint == 0xFFFFFF ? 0xFFFFFFFF : tint); return;
    }
    float cx = x + s / 2, h = s;
    auto shade = [](uint32_t c, int k) { return (((c >> 24) * k / 255) << 24) | ((((c >> 16) & 255) * k / 255) << 16) | ((((c >> 8) & 255) * k / 255) << 8) | 0xFF; };
    float top[8] = {cx, y, cx + s / 2, y + h / 4, cx, y + h / 2, cx - s / 2, y + h / 4}, uvT[8] = {0, 0, 1, 0, 1, 1, 0, 1};
    float left[8] = {cx - s / 2, y + h / 4, cx, y + h / 2, cx, y + h, cx - s / 2, y + h * 3 / 4};
    float right[8] = {cx, y + h / 2, cx + s / 2, y + h / 4, cx + s / 2, y + h * 3 / 4, cx, y + h};
    float uv[8] = {0, 0, 1, 0, 1, 1, 0, 1};
    uint32_t sideTint = b.tintSideMask ? tint : 0xFFFFFFFF; float sideMode = b.tintSideMask ? 3.0f : 1.0f;
    uint32_t topC = b.tint != Tint::None ? tint : 0xFFFFFFFF;
    quad(top, uvT, 1, (float)b.tex[DIR_UP], topC);
    quad(left, uv, sideMode, (float)b.tex[DIR_SOUTH], shade(sideTint, 205));
    quad(right, uv, sideMode, (float)b.tex[DIR_EAST], shade(sideTint, 150));
}

void UIRenderer::itemIcon(const ItemStack& st, float x, float y, float size) {
    if (st.empty()) return;
    const ItemInfo& it = Items::get(st.id);
    if (it.block) blockIcon(it.block, x, y, size); else tile(it.texture, x, y, size, size);
}

int UIRenderer::glyphIndex(uint32_t cp) {
    if (cp >= 32 && cp <= 126) return (int)cp - 32;
    if (cp >= 0x410 && cp <= 0x44F) return 95 + (int)(cp - 0x410);
    switch (cp) { case 0x401: return 159; case 0x451: return 160; case 0x2022: return 161; case 0xB0: return 162; case 0xD7: return 163; case 0x2190: return 164; case 0x2192: return 165; case 0x2191: return 166; case 0x2193: return 167; case 0x2665: return 168; }
    return '?' - 32;
}

static uint32_t nextCp(const std::string& s, size_t& i) {
    unsigned char c = s[i++]; if (c < 0x80) return c;
    int n = (c >= 0xF0) ? 3 : (c >= 0xE0) ? 2 : 1; uint32_t cp = c & (0x3F >> n);
    while (n-- > 0 && i < s.size()) cp = (cp << 6) | (s[i++] & 0x3F);
    return cp;
}

float UIRenderer::textWidth(const std::string& s, int scale) const { size_t i = 0; int n = 0; while (i < s.size()) { nextCp(s, i); ++n; } return (float)(n * 7 * scale); }

void UIRenderer::text(const std::string& s, float x, float y, int scale, uint32_t rgba, bool shadow) {
    if (!font_) return;
    if (curSheet_ != font_) { flush(); curSheet_ = font_; }
    for (int pass = shadow ? 0 : 1; pass < 2; ++pass) {
        float cx = x + (pass == 0 ? scale : 0), cy = y + (pass == 0 ? scale : 0);
        uint32_t col = pass == 0 ? ((((rgba >> 24) & 255) / 4) << 24 | (((rgba >> 16) & 255) / 4) << 16 | (((rgba >> 8) & 255) / 4) << 8 | (rgba & 255)) : rgba;
        size_t i = 0;
        while (i < s.size()) {
            uint32_t cp = nextCp(s, i);
            if (cp == '\n') { cx = x; cy += 12 * scale; continue; }
            int g = glyphIndex(cp); float u0 = (g % 16) * 8 / 128.0f, v0 = (g / 16) * 12 / 192.0f;
            if (cp != ' ') { float p[8] = {cx, cy, cx + 8.0f * scale, cy, cx + 8.0f * scale, cy + 12.0f * scale, cx, cy + 12.0f * scale}; float uv[8] = {u0, v0, u0 + 8 / 128.0f, v0, u0 + 8 / 128.0f, v0 + 12 / 192.0f, u0, v0 + 12 / 192.0f}; quad(p, uv, 2, 0, col); }
            cx += 7.0f * scale;
        }
    }
}

} // namespace mc
