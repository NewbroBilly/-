#pragma once
#include "GL.h"
#include <string>
#include <unordered_map>
namespace mc {
class Shader {
public:
    bool compile(const char* vs, const char* fs, const char* name);
    void use() const { glUseProgram(prog_); }
    GLint loc(const char* n) { auto it = u_.find(n); if (it != u_.end()) return it->second; GLint l = glGetUniformLocation(prog_, n); u_[n] = l; return l; }
    void destroy() { if (prog_) glDeleteProgram(prog_); prog_ = 0; }
    GLuint id() const { return prog_; }
private:
    GLuint prog_ = 0; std::unordered_map<std::string, GLint> u_;
};
extern const char* SHADER_TERRAIN_VS; extern const char* SHADER_TERRAIN_FS;
extern const char* SHADER_SKY_VS; extern const char* SHADER_SKY_FS;
extern const char* SHADER_LINE_VS; extern const char* SHADER_LINE_FS;
extern const char* SHADER_UI_VS; extern const char* SHADER_UI_FS;
}
