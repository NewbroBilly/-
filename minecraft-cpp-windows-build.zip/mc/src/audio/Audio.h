#pragma once
// Sound engine: OpenAL playback of the .ogg files found under assets/sounds (decoded with stb_vorbis).
// Event names are derived from the file layout: sounds/dig/stone1.ogg -> "dig.stone" (random variant picked each time).
#include "../core/Types.h"
#include "../world/Block.h"
#include <string>
#include <unordered_map>
#include <vector>

namespace mc {

class AudioSystem {
public:
    bool init(const std::string& assetDir);
    void shutdown();
    void setVolume(float master) { master_ = master; }
    void setListener(const Vec3d& pos, float yawDeg);
    void play(const std::string& event, double x, double y, double z, float volume = 1.0f, float pitch = 1.0f);   // positional
    void play2D(const std::string& event, float volume = 1.0f, float pitch = 1.0f);                                // UI / player sounds
    void playBlock(const BlockInfo& b, const char* kind, double x, double y, double z, float volume = 1.0f);       // kind: "dig" | "step"
    void startMusic(const std::string& group);                                                                      // plays a random assets/music/<group>/*.ogg if present
    void update();                                                                                                  // music scheduling
    bool hasEvent(const std::string& event) const { return events_.count(event) != 0; }
    size_t eventCount() const { return events_.size(); }
    bool available() const { return ok_; }
private:
    struct Buf { unsigned id = 0; bool loaded = false; };
    unsigned bufferFor(const std::string& file);
    unsigned freeSource();
    std::string dir_; bool ok_ = false; float master_ = 1.0f;
    std::unordered_map<std::string, std::vector<std::string>> events_;
    std::unordered_map<std::string, Buf> buffers_;
    std::vector<unsigned> sources_; unsigned musicSource_ = 0; std::string musicGroup_; double nextMusic_ = 0; unsigned rng_ = 12345;
    void* dev_ = nullptr; void* ctx_ = nullptr;
};

const char* soundGroup(SoundType t);

} // namespace mc
