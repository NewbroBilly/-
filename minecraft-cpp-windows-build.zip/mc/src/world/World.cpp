#include "World.h"
#include "../lighting/LightEngine.h"
#include "../fluid/FluidSimulation.h"

namespace mc {

static uint64_t packPos(const BlockPos& p) {
    return ((uint64_t)((uint32_t)p.x & 0x3FFFFFF) << 38) | ((uint64_t)((uint32_t)p.z & 0x3FFFFFF) << 12) | (uint64_t)((uint32_t)(p.y - WORLD_MIN_Y) & 0xFFF);
}
static std::unordered_set<uint64_t> g_tickKeys[3];

World::World(uint64_t seed_) : seed(seed_), light_(new LightEngine(*this)), fluids_(new FluidSimulation(*this)) {}
World::~World() = default;

std::shared_ptr<Chunk> World::chunkShared(int cx, int cz) const {
    auto it = chunks_.find(ChunkPos(cx, cz)); return it == chunks_.end() ? nullptr : it->second;
}
Chunk* World::chunk(int cx, int cz) const {
    if (cx == cacheX_ && cz == cacheZ_) return cacheChunk_;
    auto it = chunks_.find(ChunkPos(cx, cz));
    Chunk* c = it == chunks_.end() ? nullptr : it->second.get();
    cacheX_ = cx; cacheZ_ = cz; cacheChunk_ = c;
    return c;
}
void World::addChunk(std::shared_ptr<Chunk> c) { cacheX_ = 0x7fffffff; chunks_[ChunkPos(c->cx, c->cz)] = std::move(c); }
std::shared_ptr<Chunk> World::removeChunk(int cx, int cz) {
    cacheX_ = 0x7fffffff;
    auto it = chunks_.find(ChunkPos(cx, cz)); if (it == chunks_.end()) return nullptr;
    auto c = it->second; chunks_.erase(it); return c;
}

BlockState World::getBlock(int x, int y, int z) const {
    if (y < WORLD_MIN_Y) return makeState(B::BEDROCK);
    if (y >= WORLD_MAX_Y) return 0;
    Chunk* c = chunk(x >> 4, z >> 4);
    if (!c) return makeState(B::STONE);
    return c->get(x & 15, y, z & 15);
}
int World::surfaceY(int x, int z) const {
    Chunk* c = chunk(x >> 4, z >> 4); if (!c) return WORLD_MIN_Y - 1;
    for (int y = WORLD_MAX_Y - 1; y >= WORLD_MIN_Y; --y) if (c->get(x & 15, y, z & 15) != 0) return y;
    return WORLD_MIN_Y - 1;
}
int World::skyLight(int x, int y, int z) const {
    if (y >= WORLD_MAX_Y) return 15; if (y < WORLD_MIN_Y) return 0;
    Chunk* c = chunk(x >> 4, z >> 4); return c ? c->skyLight(x & 15, y, z & 15) : 0;
}
int World::blockLight(int x, int y, int z) const {
    if (y < WORLD_MIN_Y || y >= WORLD_MAX_Y) return 0;
    Chunk* c = chunk(x >> 4, z >> 4); return c ? c->blockLight(x & 15, y, z & 15) : 0;
}
uint8_t World::lightRaw(int x, int y, int z) const {
    if (y >= WORLD_MAX_Y) return 15 << 4; if (y < WORLD_MIN_Y) return 0;
    Chunk* c = chunk(x >> 4, z >> 4); return c ? c->lightRaw(x & 15, y, z & 15) : 0;
}

bool World::setBlock(int x, int y, int z, BlockState s, int flags) {
    if (y < WORLD_MIN_Y || y >= WORLD_MAX_Y) return false;
    Chunk* c = chunk(x >> 4, z >> 4);
    if (!c) return false;
    int lx = x & 15, lz = z & 15;
    BlockState old = c->get(lx, y, lz);
    if (old == s) return false;
    c->set(lx, y, lz, s);
    c->meshDirty = true;
    if (flags & SET_SAVE) c->modified = true;
    if (lx == 0) { if (Chunk* n = chunk((x >> 4) - 1, z >> 4)) n->meshDirty = true; }
    if (lx == 15) { if (Chunk* n = chunk((x >> 4) + 1, z >> 4)) n->meshDirty = true; }
    if (lz == 0) { if (Chunk* n = chunk(x >> 4, (z >> 4) - 1)) n->meshDirty = true; }
    if (lz == 15) { if (Chunk* n = chunk(x >> 4, (z >> 4) + 1)) n->meshDirty = true; }
    BlockPos p(x, y, z);
    if ((flags & SET_LIGHT) && c->hasLight()) light_->onBlockChanged(p, old, s);
    if (onBlockChanged) onBlockChanged(p, old, s);
    if (flags & SET_NOTIFY) {
        const BlockInfo& nb = blockOf(s);
        if (nb.fluid) {
            scheduleTick(p, fluids_->tickDelay(stateId(s)), TickType::Fluid);
            if (stateId(s) == B::LAVA) fluids_->lavaReact(p);
        }
        if (nb.gravity) scheduleTick(p, 2, TickType::Falling);
        updateNeighborsOf(p);
    }
    return true;
}

bool World::canSurvive(const BlockPos& p, BlockState s) const {
    const BlockInfo& b = blockOf(s);
    BlockId below = stateId(getBlock(p.x, p.y - 1, p.z));
    const BlockInfo& bb = Blocks::get(below);
    auto isDirtLike = [&](BlockId id) { return id == B::GRASS_BLOCK || id == B::DIRT || id == B::PODZOL || id == B::MYCELIUM || id == B::FARMLAND || id == B::MOSS_BLOCK; };
    if (b.id == B::CACTUS) return below == B::SAND || below == B::RED_SAND || below == B::CACTUS;
    if (b.id == B::SUGAR_CANE) return isDirtLike(below) || below == B::SAND || below == B::RED_SAND || below == B::SUGAR_CANE;
    if (b.id == B::LILY_PAD) return below == B::WATER && stateMeta(getBlock(p.x, p.y - 1, p.z)) == 0;
    if (b.id == B::DEAD_BUSH) return isDirtLike(below) || below == B::SAND || below == B::RED_SAND || below == B::TERRACOTTA || below == B::ORANGE_TERRACOTTA || below == B::RED_TERRACOTTA;
    if (b.id == B::BROWN_MUSHROOM || b.id == B::RED_MUSHROOM) return bb.solid;
    if (b.id == B::TORCH) return bb.solid && bb.shape == Shape::Cube;
    if (b.id == B::SNOW_LAYER) return bb.solid && below != B::ICE && below != B::PACKED_ICE;
    if (b.id == B::COBWEB) return true;
    if (b.plant) return isDirtLike(below);
    return true;
}

void World::updateNeighborsOf(const BlockPos& p) {
    for (int d = -1; d < 6; ++d) {
        BlockPos n = d < 0 ? p : BlockPos(p.x + DIR_DX[d], p.y + DIR_DY[d], p.z + DIR_DZ[d]);
        if (n.y < WORLD_MIN_Y || n.y >= WORLD_MAX_Y) continue;
        Chunk* c = chunk(n.x >> 4, n.z >> 4); if (!c) continue;
        BlockState s = c->get(n.x & 15, n.y, n.z & 15);
        const BlockInfo& b = blockOf(s);
        if (s == 0) continue;
        if (b.fluid) {
            if (stateId(s) == B::LAVA && fluids_->lavaReact(n)) continue;
            scheduleTick(n, fluids_->tickDelay(stateId(s)), TickType::Fluid);
        } else if (b.gravity) scheduleTick(n, 2, TickType::Falling);
        else if ((b.plant || b.id == B::TORCH || b.id == B::SNOW_LAYER || b.id == B::CACTUS || b.id == B::LILY_PAD) && !canSurvive(n, s)) {
            if (onBlockBroken) onBlockBroken(n, s);
            setBlock(n, 0, SET_ALL);
        }
    }
}

void World::scheduleTick(const BlockPos& p, int delay, TickType type) {
    uint64_t key = packPos(p);
    auto& set = g_tickKeys[(int)type];
    if (!set.insert(key).second) return;
    ticks_.push({gameTime + (uint64_t)std::max(1, delay), seq_++, p, type});
}

void World::runTick(const ScheduledTick& t) {
    if (t.type == TickType::Fluid) fluids_->tick(t.pos);
    else if (t.type == TickType::Falling) {
        BlockState s = getBlock(t.pos);
        if (!blockOf(s).gravity) return;
        BlockPos below(t.pos.x, t.pos.y - 1, t.pos.z);
        if (below.y < WORLD_MIN_Y) return;
        BlockState bs = getBlock(below); const BlockInfo& bi = blockOf(bs);
        if (bs == 0 || bi.fluid || bi.replaceable || bi.plant || (!bi.solid && bi.shape != Shape::Cube)) {
            if (bs != 0 && !bi.fluid && onBlockBroken) onBlockBroken(below, bs);
            setBlock(t.pos, 0, SET_ALL);
            setBlock(below, s, SET_ALL);
        }
    }
}

void World::tick() {
    ++gameTime;
    int budget = 4096;
    while (!ticks_.empty() && ticks_.top().time <= gameTime && budget-- > 0) {
        ScheduledTick t = ticks_.top(); ticks_.pop();
        g_tickKeys[(int)t.type].erase(packPos(t.pos));
        if (!chunk(t.pos.x >> 4, t.pos.z >> 4)) continue;
        runTick(t);
    }
}

} // namespace mc
