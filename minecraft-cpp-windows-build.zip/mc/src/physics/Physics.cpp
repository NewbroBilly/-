#include "Physics.h"

namespace mc {

void collectCollisions(const World& w, const AABB& r, std::vector<AABB>& out) {
    int x0 = floorInt(r.x0), x1 = floorInt(r.x1), y0 = floorInt(r.y0), y1 = floorInt(r.y1), z0 = floorInt(r.z0), z1 = floorInt(r.z1);
    for (int y = y0; y <= y1; ++y) for (int z = z0; z <= z1; ++z) for (int x = x0; x <= x1; ++x) {
        BlockState s = w.getBlock(x, y, z);
        if (s == 0) continue;
        float b[6]; if (!Blocks::getCollisionBox(s, b)) continue;
        AABB a(x + b[0], y + b[1], z + b[2], x + b[3], y + b[4], z + b[5]);
        if (a.intersects(r)) out.push_back(a);
    }
}
bool hasCollision(const World& w, const AABB& box) { std::vector<AABB> l; collectCollisions(w, box, l); return !l.empty(); }

static double clipY(const std::vector<AABB>& l, const AABB& b, double d) {
    for (const AABB& o : l) {
        if (b.x1 <= o.x0 || b.x0 >= o.x1 || b.z1 <= o.z0 || b.z0 >= o.z1) continue;
        if (d > 0 && b.y1 <= o.y0 + 1e-7) d = std::min(d, o.y0 - b.y1);
        else if (d < 0 && b.y0 >= o.y1 - 1e-7) d = std::max(d, o.y1 - b.y0);
    }
    return d;
}
static double clipX(const std::vector<AABB>& l, const AABB& b, double d) {
    for (const AABB& o : l) {
        if (b.y1 <= o.y0 || b.y0 >= o.y1 || b.z1 <= o.z0 || b.z0 >= o.z1) continue;
        if (d > 0 && b.x1 <= o.x0 + 1e-7) d = std::min(d, o.x0 - b.x1);
        else if (d < 0 && b.x0 >= o.x1 - 1e-7) d = std::max(d, o.x1 - b.x0);
    }
    return d;
}
static double clipZ(const std::vector<AABB>& l, const AABB& b, double d) {
    for (const AABB& o : l) {
        if (b.x1 <= o.x0 || b.x0 >= o.x1 || b.y1 <= o.y0 || b.y0 >= o.y1) continue;
        if (d > 0 && b.z1 <= o.z0 + 1e-7) d = std::min(d, o.z0 - b.z1);
        else if (d < 0 && b.z0 >= o.z1 - 1e-7) d = std::max(d, o.z1 - b.z0);
    }
    return d;
}

MoveResult moveEntity(const World& w, AABB& box, Vec3d d, double stepH, bool sneakEdge, bool wasOnGround) {
    MoveResult res;
    if (sneakEdge && wasOnGround) {
        const double st = 0.05;
        while (d.x != 0 && !hasCollision(w, box.offset(d.x, -stepH, 0))) { if (d.x < st && d.x >= -st) d.x = 0; else if (d.x > 0) d.x -= st; else d.x += st; }
        while (d.z != 0 && !hasCollision(w, box.offset(0, -stepH, d.z))) { if (d.z < st && d.z >= -st) d.z = 0; else if (d.z > 0) d.z -= st; else d.z += st; }
        while (d.x != 0 && d.z != 0 && !hasCollision(w, box.offset(d.x, -stepH, d.z))) {
            if (d.x < st && d.x >= -st) d.x = 0; else if (d.x > 0) d.x -= st; else d.x += st;
            if (d.z < st && d.z >= -st) d.z = 0; else if (d.z > 0) d.z -= st; else d.z += st;
        }
    }
    std::vector<AABB> list;
    AABB before = box;
    collectCollisions(w, box.expand(d.x, std::max(d.y, 0.0) + stepH, d.z).expand(0, std::min(d.y, 0.0) - stepH, 0), list);
    Vec3d r = d;
    r.y = clipY(list, box, d.y); box = box.offset(0, r.y, 0);
    r.x = clipX(list, box, d.x); box = box.offset(r.x, 0, 0);
    r.z = clipZ(list, box, d.z); box = box.offset(0, 0, r.z);
    bool ground = (d.y < 0 && r.y != d.y);
    if (stepH > 0 && (wasOnGround || ground) && (r.x != d.x || r.z != d.z)) {
        AABB b2 = before;
        double up = clipY(list, b2, stepH); b2 = b2.offset(0, up, 0);
        double sx = clipX(list, b2, d.x); b2 = b2.offset(sx, 0, 0);
        double sz = clipZ(list, b2, d.z); b2 = b2.offset(0, 0, sz);
        double down = clipY(list, b2, -up); b2 = b2.offset(0, down, 0);
        if (sx * sx + sz * sz > r.x * r.x + r.z * r.z) { box = b2; r = Vec3d(sx, up + down, sz); ground = true; }
    }
    res.hitX = r.x != d.x; res.hitY = r.y != d.y; res.hitZ = r.z != d.z;
    res.onGround = ground; res.moved = r;
    return res;
}

static bool rayBox(const Vec3d& o, const Vec3d& d, const double b[6], double& tOut, int& face) {
    double tmin = 0, tmax = 1e30; int f = -1;
    const double oo[3] = {o.x, o.y, o.z}, dd[3] = {d.x, d.y, d.z};
    for (int a = 0; a < 3; ++a) {
        if (std::fabs(dd[a]) < 1e-12) { if (oo[a] < b[a] || oo[a] > b[a + 3]) return false; continue; }
        double t1 = (b[a] - oo[a]) / dd[a], t2 = (b[a + 3] - oo[a]) / dd[a]; int fa = dd[a] > 0 ? a * 2 + 1 : a * 2;
        if (t1 > t2) std::swap(t1, t2);
        if (t1 > tmin) { tmin = t1; f = fa; }
        tmax = std::min(tmax, t2);
        if (tmin > tmax) return false;
    }
    tOut = tmin; face = f < 0 ? 0 : f; return true;
}

RayHit raycastBlocks(const World& w, const Vec3d& o, const Vec3d& dir, double maxDist, bool hitFluids) {
    RayHit out;
    double len = dir.length(); if (len < 1e-9) return out;
    Vec3d d = dir * (1.0 / len);
    int x = floorInt(o.x), y = floorInt(o.y), z = floorInt(o.z);
    int sx = d.x > 0 ? 1 : -1, sy = d.y > 0 ? 1 : -1, sz = d.z > 0 ? 1 : -1;
    double tdx = d.x != 0 ? std::fabs(1.0 / d.x) : 1e30, tdy = d.y != 0 ? std::fabs(1.0 / d.y) : 1e30, tdz = d.z != 0 ? std::fabs(1.0 / d.z) : 1e30;
    double tmx = d.x > 0 ? (x + 1 - o.x) * tdx : (o.x - x) * tdx;
    double tmy = d.y > 0 ? (y + 1 - o.y) * tdy : (o.y - y) * tdy;
    double tmz = d.z > 0 ? (z + 1 - o.z) * tdz : (o.z - z) * tdz;
    double t = 0;
    for (int i = 0; i < 256 && t <= maxDist; ++i) {
        BlockState s = w.getBlock(x, y, z);
        const BlockInfo& b = blockOf(s);
        if (s != 0 && ((b.targetable) || (hitFluids && b.fluid))) {
            float bb[6]; double box[6];
            if (b.shape == Shape::Box && Blocks::getBox(s, bb)) { for (int k = 0; k < 6; ++k) box[k] = (k % 3 == 0 ? x : k % 3 == 1 ? y : z) + bb[k]; }
            else if (b.shape == Shape::Cross) { box[0] = x + 0.15; box[1] = y; box[2] = z + 0.15; box[3] = x + 0.85; box[4] = y + 0.8; box[5] = z + 0.85; }
            else { box[0] = x; box[1] = y; box[2] = z; box[3] = x + 1; box[4] = y + 1; box[5] = z + 1; }
            double tt; int face;
            if (rayBox(o, d, box, tt, face) && tt <= maxDist) { out.hit = true; out.pos = BlockPos(x, y, z); out.face = face; out.dist = tt; out.point = o + d * tt; return out; }
        }
        if (tmx < tmy && tmx < tmz) { x += sx; t = tmx; tmx += tdx; }
        else if (tmy < tmz) { y += sy; t = tmy; tmy += tdy; }
        else { z += sz; t = tmz; tmz += tdz; }
    }
    return out;
}

} // namespace mc
