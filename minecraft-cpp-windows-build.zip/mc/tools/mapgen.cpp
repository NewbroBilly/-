// Developer tool: renders biome map, cross-section and cave slices of a seed to PPM files; prints stats.
#include "../src/terrain/TerrainGenerator.h"
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <vector>
using namespace mc;

static void writePPM(const char* path, int w, int h, const std::vector<uint8_t>& rgb) {
    FILE* f = fopen(path, "wb"); fprintf(f, "P6\n%d %d\n255\n", w, h); fwrite(rgb.data(), 1, rgb.size(), f); fclose(f);
}
static void col(Biome b, uint8_t* o) {
    static const uint32_t C[] = {0x2a4fa8, 0x15306e, 0xa8c8ee, 0x3fc7d6, 0x4f86d6, 0xb6d4f5, 0xe8dca0, 0x8ab55a, 0x3f8a2f, 0x6aa84f, 0x2f6b4f, 0xcfe8e0, 0xf2f6f8, 0xe3cf7a, 0xb8a847, 0x1f9d1f, 0x5a6b3a, 0x909090, 0xffffff, 0xb050b0, 0xc85a2a};
    uint32_t c = C[(int)b]; o[0] = (c >> 16) & 255; o[1] = (c >> 8) & 255; o[2] = c & 255;
}
int main(int argc, char** argv) {
    uint64_t seed = argc > 1 ? strtoull(argv[1], 0, 10) : 12345;
    const char* out = argc > 2 ? argv[2] : "/tmp/map";
    Blocks::init();
    TerrainGenerator tg(seed);
    // biome map 6144x6144 blocks, step 12
    const int N = 512, STEP = 12;
    std::vector<uint8_t> img(N * N * 3);
    std::map<int, long> cnt; long total = 0;
    for (int j = 0; j < N; ++j) for (int i = 0; i < N; ++i) {
        ColumnInfo c = tg.column((i - N / 2) * STEP, (j - N / 2) * STEP);
        uint8_t* p = &img[(j * N + i) * 3]; col(c.biome, p);
        double sh = clampv((c.height - 63.0) / 120.0, -0.25, 0.4);
        for (int k = 0; k < 3; ++k) p[k] = (uint8_t)clampv(p[k] * (1.0 + sh), 0.0, 255.0);
        cnt[(int)c.biome]++; total++;
    }
    writePPM((std::string(out) + "_biomes.ppm").c_str(), N, N, img);
    printf("biome share:\n"); for (auto& kv : cnt) printf("  %-16s %5.1f%%\n", biomeInfo((Biome)kv.first).name, 100.0 * kv.second / total);
    // chunk generation timing + slices: 32x32 chunks starting at (0,0)
    const int CH = 32; std::vector<Chunk*> chunks(CH * CH);
    auto t0 = std::chrono::steady_clock::now();
    for (int cz = 0; cz < CH; ++cz) for (int cx = 0; cx < CH; ++cx) { chunks[cz * CH + cx] = new Chunk(cx, cz); tg.generate(*chunks[cz * CH + cx]); }
    double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    printf("generated %d chunks in %.0f ms (%.2f ms/chunk)\n", CH * CH, ms, ms / (CH * CH));
    auto get = [&](int x, int y, int z) { return chunks[(z >> 4) * CH + (x >> 4)]->get(x & 15, y, z & 15); };
    auto colorOf = [&](BlockState s, uint8_t* o) {
        BlockId id = stateId(s); uint32_t c = 0xCFE4FF;
        if (id == B::STONE) c = 0x808080; else if (id == B::DEEPSLATE) c = 0x3c3c44; else if (id == B::WATER) c = 0x2a50c8; else if (id == B::LAVA) c = 0xff7a10;
        else if (id == B::GRASS_BLOCK) c = 0x4caf3a; else if (id == B::DIRT) c = 0x7a5530; else if (id == B::SAND || id == B::SANDSTONE) c = 0xe0d080; else if (id == B::GRAVEL) c = 0x9a9590;
        else if (id == B::BEDROCK) c = 0x101010; else if (id == B::SNOW_BLOCK || id == B::SNOW_LAYER) c = 0xffffff; else if (id == B::ICE) c = 0xa0c8ff; else if (id == B::CLAY) c = 0xa0a8b8;
        else if (id != 0) c = 0xb06040;
        o[0] = (c >> 16) & 255; o[1] = (c >> 8) & 255; o[2] = c & 255;
    };
    // cross-section along x at z=256, y -64..255
    { int W = 512, Hh = 320; std::vector<uint8_t> s(W * Hh * 3);
      for (int y = 0; y < Hh; ++y) for (int x = 0; x < W; ++x) colorOf(get(x, 255 - y, 256), &s[(y * W + x) * 3]);
      writePPM((std::string(out) + "_xsec.ppm").c_str(), W, Hh, s); }
    // horizontal slices
    for (int yy : {10, -30}) { int W = CH * 16; std::vector<uint8_t> s(W * W * 3);
      for (int z = 0; z < W; ++z) for (int x = 0; x < W; ++x) colorOf(get(x, yy, z), &s[(z * W + x) * 3]);
      writePPM((std::string(out) + "_slice" + std::to_string(yy) + ".ppm").c_str(), W, W, s); }
    // cave volume fraction below y=50
    long air = 0, tot = 0;
    for (int z = 0; z < CH * 16; z += 2) for (int x = 0; x < CH * 16; x += 2) for (int y = -60; y < 50; y += 2) { ++tot; if (get(x, y, z) == 0) ++air; }
    printf("air fraction below y=50: %.2f%%\n", 100.0 * air / tot);
    return 0;
}
