#include "game/Game.h"
#include <cstdio>
#include <cstring>
#include <filesystem>

int main(int argc, char** argv) {
    std::string assets = "assets", saves = "saves";
    for (int i = 1; i < argc; ++i) {
        if (!std::strcmp(argv[i], "--assets") && i + 1 < argc) assets = argv[++i];
        else if (!std::strcmp(argv[i], "--saves") && i + 1 < argc) saves = argv[++i];
    }
    if (!std::filesystem::exists(assets)) { std::fprintf(stderr, "Assets folder '%s' not found. Run the game from the project directory or pass --assets <dir>.\n", assets.c_str()); return 1; }
    mc::Game g(assets, saves);
    return g.run();
}
