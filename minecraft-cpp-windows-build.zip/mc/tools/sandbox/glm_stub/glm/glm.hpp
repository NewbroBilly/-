// Minimal stand-in for GLM used ONLY to compile/test inside sandboxes without GLM installed.
// Implements the exact semantics (column-major, right-handed, [-1,1] depth) of the few functions the project uses.
#pragma once
#include <cmath>
namespace glm {
struct vec2 { float x = 0, y = 0; vec2() = default; vec2(float a, float b) : x(a), y(b) {} };
struct vec3 { float x = 0, y = 0, z = 0; vec3() = default; explicit vec3(float a) : x(a), y(a), z(a) {} vec3(float a, float b, float c) : x(a), y(b), z(c) {}
    vec3 operator+(const vec3& o) const { return {x + o.x, y + o.y, z + o.z}; } vec3 operator-(const vec3& o) const { return {x - o.x, y - o.y, z - o.z}; }
    vec3 operator*(float s) const { return {x * s, y * s, z * s}; } vec3 operator-() const { return {-x, -y, -z}; } };
struct vec4 { float x = 0, y = 0, z = 0, w = 0; vec4() = default; vec4(float a, float b, float c, float d) : x(a), y(b), z(c), w(d) {} vec4(const vec3& v, float d) : x(v.x), y(v.y), z(v.z), w(d) {} };
struct mat4 { float m[4][4]; mat4() { for (int i = 0; i < 4; ++i) for (int j = 0; j < 4; ++j) m[i][j] = i == j ? 1.f : 0.f; } explicit mat4(float d) { for (int i = 0; i < 4; ++i) for (int j = 0; j < 4; ++j) m[i][j] = i == j ? d : 0.f; }
    float* operator[](int c) { return m[c]; } const float* operator[](int c) const { return m[c]; } };
inline mat4 operator*(const mat4& a, const mat4& b) { mat4 r(0.f); for (int c = 0; c < 4; ++c) for (int rI = 0; rI < 4; ++rI) { float s = 0; for (int k = 0; k < 4; ++k) s += a.m[k][rI] * b.m[c][k]; r.m[c][rI] = s; } return r; }
inline vec4 operator*(const mat4& a, const vec4& v) { float in[4] = {v.x, v.y, v.z, v.w}, o[4]; for (int r = 0; r < 4; ++r) { o[r] = 0; for (int k = 0; k < 4; ++k) o[r] += a.m[k][r] * in[k]; } return {o[0], o[1], o[2], o[3]}; }
inline float radians(float d) { return d * 0.017453292519943295f; }
inline float dot(const vec3& a, const vec3& b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline float length(const vec3& a) { return std::sqrt(dot(a, a)); }
inline vec3 normalize(const vec3& a) { float l = length(a); return l > 0 ? a * (1.0f / l) : a; }
inline vec3 cross(const vec3& a, const vec3& b) { return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
inline mat4 translate(const mat4& m, const vec3& v) { mat4 r = m; for (int i = 0; i < 4; ++i) r.m[3][i] = m.m[0][i] * v.x + m.m[1][i] * v.y + m.m[2][i] * v.z + m.m[3][i]; return r; }
inline mat4 perspective(float fovy, float aspect, float zn, float zf) { float t = std::tan(fovy / 2); mat4 r(0.f); r.m[0][0] = 1 / (aspect * t); r.m[1][1] = 1 / t; r.m[2][2] = -(zf + zn) / (zf - zn); r.m[2][3] = -1; r.m[3][2] = -(2 * zf * zn) / (zf - zn); return r; }
inline mat4 ortho(float l, float r_, float b, float t, float, float) { mat4 r; r.m[0][0] = 2 / (r_ - l); r.m[1][1] = 2 / (t - b); r.m[2][2] = -1; r.m[3][0] = -(r_ + l) / (r_ - l); r.m[3][1] = -(t + b) / (t - b); return r; }
inline mat4 lookAt(const vec3& eye, const vec3& c, const vec3& up) { vec3 f = normalize(c - eye), s = normalize(cross(f, up)), u = cross(s, f); mat4 r;
    r.m[0][0] = s.x; r.m[1][0] = s.y; r.m[2][0] = s.z; r.m[0][1] = u.x; r.m[1][1] = u.y; r.m[2][1] = u.z; r.m[0][2] = -f.x; r.m[1][2] = -f.y; r.m[2][2] = -f.z;
    r.m[3][0] = -dot(s, eye); r.m[3][1] = -dot(u, eye); r.m[3][2] = dot(f, eye); return r; }
inline mat4 inverse(const mat4& mm) { const float* m = &mm.m[0][0]; float inv[16], det; 
    inv[0] = m[5]*m[10]*m[15]-m[5]*m[11]*m[14]-m[9]*m[6]*m[15]+m[9]*m[7]*m[14]+m[13]*m[6]*m[11]-m[13]*m[7]*m[10];
    inv[4] = -m[4]*m[10]*m[15]+m[4]*m[11]*m[14]+m[8]*m[6]*m[15]-m[8]*m[7]*m[14]-m[12]*m[6]*m[11]+m[12]*m[7]*m[10];
    inv[8] = m[4]*m[9]*m[15]-m[4]*m[11]*m[13]-m[8]*m[5]*m[15]+m[8]*m[7]*m[13]+m[12]*m[5]*m[11]-m[12]*m[7]*m[9];
    inv[12] = -m[4]*m[9]*m[14]+m[4]*m[10]*m[13]+m[8]*m[5]*m[14]-m[8]*m[6]*m[13]-m[12]*m[5]*m[10]+m[12]*m[6]*m[9];
    inv[1] = -m[1]*m[10]*m[15]+m[1]*m[11]*m[14]+m[9]*m[2]*m[15]-m[9]*m[3]*m[14]-m[13]*m[2]*m[11]+m[13]*m[3]*m[10];
    inv[5] = m[0]*m[10]*m[15]-m[0]*m[11]*m[14]-m[8]*m[2]*m[15]+m[8]*m[3]*m[14]+m[12]*m[2]*m[11]-m[12]*m[3]*m[10];
    inv[9] = -m[0]*m[9]*m[15]+m[0]*m[11]*m[13]+m[8]*m[1]*m[15]-m[8]*m[3]*m[13]-m[12]*m[1]*m[11]+m[12]*m[3]*m[9];
    inv[13] = m[0]*m[9]*m[14]-m[0]*m[10]*m[13]-m[8]*m[1]*m[14]+m[8]*m[2]*m[13]+m[12]*m[1]*m[10]-m[12]*m[2]*m[9];
    inv[2] = m[1]*m[6]*m[15]-m[1]*m[7]*m[14]-m[5]*m[2]*m[15]+m[5]*m[3]*m[14]+m[13]*m[2]*m[7]-m[13]*m[3]*m[6];
    inv[6] = -m[0]*m[6]*m[15]+m[0]*m[7]*m[14]+m[4]*m[2]*m[15]-m[4]*m[3]*m[14]-m[12]*m[2]*m[7]+m[12]*m[3]*m[6];
    inv[10] = m[0]*m[5]*m[15]-m[0]*m[7]*m[13]-m[4]*m[1]*m[15]+m[4]*m[3]*m[13]+m[12]*m[1]*m[7]-m[12]*m[3]*m[5];
    inv[14] = -m[0]*m[5]*m[14]+m[0]*m[6]*m[13]+m[4]*m[1]*m[14]-m[4]*m[2]*m[13]-m[12]*m[1]*m[6]+m[12]*m[2]*m[5];
    inv[3] = -m[1]*m[6]*m[11]+m[1]*m[7]*m[10]+m[5]*m[2]*m[11]-m[5]*m[3]*m[10]-m[9]*m[2]*m[7]+m[9]*m[3]*m[6];
    inv[7] = m[0]*m[6]*m[11]-m[0]*m[7]*m[10]-m[4]*m[2]*m[11]+m[4]*m[3]*m[10]+m[8]*m[2]*m[7]-m[8]*m[3]*m[6];
    inv[11] = -m[0]*m[5]*m[11]+m[0]*m[7]*m[9]+m[4]*m[1]*m[11]-m[4]*m[3]*m[9]-m[8]*m[1]*m[7]+m[8]*m[3]*m[5];
    inv[15] = m[0]*m[5]*m[10]-m[0]*m[6]*m[9]-m[4]*m[1]*m[10]+m[4]*m[2]*m[9]+m[8]*m[1]*m[6]-m[8]*m[2]*m[5];
    det = m[0]*inv[0]+m[1]*inv[4]+m[2]*inv[8]+m[3]*inv[12]; mat4 r; if (det == 0) return r; det = 1.0f / det; for (int i = 0; i < 16; ++i) (&r.m[0][0])[i] = inv[i] * det; return r; }
inline const float* value_ptr(const mat4& m) { return &m.m[0][0]; }
inline const float* value_ptr(const vec3& v) { return &v.x; }
}
