#include "LightEngine.h"

namespace mc {

static inline int opacityOf(BlockState s) { return Blocks::get(stateId(s)).lightOpacity; }

int LightEngine::getSky(int x, int y, int z) const {
    if (y >= WORLD_MAX_Y) return 15;
    if (y < WORLD_MIN_Y) return 0;
    Chunk* c = world_.chunk(x >> 4, z >> 4); return c ? c->skyLight(x & 15, y, z & 15) : 0;
}
int LightEngine::getBlk(int x, int y, int z) const {
    if (y < WORLD_MIN_Y || y >= WORLD_MAX_Y) return 0;
    Chunk* c = world_.chunk(x >> 4, z >> 4); return c ? c->blockLight(x & 15, y, z & 15) : 0;
}
void LightEngine::touch(int x, int z) {
    Chunk* c = world_.chunk(x >> 4, z >> 4); if (c) c->meshDirty = true;
    int lx = x & 15, lz = z & 15;
    if (lx == 0) { if (Chunk* n = world_.chunk((x >> 4) - 1, z >> 4)) n->meshDirty = true; }
    if (lx == 15) { if (Chunk* n = world_.chunk((x >> 4) + 1, z >> 4)) n->meshDirty = true; }
    if (lz == 0) { if (Chunk* n = world_.chunk(x >> 4, (z >> 4) - 1)) n->meshDirty = true; }
    if (lz == 15) { if (Chunk* n = world_.chunk(x >> 4, (z >> 4) + 1)) n->meshDirty = true; }
}
void LightEngine::setSky(int x, int y, int z, int v) {
    Chunk* c = world_.chunk(x >> 4, z >> 4); if (!c || !c->hasLight()) return;
    uint8_t r = c->lightRaw(x & 15, y, z & 15);
    c->setLightRaw(x & 15, y, z & 15, (uint8_t)((r & 15) | (v << 4)));
    touch(x, z);
}
void LightEngine::setBlk(int x, int y, int z, int v) {
    Chunk* c = world_.chunk(x >> 4, z >> 4); if (!c || !c->hasLight()) return;
    uint8_t r = c->lightRaw(x & 15, y, z & 15);
    c->setLightRaw(x & 15, y, z & 15, (uint8_t)((r & 0xF0) | v));
    touch(x, z);
}

void LightEngine::floodAdd(std::vector<Node>& q, bool sky) {
    size_t head = 0;
    while (head < q.size()) {
        Node n = q[head++];
        int cur = sky ? getSky(n.x, n.y, n.z) : getBlk(n.x, n.y, n.z);
        if (cur <= 1 && !(sky && cur == 1)) { if (cur <= 1) continue; }
        for (int d = 0; d < 6; ++d) {
            int x = n.x + DIR_DX[d], y = n.y + DIR_DY[d], z = n.z + DIR_DZ[d];
            if (y < WORLD_MIN_Y || y >= WORLD_MAX_Y) continue;
            Chunk* c = world_.chunk(x >> 4, z >> 4);
            if (!c || !c->hasLight()) continue;
            int op = opacityOf(c->get(x & 15, y, z & 15));
            if (op >= 15) continue;
            int nl = (sky && d == DIR_DOWN && cur == 15 && op == 0) ? 15 : cur - std::max(1, op);
            int have = sky ? c->skyLight(x & 15, y, z & 15) : c->blockLight(x & 15, y, z & 15);
            if (nl > have) { if (sky) setSky(x, y, z, nl); else setBlk(x, y, z, nl); q.push_back({x, y, z, (uint8_t)nl}); }
        }
        if (head > 4096 && head * 2 > q.size()) { q.erase(q.begin(), q.begin() + (long)head); head = 0; }
    }
    q.clear();
}

void LightEngine::floodRemove(std::vector<Node>& rq, std::vector<Node>& addQ, bool sky) {
    size_t head = 0;
    while (head < rq.size()) {
        Node n = rq[head++];
        for (int d = 0; d < 6; ++d) {
            int x = n.x + DIR_DX[d], y = n.y + DIR_DY[d], z = n.z + DIR_DZ[d];
            if (y < WORLD_MIN_Y || y >= WORLD_MAX_Y) continue;
            Chunk* c = world_.chunk(x >> 4, z >> 4);
            if (!c || !c->hasLight()) continue;
            int nl = sky ? c->skyLight(x & 15, y, z & 15) : c->blockLight(x & 15, y, z & 15);
            if (nl == 0) continue;
            if (nl < n.level || (sky && d == DIR_DOWN && n.level == 15 && nl == 15)) {
                if (sky) setSky(x, y, z, 0); else setBlk(x, y, z, 0);
                rq.push_back({x, y, z, (uint8_t)nl});
            } else addQ.push_back({x, y, z, (uint8_t)nl});
        }
    }
    rq.clear();
}

void LightEngine::onBlockChanged(const BlockPos& p, BlockState oldS, BlockState newS) {
    Chunk* c = world_.chunk(p.x >> 4, p.z >> 4);
    if (!c || !c->hasLight()) return;
    int lx = p.x & 15, lz = p.z & 15;
    int oldSky = c->skyLight(lx, p.y, lz), oldBlk = c->blockLight(lx, p.y, lz);
    (void)oldS;
    std::vector<Node> rs, rb, as, ab;
    int emission = Blocks::get(stateId(newS)).emission;
    if (oldSky > 0) { setSky(p.x, p.y, p.z, 0); rs.push_back({p.x, p.y, p.z, (uint8_t)oldSky}); }
    if (oldBlk > 0) { setBlk(p.x, p.y, p.z, 0); rb.push_back({p.x, p.y, p.z, (uint8_t)oldBlk}); }
    if (!rs.empty()) floodRemove(rs, as, true);
    if (!rb.empty()) floodRemove(rb, ab, false);
    if (emission > 0) { setBlk(p.x, p.y, p.z, emission); ab.push_back({p.x, p.y, p.z, (uint8_t)emission}); }
    for (int d = 0; d < 6; ++d) {
        int x = p.x + DIR_DX[d], y = p.y + DIR_DY[d], z = p.z + DIR_DZ[d];
        if (y < WORLD_MIN_Y) continue;
        if (y >= WORLD_MAX_Y) { as.push_back({x, y, z, 15}); continue; }
        if (getSky(x, y, z) > 0) as.push_back({x, y, z, (uint8_t)getSky(x, y, z)});
        if (getBlk(x, y, z) > 0) ab.push_back({x, y, z, (uint8_t)getBlk(x, y, z)});
    }
    // y above the world is a virtual full-sky layer: handle by seeding the top cell directly.
    if (p.y == WORLD_MAX_Y - 1 && opacityOf(newS) == 0) { setSky(p.x, p.y, p.z, 15); as.push_back({p.x, p.y, p.z, 15}); }
    floodAdd(as, true);
    floodAdd(ab, false);
    // The cell above an opaque block we removed may now see the sky through it.
    touch(p.x, p.z);
}

void LightEngine::initChunk(Chunk& c) {
    c.allocLight();
    const int bx = c.cx * 16, bz = c.cz * 16;
    int maxTop = WORLD_MIN_Y;
    for (int i = 0; i < 256; ++i) maxTop = std::max<int>(maxTop, c.lightTop[i]);
    int yTopScan = std::min(WORLD_MAX_Y - 1, maxTop + 1);
    std::vector<Node> sq, bq;
    // 1. sky columns
    for (int z = 0; z < 16; ++z) for (int x = 0; x < 16; ++x) {
        int level = 15;
        for (int y = WORLD_MAX_Y - 1; y > yTopScan; --y) c.setLightRaw(x, y, z, 15 << 4);
        for (int y = yTopScan; y >= WORLD_MIN_Y && level > 0; --y) {
            int op = opacityOf(c.get(x, y, z));
            level = std::max(0, level - op);
            c.setLightRaw(x, y, z, (uint8_t)(level << 4));
        }
    }
    // 2. block light sources
    for (int si = c.lowestNonEmptySection(); si <= c.highestNonEmptySection(); ++si) {
        if (c.sectionEmpty(si)) continue;
        const BlockState* d = c.sectionData(si);
        for (int i = 0; i < 4096; ++i) {
            if (!d[i]) continue;
            int em = Blocks::get(stateId(d[i])).emission;
            if (em > 0) {
                int x = i & 15, z = (i >> 4) & 15, y = WORLD_MIN_Y + si * 16 + (i >> 8);
                c.setLightRaw(x, y, z, (uint8_t)((c.lightRaw(x, y, z) & 0xF0) | em));
                bq.push_back({bx + x, y, bz + z, (uint8_t)em});
            }
        }
    }
    // 3. sky seeds: lit cells next to darker passable cells (inside the chunk or in already-lit neighbours)
    for (int y = WORLD_MIN_Y; y <= yTopScan; ++y) for (int z = 0; z < 16; ++z) for (int x = 0; x < 16; ++x) {
        int s = c.skyLight(x, y, z); if (s <= 1) continue;
        bool seed = false;
        for (int d = 0; d < 6 && !seed; ++d) {
            int nx = x + DIR_DX[d], ny = y + DIR_DY[d], nz = z + DIR_DZ[d];
            if (ny < WORLD_MIN_Y || ny >= WORLD_MAX_Y) continue;
            int ns;
            if (nx >= 0 && nx < 16 && nz >= 0 && nz < 16) { ns = c.skyLight(nx, ny, nz); if (ns < s - 1 && opacityOf(c.get(nx, ny, nz)) < 15) seed = true; }
            else {
                Chunk* o = world_.chunk((bx + nx) >> 4, (bz + nz) >> 4);
                if (o && o->hasLight()) { ns = o->skyLight(nx & 15, ny, nz & 15); if (ns < s - 1 && opacityOf(o->get(nx & 15, ny, nz & 15)) < 15) seed = true; }
            }
        }
        if (seed) sq.push_back({bx + x, y, bz + z, (uint8_t)s});
    }
    // 4. light flowing in from neighbouring lit chunks
    for (int d : HORIZ_DIRS) {
        Chunk* o = world_.chunk(c.cx + DIR_DX[d], c.cz + DIR_DZ[d]);
        if (!o || !o->hasLight()) continue;
        for (int t = 0; t < 16; ++t) for (int y = WORLD_MIN_Y; y < WORLD_MAX_Y; ++y) {
            int ox = d == DIR_EAST ? 0 : d == DIR_WEST ? 15 : t;
            int oz = d == DIR_SOUTH ? 0 : d == DIR_NORTH ? 15 : t;
            uint8_t r = o->lightRaw(ox, y, oz);
            if ((r >> 4) > 1) sq.push_back({o->cx * 16 + ox, y, o->cz * 16 + oz, (uint8_t)(r >> 4)});
            if ((r & 15) > 1) bq.push_back({o->cx * 16 + ox, y, o->cz * 16 + oz, (uint8_t)(r & 15)});
        }
    }
    floodAdd(sq, true);
    floodAdd(bq, false);
    c.meshDirty = true;
}

} // namespace mc
