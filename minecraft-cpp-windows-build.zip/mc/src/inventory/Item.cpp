#include "Item.h"
#include <cstring>

namespace mc {

std::vector<ItemInfo> Items::table_;
std::unordered_map<ItemId, size_t> Items::byId_;
static std::unordered_map<std::string, ItemId> g_itemByName;

ItemId Items::byName(const std::string& n) { auto it = g_itemByName.find(n); return it == g_itemByName.end() ? 0 : it->second; }

void Items::init() {
    if (!table_.empty()) return;
    Blocks::init();
    table_.reserve(1024);
    auto addRaw = [&](ItemId id, const std::string& name) -> ItemInfo& {
        table_.emplace_back(); ItemInfo& i = table_.back(); i.id = id; i.name = name; byId_[id] = table_.size() - 1; g_itemByName[name] = id; return i;
    };
    // every placeable block is an item with the same id
    for (int b = 1; b < Blocks::count(); ++b) {
        const BlockInfo& bi = Blocks::get((BlockId)b);
        if (bi.fluid) continue;
        ItemInfo& i = addRaw((ItemId)b, bi.name); i.block = (BlockId)b;
        // icon: sides for most blocks, the item-like texture for plants/torches
        i.texture = bi.tex[DIR_SOUTH];
        if (bi.shape == Shape::Cube && bi.tex[DIR_UP] != bi.tex[DIR_SOUTH]) i.texture = bi.tex[DIR_SOUTH];
    }
    ItemId next = ITEM_FIRST_NONBLOCK;
    auto mk = [&](const char* name, int stack = 64) -> ItemInfo& {
        ItemInfo& i = addRaw(next++, name); i.maxStack = stack; i.texture = Blocks::textureIndex(std::string("item/") + name); return i;
    };
    for (const char* n : {"stick", "coal", "charcoal", "raw_iron", "raw_gold", "raw_copper", "iron_ingot", "gold_ingot", "copper_ingot", "diamond", "emerald", "lapis_lazuli",
                          "redstone", "quartz", "flint", "string", "feather", "leather", "bone", "gunpowder", "clay_ball", "brick", "snowball", "book", "paper", "sugar", "egg",
                          "wheat", "wheat_seeds", "glowstone_dust", "prismarine_crystals", "ender_pearl", "bowl", "arrow", "nether_brick", "slime_ball", "blaze_rod"}) mk(n);
    mk("snowball", 16); mk("egg", 16); mk("ender_pearl", 16);
    // fuels
    auto setFuel = [&](const char* n, int f) { table_[byId_[byName(n)]].fuel = f; };
    setFuel("coal", 1600); setFuel("charcoal", 1600); setFuel("stick", 100); setFuel("blaze_rod", 2400);
    for (const char* n : {"oak_planks", "spruce_planks", "birch_planks", "jungle_planks", "acacia_planks", "dark_oak_planks", "oak_log", "spruce_log", "birch_log", "jungle_log", "acacia_log", "dark_oak_log", "crafting_table", "chest", "bookshelf", "ladder", "oak_slab"}) setFuel(n, n[0] == 'o' && std::strstr(n, "slab") ? 150 : 300);
    setFuel("coal_block", 16000);
    // food
    struct F { const char* n; int food; float sat; };
    for (F f : {F{"apple", 4, 2.4f}, F{"bread", 5, 6.0f}, F{"cooked_beef", 8, 12.8f}, F{"beef", 3, 1.8f}, F{"cooked_porkchop", 8, 12.8f}, F{"porkchop", 3, 1.8f},
                F{"cooked_chicken", 6, 7.2f}, F{"chicken", 2, 1.2f}, F{"cooked_mutton", 6, 9.6f}, F{"mutton", 2, 1.2f}, F{"cooked_rabbit", 5, 6.0f}, F{"rabbit", 3, 1.8f},
                F{"carrot", 3, 3.6f}, F{"potato", 1, 0.6f}, F{"baked_potato", 5, 6.0f}, F{"cookie", 2, 0.4f}, F{"melon_slice", 2, 1.2f}, F{"rotten_flesh", 4, 0.8f}, F{"golden_apple", 4, 9.6f}}) {
        ItemInfo& i = mk(f.n); i.food = (int)f.food; i.saturation = f.sat;
    }
    // tools: material tiers
    struct Tier { const char* n; int tier; float speed; int dur; float bonus; const char* matItem; };
    const Tier tiers[] = {{"wooden", 0, 2.0f, 59, 0.0f, nullptr}, {"stone", 1, 4.0f, 131, 1.0f, "cobblestone"}, {"iron", 2, 6.0f, 250, 2.0f, "iron_ingot"}, {"golden", 0, 12.0f, 32, 0.0f, "gold_ingot"}, {"diamond", 3, 8.0f, 1561, 3.0f, "diamond"}};
    struct Kind { const char* n; ToolType t; float base; };
    const Kind kinds[] = {{"pickaxe", ToolType::Pickaxe, 1.0f}, {"axe", ToolType::Axe, 6.0f}, {"shovel", ToolType::Shovel, 1.5f}, {"hoe", ToolType::Hoe, 0.0f}, {"sword", ToolType::Sword, 3.0f}};
    for (const Tier& t : tiers) for (const Kind& k : kinds) {
        std::string name = std::string(t.n) + "_" + k.n; ItemInfo& i = mk(name.c_str(), 1);
        i.tool = k.t; i.tier = t.tier; i.speed = t.speed; i.maxDamage = t.dur; i.attack = 1.0f + k.base + t.bonus;
        if (k.t == ToolType::Sword) i.speed = 1.0f;
        if (t.tier == 0 && !std::strcmp(t.n, "wooden")) i.fuel = 200;
    }
    { ItemInfo& i = mk("shears", 1); i.tool = ToolType::Shears; i.speed = 5.0f; i.maxDamage = 238; }
    { ItemInfo& i = mk("flint_and_steel", 1); i.maxDamage = 64; }
    { ItemInfo& i = mk("bow", 1); i.maxDamage = 384; }
    { ItemInfo& i = mk("bucket", 16); i.maxStack = 16; }
    { ItemInfo& i = mk("water_bucket", 1); i.fluidBucket = B::WATER; }
    { ItemInfo& i = mk("lava_bucket", 1); i.fluidBucket = B::LAVA; i.fuel = 20000; }
    // armor
    struct Mat { const char* n; int pts[4]; int dur; };   // boots, leggings, chestplate, helmet
    const Mat mats[] = {{"leather", {1, 2, 3, 1}, 5}, {"iron", {2, 5, 6, 2}, 15}, {"golden", {1, 3, 5, 2}, 7}, {"diamond", {3, 6, 8, 3}, 33}};
    const char* parts[4] = {"boots", "leggings", "chestplate", "helmet"}; const int base[4] = {65, 75, 80, 55};
    for (const Mat& m : mats) for (int s = 0; s < 4; ++s) {
        std::string name = std::string(m.n) + "_" + parts[s]; ItemInfo& i = mk(name.c_str(), 1);
        i.armorSlot = s; i.armorPoints = m.pts[s]; i.maxDamage = base[s] * m.dur / 5;
    }
}

bool Items::isTag(const std::string& tag, ItemId id) {
    const std::string& n = get(id).name;
    if (tag == "planks") return n.size() > 7 && n.compare(n.size() - 7, 7, "_planks") == 0;
    if (tag == "logs") return n.size() > 4 && n.compare(n.size() - 4, 4, "_log") == 0;
    if (tag == "coals") return n == "coal" || n == "charcoal";
    if (tag == "wool") return n.size() > 5 && n.compare(n.size() - 5, 5, "_wool") == 0;
    return n == tag;
}
void Items::tagMembers(const std::string& tag, std::vector<ItemId>& out) { for (const ItemInfo& i : table_) if (isTag(tag, i.id)) out.push_back(i.id); }

bool Items::canHarvest(const BlockInfo& b, const ItemStack& tool) {
    if (!b.requiresTool) return true;
    if (tool.empty()) return false;
    const ItemInfo& t = get(tool.id);
    return t.tool == b.tool && t.tier >= b.toolTier;
}

float Items::breakDelta(const BlockInfo& b, const ItemStack& tool, bool onGround, bool underwater) {
    if (b.hardness < 0) return 0.0f;
    if (b.hardness == 0) return 1.0f;
    float speed = 1.0f;
    if (!tool.empty()) {
        const ItemInfo& t = get(tool.id);
        if (t.tool != ToolType::None && t.tool == b.tool) speed = t.speed;
        else if (t.tool == ToolType::Shears && (b.material == Material::Leaves || b.material == Material::Cloth || b.id == B::COBWEB)) speed = b.id == B::COBWEB ? 15.0f : 5.0f;
        else if (t.tool == ToolType::Sword && (b.id == B::COBWEB)) speed = 15.0f;
    }
    if (underwater) speed /= 5.0f;
    if (!onGround) speed /= 5.0f;
    return speed / b.hardness / (canHarvest(b, tool) ? 30.0f : 100.0f);
}

void Items::rollDrops(const BlockInfo& b, const ItemStack& tool, Rng& rng, std::vector<ItemStack>& out) {
    if (b.dropItem == "-" && b.material != Material::Leaves) return;
    if (!canHarvest(b, tool)) return;
    bool shears = !tool.empty() && get(tool.id).tool == ToolType::Shears;
    if (b.material == Material::Leaves) {
        if (shears) { out.emplace_back((ItemId)b.id, 1); return; }
        std::string wood = b.name.substr(0, b.name.size() - 7);
        if (rng.chance(0.05)) { ItemId s = byName(wood + "_sapling"); if (s) out.emplace_back(s, 1); }
        if (rng.chance(0.02)) out.emplace_back(byName("stick"), 1 + rng.nextInt(2));
        if ((wood == "oak" || wood == "dark_oak") && rng.chance(0.005)) out.emplace_back(byName("apple"), 1);
        return;
    }
    if (b.id == B::GRAVEL && rng.chance(0.1)) { out.emplace_back(byName("flint"), 1); return; }
    if (b.id == B::GRASS || b.id == B::FERN) { if (shears) out.emplace_back((ItemId)b.id, 1); else if (rng.chance(0.125)) out.emplace_back(byName("wheat_seeds"), 1); return; }
    if (b.dropItem.empty()) { out.emplace_back((ItemId)b.id, 1); return; }
    ItemId it = byName(b.dropItem); if (!it) return;
    int n = b.dropMin + (b.dropMax > b.dropMin ? rng.nextInt(b.dropMax - b.dropMin + 1) : 0);
    if (n > 0) out.emplace_back(it, n);
}

} // namespace mc
