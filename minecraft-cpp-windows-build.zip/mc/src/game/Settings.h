#pragma once
// User settings (options.txt) and localisation (assets/lang/<code>.txt, key=value, UTF-8).
#include <string>
#include <unordered_map>

namespace mc {

struct Settings {
    std::string lang = "ru";
    int renderDistance = 10;        // chunks
    float fov = 70.0f;
    float sensitivity = 0.5f;
    float volume = 0.7f;
    int guiScale = 0;               // 0 = auto
    bool vsync = true, fullscreen = false, occlusion = true;
    void load(const std::string& path);
    void save(const std::string& path) const;
};

class Lang {
public:
    static void load(const std::string& assetDir, const std::string& code);
    static const std::string& tr(const std::string& key);
    static std::string trf(const std::string& key, const std::string& a);      // replaces %s
private:
    static std::unordered_map<std::string, std::string> map_;
};
inline const std::string& tr(const std::string& k) { return Lang::tr(k); }

} // namespace mc
