#include "Audio.h"
#include <algorithm>
#include <cctype>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <filesystem>

#if defined(MC_HAS_OPENAL) || __has_include(<AL/al.h>)
#include <AL/al.h>
#include <AL/alc.h>
#define MC_AUDIO_BACKEND 1
extern "C" int stb_vorbis_decode_filename(const char* filename, int* channels, int* sample_rate, short** output);
#else
#define MC_AUDIO_BACKEND 0
#endif

namespace fs = std::filesystem;
namespace mc {

const char* soundGroup(SoundType t) {
    switch (t) { case SoundType::Stone: return "stone"; case SoundType::Wood: return "wood"; case SoundType::Gravel: return "gravel"; case SoundType::Grass: return "grass";
        case SoundType::Sand: return "sand"; case SoundType::Glass: return "stone"; case SoundType::Cloth: return "cloth"; case SoundType::Snow: return "snow"; case SoundType::Metal: return "stone"; default: return ""; }
}

static std::string eventName(const std::string& rel) {            // "dig/stone1" -> "dig.stone"
    std::string s = rel; while (!s.empty() && std::isdigit((unsigned char)s.back())) s.pop_back();
    for (char& c : s) if (c == '/' || c == '\\') c = '.';
    return s;
}

bool AudioSystem::init(const std::string& assetDir) {
    dir_ = assetDir;
    std::error_code ec; fs::path root = fs::path(assetDir) / "sounds";
    if (fs::exists(root, ec)) for (auto& e : fs::recursive_directory_iterator(root, ec)) {
        if (!e.is_regular_file() || e.path().extension() != ".ogg") continue;
        std::string rel = fs::relative(e.path(), root, ec).generic_string(); rel = rel.substr(0, rel.size() - 4);
        events_[eventName(rel)].push_back(rel);
    }
    for (auto& kv : events_) std::sort(kv.second.begin(), kv.second.end());
#if MC_AUDIO_BACKEND
    ALCdevice* d = alcOpenDevice(nullptr); if (!d) { std::fprintf(stderr, "[audio] no audio device, sound disabled\n"); return false; }
    ALCcontext* c = alcCreateContext(d, nullptr); if (!c || !alcMakeContextCurrent(c)) return false;
    dev_ = d; ctx_ = c;
    for (int i = 0; i < 32; ++i) { ALuint s; alGenSources(1, &s); sources_.push_back(s); }
    ALuint m; alGenSources(1, &m); musicSource_ = m; alSourcef(m, AL_GAIN, 0.4f);
    ok_ = true;
#endif
    std::printf("[audio] %zu sound events indexed, backend %s\n", events_.size(), ok_ ? "OpenAL" : "disabled");
    return ok_;
}

void AudioSystem::shutdown() {
#if MC_AUDIO_BACKEND
    if (!ok_) return;
    for (unsigned s : sources_) { alSourceStop(s); ALuint x = s; alDeleteSources(1, &x); }
    for (auto& kv : buffers_) if (kv.second.loaded) { ALuint b = kv.second.id; alDeleteBuffers(1, &b); }
    alcMakeContextCurrent(nullptr); alcDestroyContext((ALCcontext*)ctx_); alcCloseDevice((ALCdevice*)dev_);
#endif
    ok_ = false;
}

unsigned AudioSystem::bufferFor(const std::string& rel) {
#if MC_AUDIO_BACKEND
    auto it = buffers_.find(rel); if (it != buffers_.end()) return it->second.id;
    Buf b; int ch = 0, rate = 0; short* pcm = nullptr;
    int n = stb_vorbis_decode_filename((dir_ + "/sounds/" + rel + ".ogg").c_str(), &ch, &rate, &pcm);
    if (n > 0 && pcm) {
        ALuint id; alGenBuffers(1, &id);
        if (ch == 2) { /* downmix to mono so 3D positioning works */ for (int i = 0; i < n; ++i) pcm[i] = (short)((pcm[i * 2] + pcm[i * 2 + 1]) / 2); }
        alBufferData(id, AL_FORMAT_MONO16, pcm, n * 2, rate); b.id = id; b.loaded = true; std::free(pcm);
    }
    buffers_[rel] = b; return b.id;
#else
    (void)rel; return 0;
#endif
}

unsigned AudioSystem::freeSource() {
#if MC_AUDIO_BACKEND
    for (unsigned s : sources_) { ALint st; alGetSourcei(s, AL_SOURCE_STATE, &st); if (st != 0x1012) return s; }
#endif
    return 0;
}

void AudioSystem::setListener(const Vec3d& p, float yawDeg) {
#if MC_AUDIO_BACKEND
    if (!ok_) return;
    float yaw = yawDeg * 0.0174533f; float ori[6] = {-std::sin(yaw), 0, std::cos(yaw), 0, 1, 0};
    alListener3f(0x1004, (float)p.x, (float)p.y, (float)p.z); alListenerfv(AL_ORIENTATION, ori);
#else
    (void)p; (void)yawDeg;
#endif
}

void AudioSystem::play(const std::string& event, double x, double y, double z, float vol, float pitch) {
#if MC_AUDIO_BACKEND
    if (!ok_) return; auto it = events_.find(event); if (it == events_.end() || it->second.empty()) return;
    rng_ = rng_ * 1664525u + 1013904223u; const std::string& file = it->second[(rng_ >> 8) % it->second.size()];
    unsigned buf = bufferFor(file), src = freeSource(); if (!buf || !src) return;
    alSourceStop(src); alSourcei(src, AL_BUFFER, (ALint)buf); alSourcef(src, AL_GAIN, vol * master_); alSourcef(src, AL_PITCH, pitch);
    alSourcei(src, AL_SOURCE_RELATIVE, AL_FALSE); alSource3f(src, AL_POSITION, (float)x, (float)y, (float)z);
    alSourcef(src, AL_REFERENCE_DISTANCE, 4.0f); alSourcef(src, AL_MAX_DISTANCE, 48.0f); alSourcef(src, AL_ROLLOFF_FACTOR, 1.0f); alSourcePlay(src);
#else
    (void)event; (void)x; (void)y; (void)z; (void)vol; (void)pitch;
#endif
}

void AudioSystem::play2D(const std::string& event, float vol, float pitch) {
#if MC_AUDIO_BACKEND
    if (!ok_) return; auto it = events_.find(event); if (it == events_.end() || it->second.empty()) return;
    rng_ = rng_ * 1664525u + 1013904223u; const std::string& file = it->second[(rng_ >> 8) % it->second.size()];
    unsigned buf = bufferFor(file), src = freeSource(); if (!buf || !src) return;
    alSourceStop(src); alSourcei(src, AL_BUFFER, (ALint)buf); alSourcef(src, AL_GAIN, vol * master_); alSourcef(src, AL_PITCH, pitch);
    alSourcei(src, AL_SOURCE_RELATIVE, AL_TRUE); alSource3f(src, AL_POSITION, 0, 0, 0); alSourcePlay(src);
#else
    (void)event; (void)vol; (void)pitch;
#endif
}

void AudioSystem::playBlock(const BlockInfo& b, const char* kind, double x, double y, double z, float vol) {
    if (b.material == Material::Glass && std::string(kind) == "dig") { play("random.glass", x, y, z, vol, 1.0f); return; }
    const char* g = soundGroup(b.sound); if (!*g) return;
    float pitch = 0.9f + (float)((rng_ = rng_ * 1664525u + 1013904223u) >> 16 & 255) / 255.0f * 0.25f;
    play(std::string(kind) + "." + g, x, y, z, std::string(kind) == "step" ? vol * 0.5f : vol, pitch);
}

void AudioSystem::startMusic(const std::string& group) { musicGroup_ = group; nextMusic_ = 0; }

void AudioSystem::update() {
#if MC_AUDIO_BACKEND
    if (!ok_ || musicGroup_.empty()) return;
    ALint st; alGetSourcei(musicSource_, AL_SOURCE_STATE, &st);
    double now = std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
    if (st == 0x1012 || now < nextMusic_) return;
    std::vector<std::string> tracks; std::error_code ec; fs::path d = fs::path(dir_) / "music" / musicGroup_;
    if (fs::exists(d, ec)) for (auto& e : fs::directory_iterator(d, ec)) if (e.path().extension() == ".ogg") tracks.push_back(("../music/" + musicGroup_ + "/" + e.path().stem().string()));
    nextMusic_ = now + 30 + (rng_ % 60);
    if (tracks.empty()) return;
    rng_ = rng_ * 1664525u + 1013904223u; unsigned buf = bufferFor(tracks[(rng_ >> 8) % tracks.size()]); if (!buf) return;
    alSourcei(musicSource_, AL_BUFFER, (ALint)buf); alSourcei(musicSource_, AL_SOURCE_RELATIVE, AL_TRUE); alSourcef(musicSource_, AL_GAIN, 0.35f * master_); alSourcePlay(musicSource_);
#endif
}

} // namespace mc
