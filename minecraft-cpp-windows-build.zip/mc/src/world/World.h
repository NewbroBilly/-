#pragma once
// The world: loaded chunks, block access, scheduled ticks, light + fluid simulation hooks.
#include "Chunk.h"
#include <functional>
#include <memory>
#include <queue>
#include <unordered_map>
#include <unordered_set>

namespace mc {

class LightEngine;
class FluidSimulation;

enum SetFlags : int { SET_NOTIFY = 1, SET_LIGHT = 2, SET_SAVE = 4, SET_ALL = 7 };
enum class TickType : uint8_t { Fluid, Falling, Update };

struct ScheduledTick {
    uint64_t time; uint64_t seq; BlockPos pos; TickType type;
    bool operator>(const ScheduledTick& o) const { return time != o.time ? time > o.time : seq > o.seq; }
};

class World {
public:
    explicit World(uint64_t seed);
    ~World();

    const uint64_t seed;
    uint64_t gameTime = 0;
    bool ultrawarm = false;          // Nether rules for lava speed

    // ---- chunk storage (main thread only)
    std::shared_ptr<Chunk> chunkShared(int cx, int cz) const;
    Chunk* chunk(int cx, int cz) const;
    void addChunk(std::shared_ptr<Chunk> c);
    std::shared_ptr<Chunk> removeChunk(int cx, int cz);
    const std::unordered_map<ChunkPos, std::shared_ptr<Chunk>, ChunkPosHash>& chunks() const { return chunks_; }
    bool isBlockLoaded(int x, int z) const { return chunk(x >> 4, z >> 4) != nullptr; }

    // ---- blocks. Unloaded columns read as solid stone so nothing leaks into the void.
    BlockState getBlock(int x, int y, int z) const;
    BlockState getBlock(const BlockPos& p) const { return getBlock(p.x, p.y, p.z); }
    bool setBlock(int x, int y, int z, BlockState s, int flags = SET_ALL);
    bool setBlock(const BlockPos& p, BlockState s, int flags = SET_ALL) { return setBlock(p.x, p.y, p.z, s, flags); }
    int surfaceY(int x, int z) const;             // y of topmost non-air block, or WORLD_MIN_Y-1

    // ---- light (0..15)
    int skyLight(int x, int y, int z) const;
    int blockLight(int x, int y, int z) const;
    uint8_t lightRaw(int x, int y, int z) const;

    // ---- ticks
    void scheduleTick(const BlockPos& p, int delay, TickType type);
    void tick();                                   // one game tick (20/s)
    size_t pendingTicks() const { return ticks_.size(); }

    // Called when the player/gameplay destroys a block so drops/sounds can be produced.
    std::function<void(const BlockPos&, BlockState)> onBlockBroken;
    std::function<void(const BlockPos&, BlockState, BlockState)> onBlockChanged;

    LightEngine& lighting() { return *light_; }
    FluidSimulation& fluids() { return *fluids_; }

    bool canSurvive(const BlockPos& p, BlockState s) const;  // plant support rules
    void updateNeighborsOf(const BlockPos& p);

private:
    void runTick(const ScheduledTick& t);
    std::unordered_map<ChunkPos, std::shared_ptr<Chunk>, ChunkPosHash> chunks_;
    std::priority_queue<ScheduledTick, std::vector<ScheduledTick>, std::greater<ScheduledTick>> ticks_;
    std::unordered_set<uint64_t> tickKeys_;
    uint64_t seq_ = 0;
    std::unique_ptr<LightEngine> light_;
    std::unique_ptr<FluidSimulation> fluids_;
    mutable Chunk* cacheChunk_ = nullptr; mutable int cacheX_ = 0x7fffffff, cacheZ_ = 0x7fffffff;
};

} // namespace mc
