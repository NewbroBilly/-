#include "Player.h"
#include <algorithm>

namespace mc {

void Player::setMode(GameMode m) {
    mode = m;
    if (m == GameMode::Creative || m == GameMode::Spectator) { /* may fly */ }
    if (m == GameMode::Survival || m == GameMode::Adventure) flying = false;
    if (m == GameMode::Spectator) flying = true;
}

void Player::updateFluidState(const World& w) {
    AABB b = box().inflate(-0.001);
    auto touches = [&](BlockId f) {
        for (int y = floorInt(b.y0); y <= floorInt(b.y1); ++y) for (int z = floorInt(b.z0); z <= floorInt(b.z1); ++z) for (int x = floorInt(b.x0); x <= floorInt(b.x1); ++x) {
            BlockState s = w.getBlock(x, y, z); if (stateId(s) != f) continue;
            double top = y + (fluidAmount(s) >= 8 ? 1.0 : fluidAmount(s) / 9.0 + 0.0);
            if (top > b.y0) return true;
        }
        return false;
    };
    inWater = touches(B::WATER); inLava = touches(B::LAVA);
    Vec3d e = eye(1.0); BlockState es = w.getBlock(floorInt(e.x), floorInt(e.y), floorInt(e.z));
    eyesInWater = stateId(es) == B::WATER && (e.y - floorInt(e.y)) < (fluidAmount(es) >= 8 || stateId(w.getBlock(floorInt(e.x), floorInt(e.y) + 1, floorInt(e.z))) == B::WATER ? 1.0 : fluidAmount(es) / 9.0);
    BlockState at = w.getBlock(floorInt(pos.x), floorInt(pos.y + 0.1), floorInt(pos.z));
    onLadder = stateId(at) == B::LADDER;
}

float Player::blockFriction(const World& w) const {
    BlockId b = stateId(w.getBlock(floorInt(pos.x), floorInt(pos.y - 0.5), floorInt(pos.z)));
    if (b == B::ICE || b == B::PACKED_ICE) return 0.98f; if (b == B::BLUE_ICE) return 0.989f;
    return 0.6f;
}

void Player::moveRelative(float fwd, float strafe, double speed) {
    double len2 = (double)fwd * fwd + (double)strafe * strafe; if (len2 < 1e-7) return;
    double len = std::sqrt(len2); if (len < 1.0) len = 1.0;
    double f = speed / len; double a = (double)strafe * f, b = (double)fwd * f;
    double sy = std::sin(yaw * 0.017453292519943295), cy = std::cos(yaw * 0.017453292519943295);
    vel.x += a * cy - b * sy; vel.z += b * cy + a * sy;
}

void Player::tick(World& w, const PlayerInput& inRaw) {
    prevPos = pos; if (hurtTime > 0) --hurtTime;
    if (dead) return;
    PlayerInput in = inRaw;
    updateFluidState(w);
    // creative flight toggle by double-tapping jump
    if (flyToggleTimer_ > 0) --flyToggleTimer_;
    if (mode == GameMode::Creative && in.jump && !prevJump_) { if (flyToggleTimer_ > 0) { flying = !flying; flyToggleTimer_ = 0; } else flyToggleTimer_ = 7; }
    prevJump_ = in.jump;
    if (flying && mode == GameMode::Creative && onGround && !in.jump && false) flying = false;
    sneaking = in.sneak && !(flying && mode == GameMode::Spectator);
    bool wantSprint = in.sprint && in.forward > 0.8f && !sneaking && (food > 6.0f || mode != GameMode::Survival);
    if (wantSprint) sprinting = true; else if (in.forward <= 0.0f || sneaking) sprinting = false;
    float fwd = in.forward * 0.98f, str = in.strafe * 0.98f; if (sneaking) { fwd *= 0.3f; str *= 0.3f; }
    if (jumpCooldown_ > 0) --jumpCooldown_;
    bool noClip = mode == GameMode::Spectator;
    double stepH = 0.6; bool ground = onGround;
    if (flying) {
        double fs = 0.05 * (sprinting || in.sprint ? 2.0 : 1.0);
        if (in.jump) vel.y += 0.05 * 3; if (in.sneak) vel.y -= 0.05 * 3;
        moveRelative(fwd, str, fs);
        if (noClip) { pos = pos + vel; } else { AABB b = box(); MoveResult r = moveEntity(w, b, vel, 0.0, false, false); pos = Vec3d((b.x0 + b.x1) / 2, b.y0, (b.z0 + b.z1) / 2); if (r.hitX) vel.x = 0; if (r.hitZ) vel.z = 0; if (r.hitY) { vel.y = 0; if (r.onGround && mode == GameMode::Creative) { flying = false; } } }
        vel.x *= 0.91; vel.z *= 0.91; vel.y *= 0.6;
        onGround = false; fallDistance = 0;
    } else if (inLava) {
        moveRelative(fwd, str, 0.02);
        if (in.jump) vel.y += 0.04;
        AABB b = box(); MoveResult r = moveEntity(w, b, vel, stepH, false, ground); pos = Vec3d((b.x0 + b.x1) / 2, b.y0, (b.z0 + b.z1) / 2);
        if (r.hitX) vel.x = 0; if (r.hitZ) vel.z = 0; if (r.hitY) vel.y = 0; onGround = r.onGround;
        vel = vel * 0.5; vel.y -= 0.02; fallDistance = 0;
    } else if (inWater) {
        moveRelative(fwd, str, sprinting ? 0.03 : 0.02);
        if (in.jump) vel.y += 0.04; if (in.sneak) vel.y -= 0.04;
        AABB b = box(); MoveResult r = moveEntity(w, b, vel, stepH, false, ground); pos = Vec3d((b.x0 + b.x1) / 2, b.y0, (b.z0 + b.z1) / 2);
        if (r.hitX) vel.x = 0; if (r.hitZ) vel.z = 0; if (r.hitY) vel.y = 0; onGround = r.onGround;
        // climbing out of the water at the edge
        if (r.hitX || r.hitZ) { AABB up = box().offset(vel.x, 0.6, vel.z); if (!hasCollision(w, up) && in.jump) vel.y = 0.3; }
        vel.x *= 0.8; vel.z *= 0.8; vel.y *= 0.8; vel.y -= 0.02; fallDistance = 0;
    } else {
        if (in.jump && onGround && jumpCooldown_ == 0) {
            vel.y = 0.42; jumpCooldown_ = 10;
            if (sprinting) { double yr = yaw * 0.017453292519943295; vel.x -= std::sin(yr) * 0.2; vel.z += std::cos(yr) * 0.2; exhaustion += 0.2f; } else exhaustion += 0.05f;
        }
        float bf = blockFriction(w);
        float fr = ground ? bf * 0.91f : 0.91f;
        double accel = ground ? (sprinting ? 0.13 : 0.1) * (0.21600002 / ((double)bf * bf * bf)) : (sprinting ? 0.026 : 0.02);
        moveRelative(fwd, str, accel);
        if (onLadder) { vel.x = clampv(vel.x, -0.15, 0.15); vel.z = clampv(vel.z, -0.15, 0.15); fallDistance = 0; if (vel.y < -0.15) vel.y = -0.15; if (sneaking && vel.y < 0) vel.y = 0; }
        AABB b = box(); MoveResult r = moveEntity(w, b, vel, stepH, sneaking, ground);
        pos = Vec3d((b.x0 + b.x1) / 2, b.y0, (b.z0 + b.z1) / 2);
        hitHoriz = r.hitX || r.hitZ;
        if (onLadder && (hitHoriz || in.jump)) vel.y = 0.2;
        if (r.hitX) vel.x = 0; if (r.hitZ) vel.z = 0;
        if (r.moved.y < 0) fallDistance -= r.moved.y;
        if (r.hitY) {
            if (r.onGround) { // landed
                if (fallDistance > 3.0 && mode != GameMode::Creative && stateId(w.getBlock(floorInt(pos.x), floorInt(pos.y - 0.2), floorInt(pos.z))) != B::WATER) { float dmg = (float)std::ceil(fallDistance - 3.0); fallDamageTaken = (int)dmg; hurt(dmg); }
                fallDistance = 0;
            }
            vel.y = 0;
        }
        onGround = r.onGround;
        vel.y -= 0.08; vel.y *= 0.98; vel.x *= fr; vel.z *= fr;
        if (sprinting && onGround) exhaustion += (float)(std::sqrt(r.moved.x * r.moved.x + r.moved.z * r.moved.z) * 0.1);
    }
    if (pos.y < WORLD_MIN_Y - 64) { if (mode == GameMode::Spectator) {} else hurt(4.0f, true); }
    if (mode == GameMode::Survival || mode == GameMode::Adventure) survivalTick(w);
}

void Player::survivalTick(World&) {
    // exhaustion -> hunger
    if (exhaustion >= 4.0f) { exhaustion -= 4.0f; if (saturation > 0) saturation = std::max(0.0f, saturation - 1.0f); else food = std::max(0.0f, food - 1.0f); }
    if (food >= 18.0f && health < 20.0f && health > 0) {
        if (saturation > 0 && food >= 20.0f) { if (++regenTimer_ >= 10) { regenTimer_ = 0; float h = std::min(saturation, 6.0f); health = std::min(20.0f, health + h / 6.0f); exhaustion += h; } }
        else if (++regenTimer_ >= 80) { regenTimer_ = 0; health = std::min(20.0f, health + 1.0f); exhaustion += 6.0f; }
    } else if (food <= 0.0f) { if (++starveTimer_ >= 80) { starveTimer_ = 0; if (health > 1.0f) hurt(1.0f, true); } } else { regenTimer_ = 0; starveTimer_ = 0; }
    if (eyesInWater) { if (--air <= -20) { air = 0; hurt(2.0f, true); } } else air = std::min(300, air + 4);
    if (inLava) { if (++lavaTimer_ >= 10) { lavaTimer_ = 0; hurt(4.0f, true); } } else lavaTimer_ = 0;
}

void Player::hurt(float amount, bool bypassArmor) {
    if (invulnerable() || dead || amount <= 0) return;
    if (!bypassArmor) { float ar = (float)inv.armorPoints(); amount *= 1.0f - std::min(20.0f, std::max(ar / 5.0f, ar - amount / 2.0f)) / 25.0f; inv.damageArmor(amount); }
    health -= amount; exhaustion += 0.1f; hurtTime = 10;
    if (health <= 0) { health = 0; dead = true; }
}
void Player::eat(const ItemInfo& f) { food = std::min(20.0f, food + f.food); saturation = std::min(food, saturation + f.saturation); }
void Player::addXp(int amount) {
    xpTotal += amount; xpProgress += (float)amount / xpForLevel(xpLevel);
    while (xpProgress >= 1.0f) { xpProgress = (xpProgress - 1.0f) * xpForLevel(xpLevel) / xpForLevel(xpLevel + 1); ++xpLevel; }
}
void Player::respawn() {
    dead = false; health = 20; food = 20; saturation = 5; exhaustion = 0; air = 300; vel = Vec3d(); fallDistance = 0; xpLevel = 0; xpProgress = 0; xpTotal = 0;
    pos = prevPos = Vec3d(spawn.x + 0.5, spawn.y, spawn.z + 0.5);
}

} // namespace mc
