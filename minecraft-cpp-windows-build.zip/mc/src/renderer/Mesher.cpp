#include "Mesher.h"
#include "../terrain/Biome.h"
#include <cstring>

namespace mc {

uint32_t biomeTint(int kind, int biome) {
    const BiomeInfo& b = biomeInfo((Biome)biome);
    return kind == 0 ? b.grass : kind == 1 ? b.foliage : b.water;
}

std::shared_ptr<MeshInput> buildMeshInput(const World& w, const Chunk& c) {
    auto in = std::make_shared<MeshInput>();
    in->cx = c.cx; in->cz = c.cz;
    const int W = MeshInput::W;
    in->blocks.assign((size_t)W * W * WORLD_HEIGHT, 0);
    in->light.assign((size_t)W * W * WORLD_HEIGHT, 15 << 4);
    in->firstSection = SECTION_COUNT; in->lastSection = -1;
    for (int dz = -1; dz <= 16; ++dz) for (int dx = -1; dx <= 16; ++dx) {
        int wx = c.cx * 16 + dx, wz = c.cz * 16 + dz;
        const Chunk* s = w.chunk(wx >> 4, wz >> 4);
        int lx = wx & 15, lz = wz & 15;
        in->biome[(dz + 1) * W + dx + 1] = s ? s->biome[lz * 16 + lx] : 7;
        if (!s) { for (int y = 0; y < WORLD_HEIGHT; ++y) { in->blocks[((size_t)y * W + dz + 1) * W + dx + 1] = makeState(B::STONE); in->light[((size_t)y * W + dz + 1) * W + dx + 1] = 0; } continue; }
        for (int si = 0; si < SECTION_COUNT; ++si) {
            const BlockState* d = s->sectionData(si);
            if (d) for (int ly = 0; ly < 16; ++ly) in->blocks[((size_t)(si * 16 + ly) * W + dz + 1) * W + dx + 1] = d[(ly * 16 + lz) * 16 + lx];
        }
        if (s->hasLight()) for (int y = 0; y < WORLD_HEIGHT; ++y) in->light[((size_t)y * W + dz + 1) * W + dx + 1] = s->lightRaw(lx, y + WORLD_MIN_Y, lz);
    }
    for (int si = 0; si < SECTION_COUNT; ++si) if (!c.sectionEmpty(si)) { in->firstSection = std::min(in->firstSection, si); in->lastSection = std::max(in->lastSection, si); }
    return in;
}

namespace {

// geometry tables ------------------------------------------------------------------------
const int AX_A[6] = {2, 2, 0, 0, 0, 0};      // world axis of grid coordinate A (0=x,1=y,2=z)
const int AX_B[6] = {1, 1, 2, 2, 1, 1};
const int AX_N[6] = {0, 0, 1, 1, 2, 2};
const int CORNER[6][4][2] = {
    {{1, 0}, {0, 0}, {0, 1}, {1, 1}},   // +X
    {{0, 0}, {1, 0}, {1, 1}, {0, 1}},   // -X
    {{0, 1}, {1, 1}, {1, 0}, {0, 0}},   // +Y
    {{0, 0}, {1, 0}, {1, 1}, {0, 1}},   // -Y
    {{0, 0}, {1, 0}, {1, 1}, {0, 1}},   // +Z
    {{1, 0}, {0, 0}, {0, 1}, {1, 1}},   // -Z
};
const bool U_FLIP[6] = {true, false, false, false, false, true};
const bool V_FLIP[6] = {true, true, true, false, true, true};
const uint8_t FACE_SHADE[6] = {153, 153, 255, 128, 204, 204};   // 0.6 0.6 1.0 0.5 0.8 0.8

inline int passOf(const BlockInfo& b) { return b.layer == RenderLayer::Opaque ? PASS_OPAQUE : b.layer == RenderLayer::Cutout ? PASS_CUTOUT : PASS_TRANSLUCENT; }

struct Key {
    uint16_t tex = 0xFFFF; uint8_t pass = 0, tint = 0;
    uint8_t sky[4] = {}, blk[4] = {}, ao[4] = {};
    bool uniform = false;
    bool operator==(const Key& o) const { return tex == o.tex && pass == o.pass && tint == o.tint && !std::memcmp(sky, o.sky, 4) && !std::memcmp(blk, o.blk, 4) && !std::memcmp(ao, o.ao, 4); }
};

struct Mesher {
    const MeshInput& in; MeshOutput& out;
    int curSec = 0;
    // tint lattice: colours at lattice points (0..16) averaged from the 4 surrounding columns
    uint32_t tintGrid[3][17 * 17];

    Mesher(const MeshInput& i, MeshOutput& o) : in(i), out(o) {
        const int W = MeshInput::W;
        for (int k = 0; k < 3; ++k) for (int z = 0; z <= 16; ++z) for (int x = 0; x <= 16; ++x) {
            int r = 0, g = 0, b = 0;
            for (int dz = 0; dz < 2; ++dz) for (int dx = 0; dx < 2; ++dx) {
                uint32_t c = biomeTint(k, in.biome[(z + dz) * W + x + dx]);   // columns x-1..x -> index x..x+1 in padded grid
                r += (c >> 16) & 255; g += (c >> 8) & 255; b += c & 255;
            }
            tintGrid[k][z * 17 + x] = ((r / 4) << 16) | ((g / 4) << 8) | (b / 4);
        }
    }

    static const BlockInfo& info(BlockState s) { return blockOf(s); }
    bool opaqueAt(int x, int y, int z) const { return info(in.at(x, y, z)).opaque; }

    void tintColor(const BlockInfo& b, int dir, int lx, int lz, uint8_t& r, uint8_t& g, uint8_t& bl, uint8_t& a) const {
        r = g = bl = 255; a = 0;
        int kind = b.tint == Tint::Grass ? 0 : b.tint == Tint::Foliage ? 1 : b.tint == Tint::Water ? 2 : -1;
        if (kind >= 0) {
            uint32_t c = tintGrid[kind][lz * 17 + lx]; r = (c >> 16) & 255; g = (c >> 8) & 255; bl = c & 255; a = 255;
            if (b.tintSideMask) { if (dir == DIR_UP) a = 255; else if (dir == DIR_DOWN) { a = 0; r = g = bl = 255; } else a = 128; }
        } else if (b.fixedTint != 0xFFFFFF) { r = (b.fixedTint >> 16) & 255; g = (b.fixedTint >> 8) & 255; bl = b.fixedTint & 255; a = 255; }
    }

    void pushQuad(int pass, const Vertex v[4], bool flip) {
        auto& vec = out.verts[pass];
        if (!flip) for (int i = 0; i < 4; ++i) vec.push_back(v[i]);
        else for (int i = 0; i < 4; ++i) vec.push_back(v[(i + 1) & 3]);
    }

    int frontDir(BlockState s) const { static const int f[4] = {DIR_NORTH, DIR_SOUTH, DIR_WEST, DIR_EAST}; return f[stateMeta(s) & 3]; }
    int texFor(const BlockInfo& b, BlockState s, int dir) const { return (b.hasFacing && dir == frontDir(s)) ? b.frontTex : b.tex[dir]; }

    bool faceVisible(const BlockInfo& b, const BlockInfo& n, BlockState ns) const {
        if (ns == 0) return true;
        if (n.opaque) return false;
        if (b.layer != RenderLayer::Opaque && n.id == b.id && b.cullSame) return false;
        return true;
    }

    // Computes smooth light and AO for the 4 corners of the face of cell (x,y,z) in direction dir.
    void faceLight(int x, int y, int z, int dir, Key& k) const {
        int n[3] = {x, y, z}; n[AX_N[dir]] += (dir & 1) ? -1 : 1;
        uint8_t base = in.lightAt(n[0], n[1], n[2]);
        for (int c = 0; c < 4; ++c) {
            int sa = CORNER[dir][c][0] ? 1 : -1, sb = CORNER[dir][c][1] ? 1 : -1;
            int p1[3] = {n[0], n[1], n[2]}, p2[3] = {n[0], n[1], n[2]}, p3[3] = {n[0], n[1], n[2]};
            p1[AX_A[dir]] += sa; p2[AX_B[dir]] += sb; p3[AX_A[dir]] += sa; p3[AX_B[dir]] += sb;
            bool o1 = opaqueAt(p1[0], p1[1], p1[2]), o2 = opaqueAt(p2[0], p2[1], p2[2]), o3 = opaqueAt(p3[0], p3[1], p3[2]);
            uint8_t l1 = o1 ? base : in.lightAt(p1[0], p1[1], p1[2]), l2 = o2 ? base : in.lightAt(p2[0], p2[1], p2[2]);
            uint8_t l3 = (o1 && o2) ? base : (o3 ? base : in.lightAt(p3[0], p3[1], p3[2]));
            k.sky[c] = (uint8_t)((base >> 4) + (l1 >> 4) + (l2 >> 4) + (l3 >> 4));
            k.blk[c] = (uint8_t)((base & 15) + (l1 & 15) + (l2 & 15) + (l3 & 15));
            k.ao[c] = (uint8_t)((o1 && o2) ? 0 : 3 - ((int)o1 + (int)o2 + (int)o3));
        }
        k.uniform = k.sky[0] == k.sky[1] && k.sky[1] == k.sky[2] && k.sky[2] == k.sky[3] && k.blk[0] == k.blk[1] && k.blk[1] == k.blk[2] && k.blk[2] == k.blk[3] &&
                    k.ao[0] == k.ao[1] && k.ao[1] == k.ao[2] && k.ao[2] == k.ao[3];
    }

    void emitRect(int dir, const BlockInfo& b, const Key& k, int sliceN, int a0, int b0, int w, int h, int secY0) {
        Vertex v[4];
        float aoF[4] = {0.5f, 0.7f, 0.85f, 1.0f};
        for (int c = 0; c < 4; ++c) {
            int ca = CORNER[dir][c][0], cb = CORNER[dir][c][1];
            float pos[3]; int la = a0 + (ca ? w : 0), lb = b0 + (cb ? h : 0);
            pos[AX_N[dir]] = (float)(sliceN + ((dir & 1) ? 0 : 1)); pos[AX_A[dir]] = (float)la; pos[AX_B[dir]] = (float)lb;
            // pos is in (x,y,z) with y relative to the section; convert to chunk-local world y
            v[c].x = pos[0]; v[c].z = pos[2]; v[c].y = pos[1] + (float)secY0;
            v[c].u = (U_FLIP[dir] ? (1 - ca) : ca) * (float)w; v[c].v = (V_FLIP[dir] ? (1 - cb) : cb) * (float)h;
            v[c].sky = (uint8_t)(k.sky[c] * 255 / 60); v[c].blk = (uint8_t)(k.blk[c] * 255 / 60);
            v[c].ao = (uint8_t)(aoF[k.ao[c]] * 255.0f); v[c].shade = FACE_SHADE[dir];
            v[c].layer = k.tex; v[c].pad = 0;
            // tint: lattice coordinates in chunk space
            int lx = (int)std::lround(v[c].x), lz = (int)std::lround(v[c].z);
            tintColor(b, dir, clampv(lx, 0, 16), clampv(lz, 0, 16), v[c].r, v[c].g, v[c].b, v[c].a);
        }
        bool flip = k.ao[0] + k.ao[2] > k.ao[1] + k.ao[3];
        pushQuad(k.pass, v, flip);
    }

    void greedySection(int sec) {
        const int y0 = sec * 16;
        Key mask[16][16];
        for (int dir = 0; dir < 6; ++dir) {
            for (int s = 0; s < 16; ++s) {
                bool any = false;
                for (int bI = 0; bI < 16; ++bI) for (int aI = 0; aI < 16; ++aI) {
                    int c[3]; c[AX_N[dir]] = s; c[AX_A[dir]] = aI; c[AX_B[dir]] = bI;
                    int ly = c[1] + y0;     // section-relative y -> chunk y index
                    Key& k = mask[bI][aI]; k.tex = 0xFFFF;
                    BlockState st = in.at(c[0], ly, c[2]);
                    if (st == 0) continue;
                    const BlockInfo& b = info(st);
                    if (b.shape != Shape::Cube) continue;
                    int n[3] = {c[0], ly, c[2]}; n[AX_N[dir]] += (dir & 1) ? -1 : 1;
                    BlockState ns = in.at(n[0], n[1], n[2]);
                    if (!faceVisible(b, info(ns), ns)) continue;
                    k.tex = (uint16_t)texFor(b, st, dir); k.pass = (uint8_t)passOf(b); k.tint = (uint8_t)b.tint;
                    faceLight(c[0], ly, c[2], dir, k);
                    any = true;
                }
                if (!any) continue;
                bool used[16][16] = {};
                for (int bI = 0; bI < 16; ++bI) for (int aI = 0; aI < 16; ++aI) {
                    if (used[bI][aI] || mask[bI][aI].tex == 0xFFFF) continue;
                    const Key& k = mask[bI][aI];
                    int w = 1, h = 1;
                    if (k.uniform) {
                        while (aI + w < 16 && !used[bI][aI + w] && mask[bI][aI + w].tex != 0xFFFF && mask[bI][aI + w].uniform && mask[bI][aI + w] == k) ++w;
                        bool ok = true;
                        while (bI + h < 16 && ok) { for (int i = 0; i < w; ++i) { const Key& o = mask[bI + h][aI + i]; if (used[bI + h][aI + i] || o.tex == 0xFFFF || !o.uniform || !(o == k)) { ok = false; break; } } if (ok) ++h; }
                    }
                    for (int j = 0; j < h; ++j) for (int i = 0; i < w; ++i) used[bI + j][aI + i] = true;
                    int c[3]; c[AX_N[dir]] = s; c[AX_A[dir]] = aI; c[AX_B[dir]] = bI;
                    int ly = c[1] + y0; BlockState st = in.at(c[0], ly, c[2]);
                    // emitRect works in section-relative axes
                    emitRect(dir, info(st), k, s, aI, bI, w, h, y0);
                }
            }
        }
    }

    // ---- special shapes
    void cellLight(int x, int y, int z, uint8_t& sky, uint8_t& blk) const { uint8_t l = in.lightAt(x, y, z); sky = (uint8_t)((l >> 4) * 17); blk = (uint8_t)((l & 15) * 17); }

    void crossShape(int x, int y, int z, BlockState st) {
        const BlockInfo& b = info(st); Vertex v[4]; uint8_t sky, blk; cellLight(x, y, z, sky, blk);
        const float P[2][4][3] = {{{0.1f, 0, 0.1f}, {0.9f, 0, 0.9f}, {0.9f, 1, 0.9f}, {0.1f, 1, 0.1f}}, {{0.1f, 0, 0.9f}, {0.9f, 0, 0.1f}, {0.9f, 1, 0.1f}, {0.1f, 1, 0.9f}}};
        const float UV[4][2] = {{0, 1}, {1, 1}, {1, 0}, {0, 0}};
        for (int q = 0; q < 2; ++q) {
            for (int c = 0; c < 4; ++c) {
                v[c].x = x + P[q][c][0]; v[c].y = (float)(y + P[q][c][1] + curBase); v[c].z = z + P[q][c][2]; v[c].u = UV[c][0]; v[c].v = UV[c][1];
                v[c].sky = sky; v[c].blk = blk; v[c].ao = 255; v[c].shade = 230; v[c].layer = (uint16_t)b.tex[DIR_SOUTH]; v[c].pad = 0;
                tintColor(b, DIR_UP, x, z, v[c].r, v[c].g, v[c].b, v[c].a); if (b.tint != Tint::None) { v[c].a = 255; }
            }
            pushQuad(passOf(b), v, false);
        }
    }
    int curBase = 0;   // y offset of current section (chunk-local y index base)

    void boxShape(int x, int y, int z, BlockState st) {
        const BlockInfo& b = info(st); float bx[6]; if (!Blocks::getBox(st, bx)) return;
        for (int dir = 0; dir < 6; ++dir) {
            int axn = AX_N[dir]; bool neg = dir & 1; float plane = neg ? bx[axn] : bx[axn + 3];
            int nb[3] = {x, y, z}; nb[axn] += neg ? -1 : 1;
            bool boundary = neg ? bx[axn] <= 0.0001f : bx[axn + 3] >= 0.9999f;
            BlockState ns = in.at(nb[0], nb[1], nb[2]);
            if (boundary && (info(ns).opaque || (ns != 0 && info(ns).id == b.id && b.cullSame))) continue;
            uint8_t sky, blk; if (boundary) cellLight(nb[0], nb[1], nb[2], sky, blk); else cellLight(x, y, z, sky, blk);
            Vertex v[4];
            for (int c = 0; c < 4; ++c) {
                int ca = CORNER[dir][c][0], cb = CORNER[dir][c][1]; float p[3];
                p[axn] = plane; p[AX_A[dir]] = ca ? bx[AX_A[dir] + 3] : bx[AX_A[dir]]; p[AX_B[dir]] = cb ? bx[AX_B[dir] + 3] : bx[AX_B[dir]];
                v[c].x = x + p[0]; v[c].y = (float)(y + p[1] + curBase); v[c].z = z + p[2];
                float ua = p[AX_A[dir]], vb = p[AX_B[dir]];
                v[c].u = U_FLIP[dir] ? 1.0f - ua : ua; v[c].v = V_FLIP[dir] ? 1.0f - vb : vb;
                v[c].sky = sky; v[c].blk = blk; v[c].ao = 255; v[c].shade = FACE_SHADE[dir]; v[c].layer = (uint16_t)texFor(b, st, dir); v[c].pad = 0;
                tintColor(b, dir, x, z, v[c].r, v[c].g, v[c].b, v[c].a);
            }
            pushQuad(passOf(b), v, false);
        }
    }

    // fluid height of a cell as seen from a corner; returns <0 when the cell does not count
    float fluidHeight(BlockId f, int x, int y, int z, float& weight) const {
        BlockState s = in.at(x, y, z);
        if (stateId(s) == f) {
            if (stateId(in.at(x, y + 1, z)) == f) { weight = 10.0f; return 1.0f; }
            float h = fluidAmount(s) / 9.0f; weight = stateMeta(s) == 0 ? 10.0f : 1.0f; return h;
        }
        if (!info(s).solid) { weight = 1.0f; return 0.0f; }
        weight = 0.0f; return 0.0f;
    }
    void fluidShape(int x, int y, int z, BlockState st) {
        const BlockInfo& b = info(st); BlockId f = b.id; uint8_t sky, blk; cellLight(x, y, z, sky, blk);
        bool above = stateId(in.at(x, y + 1, z)) == f;
        float hc[2][2];       // corner heights [dz][dx]
        for (int dz = 0; dz < 2; ++dz) for (int dx = 0; dx < 2; ++dx) {
            if (above) { hc[dz][dx] = 1.0f; continue; }
            float sum = 0, wsum = 0;
            for (int oz = -1; oz <= 0; ++oz) for (int ox = -1; ox <= 0; ++ox) { float w; float h = fluidHeight(f, x + dx + ox, y, z + dz + oz, w); sum += h * w; wsum += w; }
            hc[dz][dx] = wsum > 0 ? std::min(sum / wsum, 0.97f) : 0.0f;
            if (hc[dz][dx] < 0.05f) hc[dz][dx] = fluidAmount(st) / 9.0f * 0.9f;
        }
        int pass = passOf(b);
        auto mk = [&](float px, float py, float pz, float u, float vv, uint8_t sh, Vertex& o) {
            o.x = x + px; o.y = (float)(y + py + curBase); o.z = z + pz; o.u = u; o.v = vv; o.sky = sky; o.blk = blk; o.ao = 255; o.shade = sh; o.layer = (uint16_t)b.tex[DIR_UP]; o.pad = 0;
            tintColor(b, DIR_UP, x + (px > 0.5f), z + (pz > 0.5f), o.r, o.g, o.b, o.a);
        };
        Vertex v[4];
        if (!above) {   // top face (visible from above), CCW seen from above
            mk(0, hc[1][0], 1, 0, 1, 255, v[0]); mk(1, hc[1][1], 1, 1, 1, 255, v[1]); mk(1, hc[0][1], 0, 1, 0, 255, v[2]); mk(0, hc[0][0], 0, 0, 0, 255, v[3]);
            pushQuad(pass, v, false);
        }
        BlockState below = in.at(x, y - 1, z);
        if (!info(below).opaque && stateId(below) != f) { mk(0, 0, 0, 0, 0, 128, v[0]); mk(1, 0, 0, 1, 0, 128, v[1]); mk(1, 0, 1, 1, 1, 128, v[2]); mk(0, 0, 1, 0, 1, 128, v[3]); pushQuad(pass, v, false); }
        for (int d : HORIZ_DIRS) {
            BlockState n = in.at(x + DIR_DX[d], y, z + DIR_DZ[d]);
            if (info(n).opaque || stateId(n) == f) continue;
            if (n != 0 && info(n).fluid) continue;
            float h0, h1;   // heights at the two corners (a,b order per CORNER table)
            // corners listed as in CORNER[d]: c0,c1 are bottom corners; their positions give which corner heights to use
            Vertex q[4];
            for (int c = 0; c < 4; ++c) {
                int ca = CORNER[d][c][0], cb = CORNER[d][c][1];
                float p[3]; p[AX_N[d]] = (d & 1) ? 0.0f : 1.0f; p[AX_A[d]] = (float)ca; p[1] = 0;
                int ix = (int)p[0], iz = (int)p[2];
                (void)ix; (void)iz;
                float hh = hc[(int)p[2]][(int)p[0]];
                p[1] = cb ? hh : 0.0f;
                q[c].x = x + p[0]; q[c].y = (float)(y + p[1] + curBase); q[c].z = z + p[2];
                q[c].u = (U_FLIP[d] ? (1 - ca) : ca) * 1.0f; q[c].v = cb ? (1.0f - hh) : 1.0f;
                q[c].sky = sky; q[c].blk = blk; q[c].ao = 255; q[c].shade = FACE_SHADE[d]; q[c].layer = (uint16_t)b.tex[DIR_UP]; q[c].pad = 0;
                tintColor(b, DIR_UP, x + (p[0] > 0.5f), z + (p[2] > 0.5f), q[c].r, q[c].g, q[c].b, q[c].a);
            }
            (void)h0; (void)h1;
            pushQuad(pass, q, false);
        }
    }

    void specialSection(int sec) {
        const int y0 = sec * 16; curBase = y0 + WORLD_MIN_Y - y0;   // vertex y is relative to WORLD_MIN_Y: y index + base
        curBase = 0;
        for (int ly = 0; ly < 16; ++ly) for (int z = 0; z < 16; ++z) for (int x = 0; x < 16; ++x) {
            int y = y0 + ly; BlockState st = in.at(x, y, z); if (st == 0) continue;
            const BlockInfo& b = info(st);
            if (b.shape == Shape::Cross) crossShape(x, y, z, st);
            else if (b.shape == Shape::Box) boxShape(x, y, z, st);
            else if (b.shape == Shape::Fluid) fluidShape(x, y, z, st);
        }
    }

    uint16_t sectionVisibility(int sec) const {
        const int y0 = sec * 16;
        static thread_local uint8_t seen[4096]; std::memset(seen, 0, 4096);
        bool anyAir = false, anySolid = false;
        for (int i = 0; i < 4096; ++i) { int x = i & 15, z = (i >> 4) & 15, y = y0 + (i >> 8); if (info(in.at(x, y, z)).opaque) anySolid = true; else anyAir = true; if (anySolid && anyAir) break; }
        if (!anySolid) return 0x7FFF;
        if (!anyAir) return 0;
        uint16_t vis = 0; static thread_local int stack[4096];
        for (int start = 0; start < 4096; ++start) {
            if (seen[start]) continue;
            int sx = start & 15, sz = (start >> 4) & 15, sy = start >> 8;
            if (info(in.at(sx, y0 + sy, sz)).opaque) { seen[start] = 1; continue; }
            int sp = 0; stack[sp++] = start; seen[start] = 1; int faces = 0;
            while (sp) {
                int i = stack[--sp]; int x = i & 15, z = (i >> 4) & 15, y = i >> 8;
                if (x == 0) faces |= 1 << DIR_WEST; if (x == 15) faces |= 1 << DIR_EAST; if (y == 0) faces |= 1 << DIR_DOWN; if (y == 15) faces |= 1 << DIR_UP; if (z == 0) faces |= 1 << DIR_NORTH; if (z == 15) faces |= 1 << DIR_SOUTH;
                for (int d = 0; d < 6; ++d) {
                    int nx = x + DIR_DX[d], ny = y + DIR_DY[d], nz = z + DIR_DZ[d];
                    if (nx < 0 || nx > 15 || ny < 0 || ny > 15 || nz < 0 || nz > 15) continue;
                    int ni = (ny * 16 + nz) * 16 + nx; if (seen[ni]) continue; seen[ni] = 1;
                    if (!info(in.at(nx, y0 + ny, nz)).opaque) stack[sp++] = ni;
                }
            }
            for (int a = 0; a < 6; ++a) for (int b2 = a + 1; b2 < 6; ++b2) if ((faces >> a & 1) && (faces >> b2 & 1)) vis |= (uint16_t)(1 << visPairBit(a, b2));
        }
        return vis;
    }

    void run() {
        for (int p = 0; p < PASS_COUNT; ++p) out.secFirstQuad[p][0] = 0;
        for (int sec = 0; sec < SECTION_COUNT; ++sec) {
            bool inRange = sec >= in.firstSection && sec <= in.lastSection;
            if (inRange) { greedySection(sec); specialSection(sec); out.secVis[sec] = sectionVisibility(sec); }
            else out.secVis[sec] = 0x7FFF;
            for (int p = 0; p < PASS_COUNT; ++p) out.secFirstQuad[p][sec + 1] = (uint32_t)(out.verts[p].size() / 4);
        }
    }
};

} // namespace

void meshChunk(const MeshInput& in, MeshOutput& out) {
    out.cx = in.cx; out.cz = in.cz;
    for (auto& v : out.verts) v.clear();
    Mesher m(in, out); m.run();
}

} // namespace mc
