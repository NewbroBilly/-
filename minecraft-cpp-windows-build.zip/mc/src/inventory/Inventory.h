#pragma once
// Player inventory, crafting recipes, furnace state and the container "menu" click logic.
#include "Item.h"
#include <array>
#include <memory>

namespace mc {

class Inventory {
public:
    static constexpr int HOTBAR = 9, MAIN_END = 36, ARMOR0 = 36, OFFHAND = 40, SIZE = 41;   // armor: 36 boots, 37 leggings, 38 chest, 39 helmet
    std::array<ItemStack, SIZE> slots{};
    int selected = 0;
    ItemStack& hand() { return slots[selected]; }
    const ItemStack& hand() const { return slots[selected]; }
    int add(ItemStack s);                          // returns what did not fit
    int count(ItemId id) const;
    bool remove(ItemId id, int n);
    int armorPoints() const;
    void damageArmor(float dmg);
    bool damageHeldTool(int amount = 1);           // returns true if it broke
};

struct Ing {
    ItemId item = 0; std::string tag;
    bool matches(ItemId id) const { return tag.empty() ? id == item : Items::isTag(tag, id); }
    bool blank() const { return item == 0 && tag.empty(); }
};
struct Recipe { bool shaped = true; int w = 1, h = 1; std::vector<Ing> ing; ItemId result = 0; int count = 1; };
struct SmeltRecipe { ItemId in, out; float xp; int time; };

class Recipes {
public:
    static void init();
    static const std::vector<Recipe>& all() { return recipes_; }
    static bool match(const ItemStack* grid, int gw, int gh, ItemStack& out, const Recipe** which = nullptr);
    static const SmeltRecipe* smelt(ItemId in);
private:
    static std::vector<Recipe> recipes_;
    static std::vector<SmeltRecipe> smelting_;
};

struct FurnaceState {
    ItemStack input, fuel, output;
    int burnTime = 0, burnTotal = 0, cookTime = 0, cookTotal = 200; float storedXp = 0;
    void tick();
};

enum class SlotKind : uint8_t { Normal, Output, Armor, Fuel, Input };
struct MenuSlot { ItemStack* stack; SlotKind kind; int armorSlot = -1; };

class Menu {
public:
    enum Type { PlayerCrafting, CraftingTable, Chest, Furnace } type;
    std::vector<MenuSlot> slots;
    ItemStack cursor;
    int gridFirst = 0, gridW = 0, gridH = 0;      // crafting grid slots (if any)
    int invFirst = 0;                              // first slot of the 27 main inventory slots; hotbar follows
    int containerFirst = 0, containerCount = 0;    // chest / furnace slots
    static std::unique_ptr<Menu> playerMenu(Inventory& inv);
    static std::unique_ptr<Menu> craftingTable(Inventory& inv);
    static std::unique_ptr<Menu> chest(Inventory& inv, std::vector<ItemStack>& chestSlots);
    static std::unique_ptr<Menu> furnace(Inventory& inv, FurnaceState& fs);
    void click(int slot, int button, bool shift);  // button 0 = left, 1 = right
    void close(Inventory& inv);                    // returns the grid + cursor to the player
    void updateResult();
private:
    bool accepts(int slot, const ItemStack& s) const;
    void quickMove(int slot);
    void takeOutput(int slot);
    int moveInto(ItemStack& s, int from, int to, bool reverse);
    std::array<ItemStack, 10> grid_{};
    Inventory* inv_ = nullptr;
};

} // namespace mc
