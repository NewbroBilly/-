#pragma once
// Player: vanilla-style movement (20 TPS), survival stats, game modes.
#include "../physics/Physics.h"
#include "../inventory/Inventory.h"

namespace mc {

enum class GameMode : uint8_t { Survival = 0, Creative = 1, Adventure = 2, Spectator = 3 };

struct PlayerInput { float forward = 0, strafe = 0; bool jump = false, sneak = false, sprint = false; };

class Player {
public:
    Vec3d pos{0, 100, 0}, prevPos{0, 100, 0}, vel;
    float yaw = 0, pitch = 0;                       // yaw 0 faces +Z, pitch>0 looks down
    bool onGround = false, flying = false, sprinting = false, sneaking = false;
    bool inWater = false, eyesInWater = false, inLava = false, onLadder = false, hitHoriz = false;
    GameMode mode = GameMode::Survival;
    float health = 20, food = 20, saturation = 5, exhaustion = 0;
    int air = 300, xpLevel = 0, xpTotal = 0; float xpProgress = 0;
    bool dead = false; int hurtTime = 0, fallDamageTaken = 0;
    double fallDistance = 0;
    Inventory inv;
    BlockPos spawn{0, 100, 0};

    static constexpr double WIDTH = 0.6, HEIGHT = 1.8, SNEAK_HEIGHT = 1.5;
    double height() const { return sneaking ? SNEAK_HEIGHT : HEIGHT; }
    double eyeHeight() const { return sneaking ? 1.27 : 1.62; }
    AABB box() const { return AABB(pos.x - WIDTH / 2, pos.y, pos.z - WIDTH / 2, pos.x + WIDTH / 2, pos.y + height(), pos.z + WIDTH / 2); }
    Vec3d eye(double partial = 1.0) const { Vec3d p = prevPos + (pos - prevPos) * partial; return Vec3d(p.x, p.y + eyeHeight(), p.z); }
    Vec3d lookDir() const { double cp = std::cos(pitch * 0.017453292519943295), sp = std::sin(pitch * 0.017453292519943295), cy = std::cos(yaw * 0.017453292519943295), sy = std::sin(yaw * 0.017453292519943295); return Vec3d(-sy * cp, -sp, cy * cp); }
    double reach() const { return mode == GameMode::Creative ? 5.0 : 4.5; }

    void tick(World& w, const PlayerInput& in);
    void setMode(GameMode m);
    void hurt(float amount, bool bypassArmor = false);
    void eat(const ItemInfo& food);
    void addXp(int amount);
    void respawn();
    bool canMineBlocks() const { return mode == GameMode::Survival || mode == GameMode::Creative; }
    bool invulnerable() const { return mode == GameMode::Creative || mode == GameMode::Spectator; }
    static int xpForLevel(int level) { return level < 16 ? 2 * level + 7 : level < 31 ? 5 * level - 38 : 9 * level - 158; }
private:
    void updateFluidState(const World& w);
    void survivalTick(World& w);
    float blockFriction(const World& w) const;
    void moveRelative(float fwd, float strafe, double speed);
    int regenTimer_ = 0, starveTimer_ = 0, lavaTimer_ = 0;
    int jumpCooldown_ = 0; bool prevJump_ = false; int flyToggleTimer_ = 0;
};

} // namespace mc
