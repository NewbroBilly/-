#include "Inventory.h"
#include <algorithm>
#include <cstdio>

namespace mc {

int Inventory::add(ItemStack s) {
    if (s.empty()) return 0;
    int max = Items::get(s.id).maxStack;
    for (int i = 0; i < 36 && s.count > 0; ++i) {                  // fill existing stacks (hotbar first)
        ItemStack& d = slots[i];
        if (!d.empty() && d.sameKind(s) && d.count < max) { int n = std::min(max - d.count, s.count); d.count += n; s.count -= n; }
    }
    for (int i = 0; i < 36 && s.count > 0; ++i) {
        ItemStack& d = slots[i];
        if (d.empty()) { int n = std::min(max, s.count); d = ItemStack(s.id, n, s.damage); s.count -= n; }
    }
    return s.count;
}
int Inventory::count(ItemId id) const { int n = 0; for (int i = 0; i < 36; ++i) if (!slots[i].empty() && slots[i].id == id) n += slots[i].count; return n; }
bool Inventory::remove(ItemId id, int n) {
    if (count(id) < n) return false;
    for (int i = 0; i < 36 && n > 0; ++i) if (!slots[i].empty() && slots[i].id == id) { int t = std::min(n, slots[i].count); slots[i].count -= t; n -= t; if (slots[i].count <= 0) slots[i].clear(); }
    return true;
}
int Inventory::armorPoints() const { int p = 0; for (int i = 0; i < 4; ++i) if (!slots[ARMOR0 + i].empty()) p += Items::get(slots[ARMOR0 + i].id).armorPoints; return p; }
void Inventory::damageArmor(float dmg) {
    int d = std::max(1, (int)(dmg / 4.0f));
    for (int i = 0; i < 4; ++i) { ItemStack& a = slots[ARMOR0 + i]; if (a.empty()) continue; a.damage += d; if (a.damage >= Items::get(a.id).maxDamage) a.clear(); }
}
bool Inventory::damageHeldTool(int amount) {
    ItemStack& h = hand(); if (h.empty()) return false;
    int md = Items::get(h.id).maxDamage; if (md <= 0) return false;
    h.damage += amount; if (h.damage >= md) { h.clear(); return true; } return false;
}

// ---------------------------------------------------------------- recipes
std::vector<Recipe> Recipes::recipes_;
std::vector<SmeltRecipe> Recipes::smelting_;

static Ing mkIng(const std::string& n) {
    Ing i;
    if (n.empty() || n == " ") return i;
    if (n[0] == '#') i.tag = n.substr(1); else { i.item = Items::byName(n); if (!i.item) std::fprintf(stderr, "[recipes] unknown item '%s'\n", n.c_str()); }
    return i;
}

void Recipes::init() {
    if (!recipes_.empty()) return;
    Items::init();
    auto shaped = [&](std::vector<std::string> rows, std::vector<std::pair<char, std::string>> key, const std::string& result, int count = 1) {
        Recipe r; r.shaped = true; r.h = (int)rows.size(); r.w = (int)rows[0].size(); r.result = Items::byName(result); r.count = count;
        if (!r.result) { std::fprintf(stderr, "[recipes] unknown result '%s'\n", result.c_str()); return; }
        for (auto& row : rows) for (char c : row) { Ing i; if (c != ' ') for (auto& k : key) if (k.first == c) i = mkIng(k.second); r.ing.push_back(i); }
        recipes_.push_back(r);
    };
    auto shapeless = [&](std::vector<std::string> items, const std::string& result, int count = 1) {
        Recipe r; r.shaped = false; r.result = Items::byName(result); r.count = count;
        if (!r.result) { std::fprintf(stderr, "[recipes] unknown result '%s'\n", result.c_str()); return; }
        for (auto& n : items) r.ing.push_back(mkIng(n)); recipes_.push_back(r);
    };
    for (const char* w : {"oak", "spruce", "birch", "jungle", "acacia", "dark_oak"}) shapeless({std::string(w) + "_log"}, std::string(w) + "_planks", 4);
    shaped({"#", "#"}, {{'#', "#planks"}}, "stick", 4);
    shaped({"##", "##"}, {{'#', "#planks"}}, "crafting_table");
    shaped({"###", "# #", "###"}, {{'#', "cobblestone"}}, "furnace");
    shaped({"###", "# #", "###"}, {{'#', "#planks"}}, "chest");
    shaped({"C", "S"}, {{'C', "#coals"}, {'S', "stick"}}, "torch", 4);
    shaped({"S S", "SSS", "S S"}, {{'S', "stick"}}, "ladder", 3);
    shaped({"###", "BBB", "###"}, {{'#', "#planks"}, {'B', "book"}}, "bookshelf");
    shaped({"##", "##"}, {{'#', "stone"}}, "stone_bricks", 4); shaped({"##", "##"}, {{'#', "sand"}}, "sandstone"); shaped({"##", "##"}, {{'#', "brick"}}, "bricks");
    shaped({"##", "##"}, {{'#', "glowstone_dust"}}, "glowstone"); shaped({"##", "##"}, {{'#', "snowball"}}, "snow_block"); shaped({"##", "##"}, {{'#', "clay_ball"}}, "clay");
    shaped({"###"}, {{'#', "sugar_cane"}}, "paper", 3); shaped({"###"}, {{'#', "wheat"}}, "bread");
    shaped({"#X#", "X#X", "#X#"}, {{'#', "gunpowder"}, {'X', "sand"}}, "tnt");
    shaped({"# #", " # "}, {{'#', "iron_ingot"}}, "bucket"); shaped({" #", "# "}, {{'#', "iron_ingot"}}, "shears");
    shapeless({"iron_ingot", "flint"}, "flint_and_steel");
    shaped({" #S", "# S", " #S"}, {{'#', "stick"}, {'S', "string"}}, "bow"); shaped({"F", "S", "E"}, {{'F', "flint"}, {'S', "stick"}, {'E', "feather"}}, "arrow", 4);
    shaped({"###"}, {{'#', "#planks"}}, "oak_slab", 6); shaped({"###"}, {{'#', "cobblestone"}}, "cobblestone_slab", 6); shaped({"###"}, {{'#', "stone"}}, "stone_slab", 6);
    shaped({"###"}, {{'#', "stone_bricks"}}, "stone_brick_slab", 6); shaped({"###"}, {{'#', "sandstone"}}, "sandstone_slab", 6);
    shaped({"###", " S ", " S "}, {{'#', "stone"}, {'S', "stick"}}, "stone_pickaxe");   // overridden below by the generic tier loop (cobblestone)
    recipes_.pop_back();
    struct M { const char* tool; const char* mat; };
    for (M m : {M{"wooden", "#planks"}, M{"stone", "cobblestone"}, M{"iron", "iron_ingot"}, M{"golden", "gold_ingot"}, M{"diamond", "diamond"}}) {
        std::string t = m.tool, mat = m.mat; std::vector<std::pair<char, std::string>> k = {{'M', mat}, {'S', "stick"}};
        shaped({"MMM", " S ", " S "}, k, t + "_pickaxe"); shaped({"MM", "MS", " S"}, k, t + "_axe"); shaped({"M", "S", "S"}, k, t + "_shovel");
        shaped({"MM", " S", " S"}, k, t + "_hoe"); shaped({"M", "M", "S"}, k, t + "_sword");
    }
    for (M m : {M{"leather", "leather"}, M{"iron", "iron_ingot"}, M{"golden", "gold_ingot"}, M{"diamond", "diamond"}}) {
        std::string t = m.tool; std::vector<std::pair<char, std::string>> k = {{'M', m.mat}};
        shaped({"MMM", "M M"}, k, t + "_helmet"); shaped({"M M", "MMM", "MMM"}, k, t + "_chestplate"); shaped({"MMM", "M M", "M M"}, k, t + "_leggings"); shaped({"M M", "M M"}, k, t + "_boots");
    }
    struct S { const char* block; const char* item; };
    for (S s : {S{"iron_block", "iron_ingot"}, S{"gold_block", "gold_ingot"}, S{"diamond_block", "diamond"}, S{"emerald_block", "emerald"}, S{"lapis_block", "lapis_lazuli"}, S{"redstone_block", "redstone"}, S{"coal_block", "coal"}}) {
        shaped({"###", "###", "###"}, {{'#', s.item}}, s.block); shapeless({s.block}, s.item, 9);
    }
    // smelting
    auto sm = [&](const char* in, const char* out, float xp, int t = 200) { ItemId a = Items::byName(in), b = Items::byName(out); if (a && b) smelting_.push_back({a, b, xp, t}); else std::fprintf(stderr, "[smelt] unknown %s -> %s\n", in, out); };
    sm("raw_iron", "iron_ingot", 0.7f); sm("raw_gold", "gold_ingot", 1.0f); sm("raw_copper", "copper_ingot", 0.7f);
    sm("iron_ore", "iron_ingot", 0.7f); sm("gold_ore", "gold_ingot", 1.0f); sm("copper_ore", "copper_ingot", 0.7f); sm("deepslate_iron_ore", "iron_ingot", 0.7f); sm("deepslate_gold_ore", "gold_ingot", 1.0f);
    sm("sand", "glass", 0.1f); sm("cobblestone", "stone", 0.1f); sm("clay_ball", "brick", 0.3f); sm("clay", "terracotta", 0.35f); sm("netherrack", "nether_brick", 0.1f);
    sm("coal_ore", "coal", 0.1f); sm("diamond_ore", "diamond", 1.0f); sm("lapis_ore", "lapis_lazuli", 0.2f); sm("redstone_ore", "redstone", 0.7f); sm("emerald_ore", "emerald", 1.0f);
    for (const char* l : {"oak_log", "spruce_log", "birch_log", "jungle_log", "acacia_log", "dark_oak_log"}) sm(l, "charcoal", 0.15f);
    sm("beef", "cooked_beef", 0.35f); sm("porkchop", "cooked_porkchop", 0.35f); sm("chicken", "cooked_chicken", 0.35f); sm("mutton", "cooked_mutton", 0.35f); sm("rabbit", "cooked_rabbit", 0.35f); sm("potato", "baked_potato", 0.35f);
}

const SmeltRecipe* Recipes::smelt(ItemId in) { for (const SmeltRecipe& r : smelting_) if (r.in == in) return &r; return nullptr; }

static bool matchShapeless(const Recipe& r, const std::vector<ItemId>& items) {
    if (items.size() != r.ing.size()) return false;
    std::vector<bool> used(items.size(), false);
    for (const Ing& g : r.ing) { bool f = false; for (size_t i = 0; i < items.size(); ++i) if (!used[i] && g.matches(items[i])) { used[i] = true; f = true; break; } if (!f) return false; }
    return true;
}

bool Recipes::match(const ItemStack* grid, int gw, int gh, ItemStack& out, const Recipe** which) {
    init();
    int x0 = gw, y0 = gh, x1 = -1, y1 = -1; std::vector<ItemId> items;
    for (int y = 0; y < gh; ++y) for (int x = 0; x < gw; ++x) if (!grid[y * gw + x].empty()) { x0 = std::min(x0, x); y0 = std::min(y0, y); x1 = std::max(x1, x); y1 = std::max(y1, y); items.push_back(grid[y * gw + x].id); }
    if (items.empty()) return false;
    int bw = x1 - x0 + 1, bh = y1 - y0 + 1;
    for (const Recipe& r : recipes_) {
        bool ok = false;
        if (!r.shaped) ok = matchShapeless(r, items);
        else if (r.w == bw && r.h == bh) {
            for (int mirror = 0; mirror < 2 && !ok; ++mirror) {
                bool all = true;
                for (int y = 0; y < bh && all; ++y) for (int x = 0; x < bw && all; ++x) {
                    const Ing& g = r.ing[y * bw + (mirror ? bw - 1 - x : x)]; const ItemStack& s = grid[(y0 + y) * gw + x0 + x];
                    if (g.blank()) { if (!s.empty()) all = false; } else if (s.empty() || !g.matches(s.id)) all = false;
                }
                ok = all;
            }
        }
        if (ok) { out = ItemStack(r.result, r.count); if (which) *which = &r; return true; }
    }
    return false;
}

void FurnaceState::tick() {
    const SmeltRecipe* r = input.empty() ? nullptr : Recipes::smelt(input.id);
    bool canSmelt = r && (output.empty() || (output.id == r->out && output.count < Items::get(r->out).maxStack));
    if (burnTime > 0) --burnTime;
    if (canSmelt && burnTime == 0 && !fuel.empty() && Items::get(fuel.id).fuel > 0) {
        burnTime = burnTotal = Items::get(fuel.id).fuel;
        if (fuel.id == Items::byName("lava_bucket")) fuel = ItemStack(Items::byName("bucket"), 1); else if (--fuel.count <= 0) fuel.clear();
    }
    if (canSmelt && burnTime > 0) {
        cookTotal = r->time;
        if (++cookTime >= cookTotal) {
            cookTime = 0;
            if (output.empty()) output = ItemStack(r->out, 1); else ++output.count;
            storedXp += r->xp; if (--input.count <= 0) input.clear();
        }
    } else if (cookTime > 0) cookTime = std::max(0, cookTime - 2);
}

// ---------------------------------------------------------------- menus
static void layoutInventory(Menu& m, Inventory& inv) {
    m.invFirst = (int)m.slots.size();
    for (int i = 9; i < 36; ++i) m.slots.push_back({&inv.slots[i], SlotKind::Normal});
    for (int i = 0; i < 9; ++i) m.slots.push_back({&inv.slots[i], SlotKind::Normal});
}

std::unique_ptr<Menu> Menu::playerMenu(Inventory& inv) {
    auto m = std::make_unique<Menu>(); m->type = PlayerCrafting; m->inv_ = &inv;
    m->slots.push_back({&m->grid_[0], SlotKind::Output});
    m->gridFirst = 1; m->gridW = m->gridH = 2;
    for (int i = 0; i < 4; ++i) m->slots.push_back({&m->grid_[1 + i], SlotKind::Normal});
    for (int i = 0; i < 4; ++i) m->slots.push_back({&inv.slots[Inventory::ARMOR0 + 3 - i], SlotKind::Armor, 3 - i});   // helmet first
    layoutInventory(*m, inv);
    m->slots.push_back({&inv.slots[Inventory::OFFHAND], SlotKind::Normal});
    return m;
}
std::unique_ptr<Menu> Menu::craftingTable(Inventory& inv) {
    auto m = std::make_unique<Menu>(); m->type = CraftingTable; m->inv_ = &inv;
    m->slots.push_back({&m->grid_[0], SlotKind::Output}); m->gridFirst = 1; m->gridW = m->gridH = 3;
    for (int i = 0; i < 9; ++i) m->slots.push_back({&m->grid_[1 + i], SlotKind::Normal});
    layoutInventory(*m, inv); return m;
}
std::unique_ptr<Menu> Menu::chest(Inventory& inv, std::vector<ItemStack>& cs) {
    auto m = std::make_unique<Menu>(); m->type = Chest; m->inv_ = &inv; m->containerFirst = 0; m->containerCount = (int)cs.size();
    for (auto& s : cs) m->slots.push_back({&s, SlotKind::Normal});
    layoutInventory(*m, inv); return m;
}
std::unique_ptr<Menu> Menu::furnace(Inventory& inv, FurnaceState& fs) {
    auto m = std::make_unique<Menu>(); m->type = Furnace; m->inv_ = &inv; m->containerFirst = 0; m->containerCount = 3;
    m->slots.push_back({&fs.input, SlotKind::Input}); m->slots.push_back({&fs.fuel, SlotKind::Fuel}); m->slots.push_back({&fs.output, SlotKind::Output});
    layoutInventory(*m, inv); return m;
}

void Menu::updateResult() {
    if (gridW == 0) return;
    ItemStack out; ItemStack g[9]; for (int i = 0; i < gridW * gridH; ++i) g[i] = *slots[gridFirst + i].stack;
    if (Recipes::match(g, gridW, gridH, out)) *slots[0].stack = out; else slots[0].stack->clear();
}

bool Menu::accepts(int slot, const ItemStack& s) const {
    const MenuSlot& ms = slots[slot];
    switch (ms.kind) {
        case SlotKind::Output: return false;
        case SlotKind::Armor: return Items::get(s.id).armorSlot == ms.armorSlot;
        case SlotKind::Fuel: return Items::get(s.id).fuel > 0 || s.id == Items::byName("bucket");
        case SlotKind::Input: return Recipes::smelt(s.id) != nullptr;
        default: return true;
    }
}

void Menu::takeOutput(int slot) {
    ItemStack& out = *slots[slot].stack; if (out.empty()) return;
    int max = Items::get(out.id).maxStack;
    if (!cursor.empty() && (!cursor.sameKind(out) || cursor.count + out.count > max)) return;
    if (cursor.empty()) cursor = out; else cursor.count += out.count;
    if (type == Furnace) out.clear();
    else { for (int i = 0; i < gridW * gridH; ++i) { ItemStack& g = *slots[gridFirst + i].stack; if (!g.empty() && --g.count <= 0) g.clear(); } updateResult(); }
}

void Menu::click(int idx, int button, bool shift) {
    if (idx < 0 || idx >= (int)slots.size()) return;
    MenuSlot& ms = slots[idx]; ItemStack& s = *ms.stack;
    if (ms.kind == SlotKind::Output) {
        if (shift) { int guard = 64; ItemStack first = s; while (!s.empty() && guard-- > 0) { ItemStack t = s; ItemStack save = cursor; cursor.clear(); takeOutput(idx); ItemStack got = cursor; cursor = save; if (got.empty() || inv_->add(got) > 0) break; (void)t; } }
        else takeOutput(idx);
        return;
    }
    if (shift) { quickMove(idx); updateResult(); return; }
    int max = s.empty() ? 64 : Items::get(s.id).maxStack;
    if (cursor.empty()) {
        if (s.empty()) return;
        if (button == 0) { cursor = s; s.clear(); } else { int take = (s.count + 1) / 2; cursor = ItemStack(s.id, take, s.damage); s.count -= take; if (s.count <= 0) s.clear(); }
    } else if (s.empty()) {
        if (!accepts(idx, cursor)) return;
        int n = button == 0 ? cursor.count : 1; n = std::min(n, Items::get(cursor.id).maxStack);
        s = ItemStack(cursor.id, n, cursor.damage); cursor.count -= n; if (cursor.count <= 0) cursor.clear();
    } else if (s.sameKind(cursor)) {
        int room = max - s.count; int n = button == 0 ? std::min(room, cursor.count) : std::min(room, 1);
        s.count += n; cursor.count -= n; if (cursor.count <= 0) cursor.clear();
    } else if (accepts(idx, cursor)) { std::swap(s, cursor); }
    updateResult();
}

int Menu::moveInto(ItemStack& src, int from, int to, bool reverse) {
    // merge pass then empty pass over slots [from, to)
    for (int pass = 0; pass < 2 && !src.empty(); ++pass) for (int k = 0; k < to - from && !src.empty(); ++k) {
        int i = reverse ? to - 1 - k : from + k; ItemStack& d = *slots[i].stack; if (!accepts(i, src)) continue;
        int max = Items::get(src.id).maxStack;
        if (pass == 0 && !d.empty() && d.sameKind(src) && d.count < max) { int n = std::min(max - d.count, src.count); d.count += n; src.count -= n; }
        else if (pass == 1 && d.empty()) { int n = std::min(max, src.count); d = ItemStack(src.id, n, src.damage); src.count -= n; }
    }
    if (src.count <= 0) src.clear();
    return src.count;
}

void Menu::quickMove(int idx) {
    ItemStack& s = *slots[idx].stack; if (s.empty()) return;
    int invEnd = invFirst + 36;
    if (idx >= invFirst && idx < invEnd) {
        if (Items::get(s.id).armorSlot >= 0 && type == PlayerCrafting) { for (int i = 1; i < (int)slots.size(); ++i) if (slots[i].kind == SlotKind::Armor && accepts(i, s) && slots[i].stack->empty()) { *slots[i].stack = s; s.clear(); return; } }
        if (type == Chest) moveInto(s, containerFirst, containerFirst + containerCount, false);
        else if (type == Furnace) { if (!moveInto(s, 0, 1, false) && false) {} if (!s.empty()) moveInto(s, 1, 2, false); }
        else if (type == PlayerCrafting || type == CraftingTable) { if (idx < invFirst + 27) moveInto(s, invFirst + 27, invEnd, false); else moveInto(s, invFirst, invFirst + 27, false); }
    } else moveInto(s, invFirst, invEnd, true);
}

void Menu::close(Inventory& inv) {
    if (gridW) for (int i = 0; i < gridW * gridH; ++i) { ItemStack& g = *slots[gridFirst + i].stack; if (!g.empty()) { inv.add(g); g.clear(); } }
    if (!cursor.empty()) { inv.add(cursor); cursor.clear(); }
    if (gridW) slots[0].stack->clear();
}

} // namespace mc
