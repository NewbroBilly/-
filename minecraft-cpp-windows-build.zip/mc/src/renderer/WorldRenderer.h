#pragma once
// GPU side of the world: chunk mesh upload, frustum + cave-visibility culling, sky, fog, selection/crack overlays.
#include "GL.h"
#include "Mesher.h"
#include "Shader.h"
#include "TextureArray.h"
#include "../engine/ThreadPool.h"
#include <glm/glm.hpp>
#include <memory>
#include <mutex>
#include <unordered_map>
#include <unordered_set>

namespace mc {

struct SkyState { glm::vec3 sunDir, top, horizon; float skyLevel, night; };
SkyState computeSky(double dayTicks, bool underwater);

struct FrameParams {
    glm::mat4 rotView, proj; Vec3d cam; int width = 1, height = 1; double dayTicks = 1000; bool underwater = false;
    float renderDistanceBlocks = 128; bool occlusion = true; float time = 0;
};

struct RenderStats { int chunksDrawn = 0, sectionsDrawn = 0, sectionsCulled = 0; long quads = 0; int meshesPending = 0, chunksMeshed = 0; };

class WorldRenderer {
public:
    bool init(const std::string& assetDir, ThreadPool* pool);
    void shutdown();
    void update(World& w, const Vec3d& cam);                 // schedule mesh jobs, upload finished meshes
    void render(World& w, const FrameParams& fp);
    void drawSelection(const FrameParams& fp, const BlockPos& p, const float box[6]);
    void drawCrack(const FrameParams& fp, const BlockPos& p, int stage);
    void onChunkUnloaded(int cx, int cz);
    void clearChunks();
    void drawDynamic(const FrameParams& fp, const std::vector<Vertex>& quads, double dayTicks);   // camera-relative quads (4 vertices each), cutout pass
    const TextureArray& textures() const { return tex_; }
    RenderStats stats;
    int maxJobs = 6;
private:
    struct ChunkGpu {
        GLuint vao[PASS_COUNT] = {0, 0, 0}, vbo[PASS_COUNT] = {0, 0, 0};
        uint32_t first[PASS_COUNT][SECTION_COUNT + 1] = {}; uint16_t vis[SECTION_COUNT] = {};
        bool has[PASS_COUNT] = {false, false, false}; int cx = 0, cz = 0;
    };
    void upload(std::unique_ptr<MeshOutput> m);
    void freeGpu(ChunkGpu& g);
    void setupVao(GLuint vao, GLuint vbo);
    struct Draw { ChunkGpu* g; uint32_t mask; double d2; };
    void collectVisible(const FrameParams& fp, std::vector<Draw>& out);
    void drawPass(const std::vector<Draw>& list, int pass, const FrameParams& fp);
    TextureArray tex_; Shader terrain_, sky_, line_;
    GLuint ibo_ = 0, dummyVao_ = 0, dynVao_ = 0, dynVbo_ = 0, lineVao_ = 0, lineVbo_ = 0;
    std::unordered_map<ChunkPos, std::unique_ptr<ChunkGpu>, ChunkPosHash> gpu_;
    std::unordered_map<ChunkPos, uint32_t, ChunkPosHash> meshedVersion_;
    std::unordered_set<ChunkPos, ChunkPosHash> inflight_;
    std::mutex m_; std::vector<std::unique_ptr<MeshOutput>> done_;
    ThreadPool* pool_ = nullptr; int destroyLayer_[10] = {};
    float frustum_[6][4];
    glm::mat4 vp_;
};

} // namespace mc
