// Declarations-only stand-in for OpenAL (sandbox syntax checking only).
#pragma once
typedef unsigned int ALuint; typedef int ALint; typedef int ALenum; typedef int ALsizei; typedef float ALfloat; typedef void ALvoid;
#define AL_FALSE 0
#define AL_TRUE 1
#define AL_BUFFER 0x1009
#define AL_POSITION 0x1004
#define AL_GAIN 0x100A
#define AL_PITCH 0x1003
#define AL_LOOPING 0x1007
#define AL_SOURCE_STATE 0x1010
#define AL_STOPPED 0x1014
#define AL_INITIAL 0x1011
#define AL_ORIENTATION 0x100F
#define AL_REFERENCE_DISTANCE 0x1020
#define AL_MAX_DISTANCE 0x1023
#define AL_ROLLOFF_FACTOR 0x1021
#define AL_SOURCE_RELATIVE 0x202
#define AL_FORMAT_MONO16 0x1101
#define AL_FORMAT_STEREO16 0x1103
extern "C" {
void alGenBuffers(ALsizei, ALuint*); void alDeleteBuffers(ALsizei, const ALuint*); void alBufferData(ALuint, ALenum, const ALvoid*, ALsizei, ALsizei);
void alGenSources(ALsizei, ALuint*); void alDeleteSources(ALsizei, const ALuint*); void alSourcei(ALuint, ALenum, ALint); void alSourcef(ALuint, ALenum, ALfloat); void alSource3f(ALuint, ALenum, ALfloat, ALfloat, ALfloat);
void alSourcePlay(ALuint); void alSourceStop(ALuint); void alGetSourcei(ALuint, ALenum, ALint*); void alListener3f(ALenum, ALfloat, ALfloat, ALfloat); void alListenerf(ALenum, ALfloat); void alListenerfv(ALenum, const ALfloat*);
}
