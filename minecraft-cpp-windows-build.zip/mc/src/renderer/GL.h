#pragma once
// Minimal OpenGL 3.3 core loader (no external dependency). Call mc::gl::load(getProcAddress) once a context is current.
#include <cstddef>
#include <cstdint>

#if defined(_WIN32)
#define MC_GLAPI __stdcall
#else
#define MC_GLAPI
#endif

typedef unsigned int GLenum; typedef unsigned int GLuint; typedef int GLint; typedef int GLsizei; typedef float GLfloat; typedef unsigned char GLboolean;
typedef unsigned int GLbitfield; typedef char GLchar; typedef ptrdiff_t GLsizeiptr; typedef ptrdiff_t GLintptr; typedef void GLvoid;

#define GL_FALSE 0
#define GL_TRUE 1
#define GL_COLOR_BUFFER_BIT 0x4000
#define GL_DEPTH_BUFFER_BIT 0x100
#define GL_TRIANGLES 0x0004
#define GL_LINES 0x0001
#define GL_TRIANGLE_STRIP 0x0005
#define GL_DEPTH_TEST 0x0B71
#define GL_CULL_FACE 0x0B44
#define GL_BLEND 0x0BE2
#define GL_SCISSOR_TEST 0x0C11
#define GL_POLYGON_OFFSET_FILL 0x8037
#define GL_SRC_ALPHA 0x0302
#define GL_ONE_MINUS_SRC_ALPHA 0x0303
#define GL_BACK 0x0405
#define GL_CCW 0x0901
#define GL_LESS 0x0201
#define GL_LEQUAL 0x0203
#define GL_FLOAT 0x1406
#define GL_UNSIGNED_BYTE 0x1401
#define GL_UNSIGNED_SHORT 0x1403
#define GL_UNSIGNED_INT 0x1405
#define GL_RGBA 0x1908
#define GL_RGB 0x1907
#define GL_RGBA8 0x8058
#define GL_TEXTURE_2D 0x0DE1
#define GL_TEXTURE_2D_ARRAY 0x8C1A
#define GL_TEXTURE0 0x84C0
#define GL_TEXTURE1 0x84C1
#define GL_TEXTURE_MIN_FILTER 0x2801
#define GL_TEXTURE_MAG_FILTER 0x2800
#define GL_TEXTURE_WRAP_S 0x2802
#define GL_TEXTURE_WRAP_T 0x2803
#define GL_TEXTURE_MAX_LEVEL 0x813D
#define GL_NEAREST 0x2600
#define GL_LINEAR 0x2601
#define GL_NEAREST_MIPMAP_LINEAR 0x2702
#define GL_NEAREST_MIPMAP_NEAREST 0x2700
#define GL_LINEAR_MIPMAP_LINEAR 0x2703
#define GL_REPEAT 0x2901
#define GL_CLAMP_TO_EDGE 0x812F
#define GL_ARRAY_BUFFER 0x8892
#define GL_ELEMENT_ARRAY_BUFFER 0x8893
#define GL_STATIC_DRAW 0x88E4
#define GL_DYNAMIC_DRAW 0x88E8
#define GL_STREAM_DRAW 0x88E0
#define GL_VERTEX_SHADER 0x8B31
#define GL_FRAGMENT_SHADER 0x8B30
#define GL_COMPILE_STATUS 0x8B81
#define GL_LINK_STATUS 0x8B82
#define GL_INFO_LOG_LENGTH 0x8B84
#define GL_FRAMEBUFFER 0x8D40
#define GL_RENDERBUFFER 0x8D41
#define GL_COLOR_ATTACHMENT0 0x8CE0
#define GL_DEPTH_ATTACHMENT 0x8D00
#define GL_DEPTH_COMPONENT24 0x81A6
#define GL_FRAMEBUFFER_COMPLETE 0x8CD5
#define GL_VERSION 0x1F02
#define GL_RENDERER 0x1F01
#define GL_NO_ERROR 0
#define GL_UNPACK_ALIGNMENT 0x0CF5
#define GL_MAJOR_VERSION 0x821B
#define GL_MINOR_VERSION 0x821C

#define MC_GL_FUNCS(X) \
    X(void, Clear, (GLbitfield)) X(void, ClearColor, (GLfloat, GLfloat, GLfloat, GLfloat)) X(void, Enable, (GLenum)) X(void, Disable, (GLenum)) \
    X(void, BlendFunc, (GLenum, GLenum)) X(void, DepthFunc, (GLenum)) X(void, DepthMask, (GLboolean)) X(void, CullFace, (GLenum)) X(void, FrontFace, (GLenum)) \
    X(void, Viewport, (GLint, GLint, GLsizei, GLsizei)) X(void, DrawArrays, (GLenum, GLint, GLsizei)) X(void, DrawElements, (GLenum, GLsizei, GLenum, const void*)) \
    X(void, BindTexture, (GLenum, GLuint)) X(void, GenTextures, (GLsizei, GLuint*)) X(void, DeleteTextures, (GLsizei, const GLuint*)) \
    X(void, TexParameteri, (GLenum, GLenum, GLint)) X(void, TexImage2D, (GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum, const void*)) \
    X(void, TexImage3D, (GLenum, GLint, GLint, GLsizei, GLsizei, GLsizei, GLint, GLenum, GLenum, const void*)) \
    X(void, TexSubImage3D, (GLenum, GLint, GLint, GLint, GLint, GLsizei, GLsizei, GLsizei, GLenum, GLenum, const void*)) \
    X(void, ReadPixels, (GLint, GLint, GLsizei, GLsizei, GLenum, GLenum, void*)) X(GLenum, GetError, ()) X(void, PixelStorei, (GLenum, GLint)) \
    X(void, LineWidth, (GLfloat)) X(const unsigned char*, GetString, (GLenum)) X(void, GetIntegerv, (GLenum, GLint*)) X(void, Scissor, (GLint, GLint, GLsizei, GLsizei)) \
    X(void, PolygonOffset, (GLfloat, GLfloat)) X(void, ActiveTexture, (GLenum)) X(void, Finish, ()) \
    X(void, GenBuffers, (GLsizei, GLuint*)) X(void, BindBuffer, (GLenum, GLuint)) X(void, BufferData, (GLenum, GLsizeiptr, const void*, GLenum)) \
    X(void, BufferSubData, (GLenum, GLintptr, GLsizeiptr, const void*)) X(void, DeleteBuffers, (GLsizei, const GLuint*)) \
    X(GLuint, CreateShader, (GLenum)) X(void, ShaderSource, (GLuint, GLsizei, const GLchar* const*, const GLint*)) X(void, CompileShader, (GLuint)) \
    X(void, GetShaderiv, (GLuint, GLenum, GLint*)) X(void, GetShaderInfoLog, (GLuint, GLsizei, GLsizei*, GLchar*)) X(GLuint, CreateProgram, ()) \
    X(void, AttachShader, (GLuint, GLuint)) X(void, LinkProgram, (GLuint)) X(void, GetProgramiv, (GLuint, GLenum, GLint*)) \
    X(void, GetProgramInfoLog, (GLuint, GLsizei, GLsizei*, GLchar*)) X(void, UseProgram, (GLuint)) X(void, DeleteShader, (GLuint)) X(void, DeleteProgram, (GLuint)) \
    X(GLint, GetUniformLocation, (GLuint, const GLchar*)) X(void, Uniform1i, (GLint, GLint)) X(void, Uniform1f, (GLint, GLfloat)) X(void, Uniform2f, (GLint, GLfloat, GLfloat)) \
    X(void, Uniform3f, (GLint, GLfloat, GLfloat, GLfloat)) X(void, Uniform4f, (GLint, GLfloat, GLfloat, GLfloat, GLfloat)) \
    X(void, UniformMatrix4fv, (GLint, GLsizei, GLboolean, const GLfloat*)) X(void, EnableVertexAttribArray, (GLuint)) X(void, DisableVertexAttribArray, (GLuint)) \
    X(void, VertexAttribPointer, (GLuint, GLint, GLenum, GLboolean, GLsizei, const void*)) \
    X(void, GenVertexArrays, (GLsizei, GLuint*)) X(void, BindVertexArray, (GLuint)) X(void, DeleteVertexArrays, (GLsizei, const GLuint*)) X(void, GenerateMipmap, (GLenum)) \
    X(void, GenFramebuffers, (GLsizei, GLuint*)) X(void, BindFramebuffer, (GLenum, GLuint)) X(void, FramebufferRenderbuffer, (GLenum, GLenum, GLenum, GLuint)) \
    X(void, GenRenderbuffers, (GLsizei, GLuint*)) X(void, BindRenderbuffer, (GLenum, GLuint)) X(void, RenderbufferStorage, (GLenum, GLenum, GLsizei, GLsizei)) \
    X(GLenum, CheckFramebufferStatus, (GLenum))

#define X(ret, name, args) extern ret (MC_GLAPI *gl##name) args;
MC_GL_FUNCS(X)
#undef X

namespace mc { namespace gl {
typedef void* (*GetProc)(const char*);
bool load(GetProc getProc);     // returns false if a required function is missing
} }
