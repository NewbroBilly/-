#pragma once
// Batched 2D renderer for HUD, menus and text (screen-pixel coordinates, origin top-left).
#include "GL.h"
#include "Shader.h"
#include "TextureArray.h"
#include "../inventory/Item.h"
#include <string>
#include <unordered_map>
#include <vector>

namespace mc {

class UIRenderer {
public:
    bool init(const std::string& assetDir, const TextureArray* arr);
    void shutdown();
    void begin(int w, int h);
    void end();
    void rect(float x, float y, float w, float h, uint32_t rgba);                                  // 0xRRGGBBAA
    void sheet(GLuint tex, float x, float y, float w, float h, float u0, float v0, float u1, float v1, uint32_t rgba = 0xFFFFFFFF);
    void tile(int layer, float x, float y, float w, float h, uint32_t rgba = 0xFFFFFFFF);
    void blockIcon(BlockId id, float x, float y, float size);
    void itemIcon(const ItemStack& s, float x, float y, float size);
    void text(const std::string& s, float x, float y, int scale, uint32_t rgba, bool shadow = true);
    float textWidth(const std::string& s, int scale) const;
    GLuint loadSheet(const std::string& relPath, int& w, int& h);        // cached 2D texture from assets/textures/<rel>.png (0 if missing)
    GLuint fontTexture() const { return font_; }
    int width() const { return sw_; } int height() const { return sh_; }
private:
    struct V { float x, y, u, v; uint8_t r, g, b, a; float mode, layer; };
    void quad(const float p[8], const float uv[8], float mode, float layer, uint32_t rgba);
    void flush();
    static int glyphIndex(uint32_t cp);
    Shader sh_prog_; GLuint vao_ = 0, vbo_ = 0, font_ = 0, curSheet_ = 0; std::vector<V> verts_;
    const TextureArray* arr_ = nullptr; int sw_ = 1, sh_ = 1; std::string dir_;
    struct Sheet { GLuint id; int w, h; }; std::unordered_map<std::string, Sheet> sheets_;
};

} // namespace mc
