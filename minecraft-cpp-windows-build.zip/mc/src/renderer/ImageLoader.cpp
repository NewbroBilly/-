#include "ImageLoader.h"
#include <cstdio>
#if defined(MC_HAVE_STB) || __has_include("stb_image.h")
#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_PNG
#include "stb_image.h"
namespace mc {
bool loadImageRGBA(const std::string& path, int& w, int& h, std::vector<uint8_t>& rgba) {
    int n; unsigned char* d = stbi_load(path.c_str(), &w, &h, &n, 4); if (!d) return false;
    rgba.assign(d, d + (size_t)w * h * 4); stbi_image_free(d); return true;
}
}
#else
namespace mc {
bool loadImageRGBA(const std::string& path, int& w, int& h, std::vector<uint8_t>& rgba) {
    FILE* f = std::fopen((path + ".rgba").c_str(), "rb"); if (!f) return false;
    int32_t hd[2]; if (std::fread(hd, 4, 2, f) != 2) { std::fclose(f); return false; }
    w = hd[0]; h = hd[1]; rgba.resize((size_t)w * h * 4); size_t r = std::fread(rgba.data(), 1, rgba.size(), f); std::fclose(f); return r == rgba.size();
}
}
#endif
