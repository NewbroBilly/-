// Prints every texture name the game needs (block/..., item/...). Used by tools/make_assets.py.
#include "../src/inventory/Item.h"
#include <cstdio>
using namespace mc;
int main() {
    Blocks::init();
    for (int i = 0; i < 10; ++i) Blocks::textureIndex("block/destroy_stage_" + std::to_string(i));
    Items::init();
    for (auto& n : Blocks::textureNames()) std::printf("%s\n", n.c_str());
}
