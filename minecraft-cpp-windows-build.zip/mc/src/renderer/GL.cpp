#include "GL.h"
#include <cstdio>

#define X(ret, name, args) ret (MC_GLAPI *gl##name) args = nullptr;
MC_GL_FUNCS(X)
#undef X

namespace mc { namespace gl {
bool load(GetProc getProc) {
    bool ok = true;
#define X(ret, name, args) gl##name = reinterpret_cast<ret (MC_GLAPI *) args>(getProc("gl" #name)); if (!gl##name) { std::fprintf(stderr, "[gl] missing gl%s\n", #name); ok = false; }
    MC_GL_FUNCS(X)
#undef X
    return ok;
}
} }
