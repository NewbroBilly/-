#pragma once
typedef struct ALCdevice ALCdevice; typedef struct ALCcontext ALCcontext;
extern "C" { ALCdevice* alcOpenDevice(const char*); ALCcontext* alcCreateContext(ALCdevice*, const int*); int alcMakeContextCurrent(ALCcontext*); void alcDestroyContext(ALCcontext*); int alcCloseDevice(ALCdevice*); }
