#include "TextureArray.h"
#include "ImageLoader.h"
#include <cstdio>
namespace mc {

bool TextureArray::build(const std::string& dir, const std::vector<std::string>& names, int tileSize) {
    layers_ = (int)names.size(); tile_ = tileSize > 0 ? tileSize : 16; missing_ = 0;
    std::vector<std::vector<uint8_t>> imgs(names.size()); std::vector<int> iw(names.size(), 0), ih(names.size(), 0);
    for (size_t i = 0; i < names.size(); ++i) {
        if (!loadImageRGBA(dir + "/textures/" + names[i] + ".png", iw[i], ih[i], imgs[i])) { ++missing_; iw[i] = 0; }
        else if (tileSize == 0 && names[i] == "block/stone") tile_ = iw[i];
    }
    const int S = tile_;
    std::vector<uint8_t> data((size_t)S * S * 4 * names.size());
    for (size_t i = 0; i < names.size(); ++i) {
        uint8_t* dst = &data[i * (size_t)S * S * 4];
        for (int y = 0; y < S; ++y) for (int x = 0; x < S; ++x) {
            uint8_t* d = dst + (y * S + x) * 4;
            if (iw[i] == 0) { bool c = ((x / (S / 2)) + (y / (S / 2))) & 1; d[0] = c ? 255 : 0; d[1] = 0; d[2] = c ? 255 : 0; d[3] = 255; continue; }
            int sx = x * iw[i] / S, sy = y * (iw[i] < ih[i] ? iw[i] : ih[i]) / S;     // nearest; animated strips use the first frame
            const uint8_t* s = &imgs[i][((size_t)sy * iw[i] + sx) * 4]; d[0] = s[0]; d[1] = s[1]; d[2] = s[2]; d[3] = s[3];
        }
    }
    glGenTextures(1, &id_); glBindTexture(GL_TEXTURE_2D_ARRAY, id_);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage3D(GL_TEXTURE_2D_ARRAY, 0, GL_RGBA8, S, S, layers_, 0, GL_RGBA, GL_UNSIGNED_BYTE, data.data());
    glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MAX_LEVEL, 4);
    glGenerateMipmap(GL_TEXTURE_2D_ARRAY);
    glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_T, GL_REPEAT);
    if (missing_) std::fprintf(stderr, "[textures] %d of %d textures missing (magenta placeholders used)\n", missing_, layers_);
    return true;
}
}
