# Minecraft C++ (клон Minecraft Java Edition на собственном движке)

Игра написана на C++20 с нуля: без Unity/Unreal/Godot. Графика — OpenGL (контекст 4.5, при отсутствии — 3.3 core),
окно и ввод — GLFW, математика — GLM, текстуры — stb_image, звук — OpenAL + stb_vorbis, сборка — CMake.
**Текущая версия: этапы 1–10 в основном реализованы, 11 (мобы/ИИ) и 13 (измерения) ещё не начаты — см. `docs/STATUS.md`.**

## Windows: получить minecraft.exe

**Вариант 1 (на своём ПК, ~10 минут):** установите [Visual Studio 2022 Community](https://visualstudio.microsoft.com/) (галочка «Разработка классических приложений на C++») и [CMake](https://cmake.org/download/) (галочка «Add to PATH»).
Распакуйте архив и дважды щёлкните `build_windows.bat` — готовая игра появится в `dist\Minecraft\minecraft.exe` (одним файлом, без установки библиотек; рядом папка `assets`).

**Вариант 2 (без установки компилятора):** создайте бесплатный репозиторий на GitHub, загрузите в него содержимое проекта, откройте вкладку *Actions* → *build* → готовый `Minecraft-Windows-x64` скачайте из *Artifacts*.

## Сборка и запуск (Linux/macOS)

Нужны: компилятор C++20 (GCC 11+, Clang 14+, MSVC 2022), CMake 3.16+, интернет при первой конфигурации
(CMake сам скачает GLFW, GLM, stb и, если не найден в системе, OpenAL Soft).

```bash
# Linux: sudo apt install build-essential cmake libx11-dev libxrandr-dev libxinerama-dev libxcursor-dev libxi-dev libwayland-dev libxkbcommon-dev libgl-dev libopenal-dev
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
./build/minecraft            # ресурсы копируются рядом с бинарником (build/assets)
ctest --test-dir build       # тесты симуляции без графики
```
Параметры: `--assets <папка>`, `--saves <папка>`. Сохранения лежат в `saves/<имя мира>/`, настройки — `options.txt`.

## Управление

| Клавиша | Действие |
|---|---|
| W A S D, Пробел, Shift, Ctrl | движение, прыжок, красться, бег |
| Двойной Пробел (Творческий) | включить/выключить полёт |
| ЛКМ (удерживать) / ПКМ | ломать блок / ставить блок, открывать верстак, печь, сундук, есть, вёдра |
| СКМ (Творческий) | взять блок |
| 1–9, колесо | выбор ячейки хотбара |
| E | инвентарь (Творческий — каталог всех блоков и предметов) |
| Q (Ctrl+Q) | выбросить предмет (стак) |
| F3 | отладочный экран |
| F4 | сменить режим: Выживание → Творческий → Приключение → Наблюдатель |
| F11 | полный экран |
| Esc | пауза / закрыть окно |

## Что внутри

```
src/core        типы, ГПСЧ (xoroshiro), шум Перлина
src/world       реестр блоков (≈190), Chunk (16×384×16, секции 16³), World, ChunkManager (конвейер чанков)
src/terrain     биомы (21), TerrainGenerator (климат → высота → 3D-плотность → пещеры → поверхность), Decorator (руды, деревья, растения, подземелья)
src/lighting    небесный + блочный свет, инкрементальное добавление/удаление через границы чанков
src/fluid       жидкости как в Java Edition: источники, уровни 1–7, падающий столб, поиск склона, бесконечная вода, лава/вода → обсидиан/булыжник/камень
src/physics     AABB, столкновения (ступеньки 0.6, приседание у края), рейкаст
src/player      движение 20 TPS по формулам ванили, голод, здоровье, утопление, урон от падения, опыт, 4 режима
src/inventory   предметы (инструменты, броня, еда), инвентарь, рецепты (формы + бесформенные), печь, меню-контейнеры (клики ЛКМ/ПКМ/Shift)
src/save        region-файлы 32×32 чанков (RLE), level.dat (seed, время, игрок, инвентарь), контейнеры
src/renderer    OpenGL-загрузчик, шейдеры, texture array, Mesher (greedy + AO + сглаженный свет), WorldRenderer, UIRenderer
src/engine      окно/ввод GLFW, ThreadPool
src/audio       OpenAL: события выводятся из структуры assets/sounds (dig/step/liquid/mob/…)
src/game        Game: меню, HUD, инвентари, управление, главный цикл; Settings + локализация RU/EN
tests, tools    тесты без графики; mapgen (карта биомов); render_test (рендер без монитора через Mesa EGL); make_assets.py
```

Генерация детерминирована: один seed → один мир, независимо от числа потоков и порядка загрузки чанков
(декорации чанка считаются «проигрыванием» потоков фич соседей с независимым ГПСЧ на каждую фичу).

## Ресурсы

* `assets/textures` — из вашего пака `Vintage1_14-1_19` (230 текстур); 49 недостающих (земля, вода, лава, шерсть, терракота, глубинный сланец, факел…) нарисованы
  скриптом `tools/make_assets.py` — это собственные ресурсы. Шрифт (с кириллицей) сгенерирован из DejaVu Sans Mono (свободная лицензия).
* `assets/sounds` — подмножество вашего пака `Minecraft Sound Pack 1.17` (11 МБ). Музыки в паке нет: положите `.ogg` в `assets/music/menu/` и `assets/music/game/`.
* Пересборка ресурсов: `build/list_textures > needed.txt && python3 tools/make_assets.py <pack>/assets/minecraft/textures assets needed.txt`.
* Текстуры и звуки Mojang принадлежат их правообладателям: не публикуйте их вместе с игрой без разрешения/лицензии.
