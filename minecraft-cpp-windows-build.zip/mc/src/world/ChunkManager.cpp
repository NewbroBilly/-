#include "ChunkManager.h"
#include "../lighting/LightEngine.h"
#include <algorithm>
#include <chrono>

namespace mc {

ChunkManager::ChunkManager(World& w, ThreadPool& pool, uint64_t seed, SaveSystem* save) : w_(w), pool_(pool), save_(save), tg_(seed), dec_(seed, tg_) {}

void ChunkManager::drain() {
    std::vector<std::shared_ptr<Chunk>> t; std::vector<ChunkPos> d;
    { std::lock_guard<std::mutex> l(m_); t.swap(doneTerrain_); d.swap(doneDecor_); }
    for (auto& c : t) { --inflight_; requested_.erase({c->cx, c->cz}); w_.addChunk(c); }
    for (auto& p : d) {
        --inflight_; decorating_.erase({p.x, p.z});
        Chunk* c = w_.chunk(p.x, p.z); if (c) { c->meshDirty = true; }
    }
}

void ChunkManager::update(int pcx, int pcz, int radius, double budgetMs) {
    using clock = std::chrono::steady_clock; auto t0 = clock::now();
    auto elapsed = [&] { return std::chrono::duration<double, std::milli>(clock::now() - t0).count(); };
    drain();
    const int R = radius + 3;                        // terrain ring; +1 decoration, +1 light, +1 mesh neighbours
    std::vector<std::pair<int, std::pair<int, int>>> want;
    for (int dz = -R; dz <= R; ++dz) for (int dx = -R; dx <= R; ++dx) want.push_back({dx * dx + dz * dz, {pcx + dx, pcz + dz}});   // square ring: every chunk inside the lit radius has its full dependency neighbourhood
    std::sort(want.begin(), want.end());
    const size_t maxInflight = pool_.size() * 3 + 2;
    // 1. terrain
    for (auto& e : want) {
        if (inflight_ >= maxInflight) break;
        int cx = e.second.first, cz = e.second.second;
        if (w_.chunk(cx, cz) || requested_.count({cx, cz})) continue;
        requested_.insert({cx, cz}); ++inflight_;
        uint64_t seed = tg_.seed(); SaveSystem* save = save_; const TerrainGenerator* tg = &tg_;
        pool_.submit([this, cx, cz, save, tg, seed] {
            (void)seed;
            auto c = std::make_shared<Chunk>(cx, cz);
            tg->generate(*c);
            if (save && save->loadChunk(cx, cz, *c)) { c->fromSave = true; c->status.store(ChunkStatus::Decorated); }
            std::lock_guard<std::mutex> l(m_); doneTerrain_.push_back(c);
        });
    }
    // 2. decoration (worker): needs terrain data of the whole 3x3
    for (auto& e : want) {
        if (inflight_ >= maxInflight + 4) break;
        int cx = e.second.first, cz = e.second.second;
        Chunk* c = w_.chunk(cx, cz); if (!c || c->status.load() != ChunkStatus::Terrain || decorating_.count({cx, cz})) continue;
        std::shared_ptr<Chunk> nb[9]; bool ok = true;
        for (int dz = -1; dz <= 1 && ok; ++dz) for (int dx = -1; dx <= 1; ++dx) { auto s = w_.chunkShared(cx + dx, cz + dz); if (!s || s->status.load() == ChunkStatus::Empty) { ok = false; break; } nb[(dz + 1) * 3 + dx + 1] = s; }
        if (!ok) continue;
        decorating_.insert({cx, cz}); ++inflight_;
        Decorator* dec = &dec_;
        pool_.submit([this, nb, dec, cx, cz] {
            Chunk* raw[9]; for (int i = 0; i < 9; ++i) raw[i] = nb[i].get();
            dec->decorate(*nb[4], raw);
            std::lock_guard<std::mutex> l(m_); doneDecor_.push_back(ChunkPos(cx, cz));
        });
    }
    // 3. lighting on the main thread, nearest first, within the time budget
    for (auto& e : want) {
        if (elapsed() > budgetMs) break;
        Chunk* c = w_.chunk(e.second.first, e.second.second); if (!c || c->status.load() != ChunkStatus::Decorated || c->hasLight()) continue;
        bool ok = true;
        for (int dz = -1; dz <= 1 && ok; ++dz) for (int dx = -1; dx <= 1; ++dx) { Chunk* n = w_.chunk(c->cx + dx, c->cz + dz); if (!n || n->status.load() < ChunkStatus::Decorated || decorating_.count({n->cx, n->cz})) { ok = false; break; } }
        if (!ok) continue;
        w_.lighting().initChunk(*c); c->status.store(ChunkStatus::Lit);
    }
    // 4. unload far chunks
    std::vector<ChunkPos> drop;
    for (auto& kv : w_.chunks()) { int dx = kv.first.x - pcx, dz = kv.first.z - pcz; if (std::max(std::abs(dx), std::abs(dz)) > R + 2) drop.push_back(kv.first); }
    lit_ = 0; for (auto& kv : w_.chunks()) if (kv.second->status.load() == ChunkStatus::Lit) ++lit_;
    for (auto& p : drop) {
        if (decorating_.count({p.x, p.z})) continue;
        auto c = w_.removeChunk(p.x, p.z);
        if (c && c->modified && save_) save_->saveChunk(*c);
        if (onUnload) onUnload(p.x, p.z);
    }
    // drop block ticks that belong to unloaded chunks lazily (World::tick ignores them)
}

void ChunkManager::saveAll() {
    if (!save_) return;
    for (auto& kv : w_.chunks()) if (kv.second->modified) { save_->saveChunk(*kv.second); kv.second->modified = false; }
}

} // namespace mc
