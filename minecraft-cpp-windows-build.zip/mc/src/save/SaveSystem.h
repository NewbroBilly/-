#pragma once
// World persistence: region files (32x32 chunks, only modified chunks are stored), level.dat with seed/time/player.
#include "../player/Player.h"
#include <mutex>
#include <string>

namespace mc {

struct LevelData {
    std::string name = "World"; uint64_t seed = 0; uint64_t gameTime = 0, dayTime = 1000;
    GameMode mode = GameMode::Survival; bool hasPlayer = false; int version = 1;
};

class SaveSystem {
public:
    explicit SaveSystem(const std::string& worldDir);
    const std::string& dir() const { return dir_; }
    bool loadChunk(int cx, int cz, Chunk& out);          // fills blocks; false if not stored
    void saveChunk(const Chunk& c);
    bool loadLevel(LevelData& out, Player* player);
    bool saveLevel(const LevelData& ld, const Player* player);
    static std::vector<std::string> listWorlds(const std::string& savesDir);
    static bool readLevelHeader(const std::string& worldDir, LevelData& out);
private:
    std::string regionPath(int rx, int rz) const;
    std::string dir_; std::mutex m_;
};

} // namespace mc
