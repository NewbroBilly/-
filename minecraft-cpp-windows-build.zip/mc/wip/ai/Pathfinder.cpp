#include "Pathfinder.h"
#include <queue>
#include <unordered_map>

namespace mc {

static bool passable(const World& w, int x, int y, int z) {
    BlockState s = w.getBlock(x, y, z); const BlockInfo& b = blockOf(s);
    return s == 0 || (!b.solid && b.id != B::COBWEB) || (b.shape == Shape::Box && !b.solid);
}
static bool isWater(const World& w, int x, int y, int z) { return blockOf(w.getBlock(x, y, z)).fluid; }
static bool isLava(const World& w, int x, int y, int z) { return stateId(w.getBlock(x, y, z)) == B::LAVA; }

// A node is the block cell of the mob's feet: it needs room for the body and solid ground (or water for swimmers) below.
bool pathStandable(const World& w, int x, int y, int z, int height, bool swimmer, bool avoidWater) {
    for (int i = 0; i < height; ++i) {
        if (!passable(w, x, y + i, z) && !isWater(w, x, y + i, z)) return false;
        if (isLava(w, x, y + i, z)) return false;
    }
    BlockState below = w.getBlock(x, y - 1, z); const BlockInfo& bb = blockOf(below);
    if (bb.solid) { return !(stateId(below) == B::CACTUS || stateId(below) == B::MAGMA_BLOCK); }
    if (bb.fluid) { if (stateId(below) == B::LAVA) return false; return swimmer || !avoidWater ? true : false; }
    return false;
}

struct NodeInfo { float g; int parent; };

PathResult findPath(const World& w, const PathRequest& r) {
    PathResult out;
    auto key = [](int x, int y, int z) { return ((int64_t)(x + 1048576) << 40) ^ ((int64_t)(z + 1048576) << 16) ^ (int64_t)(y + 512); };
    struct QItem { float f; int idx; bool operator>(const QItem& o) const { return f > o.f; } };
    std::vector<BlockPos> nodes; std::vector<NodeInfo> info; std::unordered_map<int64_t, int> seen;
    std::priority_queue<QItem, std::vector<QItem>, std::greater<QItem>> open;
    auto heur = [&](const BlockPos& p) { return (float)(std::abs(p.x - r.goal.x) + std::abs(p.z - r.goal.z) + std::abs(p.y - r.goal.y) * 0.7f); };
    BlockPos s = r.start;
    // the mob may stand slightly inside a block edge: lift to a standable cell if needed
    if (!pathStandable(w, s.x, s.y, s.z, r.height, r.swimmer, r.avoidWater)) { if (pathStandable(w, s.x, s.y + 1, s.z, r.height, r.swimmer, r.avoidWater)) ++s.y; else if (pathStandable(w, s.x, s.y - 1, s.z, r.height, r.swimmer, r.avoidWater)) --s.y; }
    nodes.push_back(s); info.push_back({0, -1}); seen[key(s.x, s.y, s.z)] = 0; open.push({heur(s), 0});
    int best = 0; float bestH = heur(s); int goalNode = -1;
    static const int D4[4][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    while (!open.empty() && out.expanded < r.maxNodes) {
        QItem it = open.top(); open.pop(); int ci = it.idx; BlockPos c = nodes[ci];
        if (it.f - heur(c) > info[ci].g + 0.01f && false) continue;
        ++out.expanded;
        if (std::abs(c.x - r.goal.x) + std::abs(c.z - r.goal.z) <= 0 && std::abs(c.y - r.goal.y) <= 1) { goalNode = ci; break; }
        float h = heur(c); if (h < bestH) { bestH = h; best = ci; }
        for (auto& d : D4) {
            int nx = c.x + d[0], nz = c.z + d[1];
            if (std::abs(nx - s.x) > r.maxRange || std::abs(nz - s.z) > r.maxRange) continue;
            int cands[2 + 8]; int nc = 0; cands[nc++] = c.y; cands[nc++] = c.y + 1;
            for (int dy = 1; dy <= r.maxDrop; ++dy) cands[nc++] = c.y - dy;
            for (int k = 0; k < nc; ++k) {
                int ny = cands[k];
                if (!pathStandable(w, nx, ny, nz, r.height, r.swimmer, r.avoidWater)) continue;
                // moving horizontally at level c.y: the swept cells must be free
                if (ny > c.y && !passable(w, c.x, c.y + r.height, c.z)) continue;           // head room to jump
                if (ny < c.y) { bool ok = true; for (int i = 0; i < r.height; ++i) if (!passable(w, nx, c.y + i, nz) && !isWater(w, nx, c.y + i, nz)) ok = false; if (!ok) continue; }
                float cost = 1.0f + (ny > c.y ? 0.6f : 0) + (ny < c.y ? 0.3f * (c.y - ny) : 0) + (isWater(w, nx, ny, nz) ? 5.0f : 0);
                BlockState nbelow = w.getBlock(nx, ny - 1, nz); if (stateId(nbelow) == B::LAVA) continue;
                // cells next to lava are risky
                for (auto& e : D4) if (isLava(w, nx + e[0], ny, nz + e[1])) cost += 6;
                float g = info[ci].g + cost; int64_t kk = key(nx, ny, nz); auto f = seen.find(kk);
                if (f != seen.end()) { if (g >= info[f->second].g) continue; info[f->second] = {g, ci}; open.push({g + heur(nodes[f->second]), f->second}); }
                else { int ni = (int)nodes.size(); nodes.push_back(BlockPos(nx, ny, nz)); info.push_back({g, ci}); seen[kk] = ni; open.push({g + heur(nodes[ni]), ni}); }
                break;                                                              // first valid vertical option per direction
            }
        }
    }
    int end = goalNode >= 0 ? goalNode : best; out.reached = goalNode >= 0;
    for (int i = end; i >= 0; i = info[i].parent) out.nodes.push_back(nodes[i]);
    std::reverse(out.nodes.begin(), out.nodes.end());
    return out;
}

} // namespace mc
