#pragma once
// Minecraft-style block fluids: sources, flowing levels 1..7, falling columns, slope search,
// infinite water sources, lava/water reactions (obsidian, cobblestone, stone).
#include "../world/World.h"
#include <vector>

namespace mc {

class FluidSimulation {
public:
    explicit FluidSimulation(World& w) : w_(w) {}
    void tick(const BlockPos& p);               // scheduled fluid tick
    int tickDelay(BlockId fluid) const;         // water 5, lava 30 (10 in the Nether)
    bool lavaReact(const BlockPos& p);          // lava next to water -> obsidian / cobblestone; true if converted
private:
    struct SpreadEntry { int dir; BlockState state; };
    int dropOff(BlockId f) const;
    int slopeFindDistance(BlockId f) const;
    bool canConvertToSource(BlockId f) const { return f == B::WATER; }
    static bool canHold(BlockState s);
    static bool isWall(BlockState s) { return Blocks::get(stateId(s)).solid; }
    BlockState flowing(BlockId f, int amount, bool falling) const;
    BlockState newLiquid(BlockId f, const BlockPos& p) const;
    bool isHole(BlockId f, const BlockPos& p, BlockState below) const;
    bool canReplaceWith(BlockState to, BlockId f, int dir) const;
    bool canSpreadTo(BlockId f, int dir, BlockState toState) const;
    void spreadTo(BlockId f, const BlockPos& to, int dir, BlockState toState, BlockState newState);
    int sourceNeighbours(BlockId f, const BlockPos& p) const;
    int slopeDistance(BlockId f, const BlockPos& p, int dist, int fromDir) const;
    std::vector<SpreadEntry> getSpread(BlockId f, const BlockPos& p) const;
    void spread(const BlockPos& p, BlockState cur);
    void spreadToSides(const BlockPos& p, BlockState cur);
    World& w_;
};

} // namespace mc
