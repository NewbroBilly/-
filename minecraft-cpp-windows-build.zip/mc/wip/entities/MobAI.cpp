#include "MobManager.h"
#include <algorithm>
#include <cmath>

namespace mc {

static const MobInfo TABLE[(int)MobType::Count] = {
    // id, ru, w, h, hp, speed, hostile, attack, follow, xp, say, hurt, death, step
    {"pig", "Свинья", 0.9f, 0.9f, 10, 0.25f, false, 0, 0, 2, "mob.pig.say", "mob.pig.say", "mob.pig.death", "mob.pig.step"},
    {"cow", "Корова", 0.9f, 1.4f, 10, 0.20f, false, 0, 0, 2, "mob.cow.say", "mob.cow.hurt", "mob.cow.hurt", "mob.cow.step"},
    {"sheep", "Овца", 0.9f, 1.3f, 8, 0.23f, false, 0, 0, 2, "mob.sheep.say", "mob.sheep.say", "mob.sheep.say", "mob.sheep.step"},
    {"chicken", "Курица", 0.4f, 0.7f, 4, 0.25f, false, 0, 0, 2, "mob.chicken.say", "mob.chicken.hurt", "mob.chicken.hurt", "mob.chicken.step"},
    {"wolf", "Волк", 0.6f, 0.85f, 8, 0.30f, false, 4, 16, 2, "mob.wolf.panting", "mob.wolf.hurt", "mob.wolf.death", "mob.wolf.step"},
    {"cat", "Кошка", 0.6f, 0.7f, 10, 0.30f, false, 0, 0, 2, "mob.cat.meow", "mob.cat.hitt", "mob.cat.hitt", ""},
    {"rabbit", "Кролик", 0.4f, 0.5f, 3, 0.30f, false, 0, 0, 2, "mob.rabbit.idle", "mob.rabbit.hurt", "mob.rabbit.bunnymurder", "mob.rabbit.hop"},
    {"zombie", "Зомби", 0.6f, 1.95f, 20, 0.23f, true, 3, 35, 5, "mob.zombie.say", "mob.zombie.hurt", "mob.zombie.death", "mob.zombie.step"},
    {"skeleton", "Скелет", 0.6f, 1.99f, 20, 0.25f, true, 2, 16, 5, "mob.skeleton.say", "mob.skeleton.hurt", "mob.skeleton.death", "mob.skeleton.step"},
    {"creeper", "Крипер", 0.6f, 1.7f, 20, 0.25f, true, 0, 16, 5, "mob.creeper.say", "mob.creeper.say", "mob.creeper.death", ""},
    {"spider", "Паук", 1.4f, 0.9f, 16, 0.30f, true, 2, 16, 5, "mob.spider.say", "mob.spider.say", "mob.spider.death", "mob.spider.step"},
    {"enderman", "Эндермен", 0.6f, 2.9f, 40, 0.30f, false, 7, 64, 5, "mob.endermen.idle", "mob.endermen.hit", "mob.endermen.death", ""},
    {"villager", "Житель", 0.6f, 1.95f, 20, 0.50f, false, 0, 0, 0, "mob.villager.idle", "mob.villager.hit", "mob.villager.death", ""},
    {"iron_golem", "Железный голем", 1.4f, 2.7f, 100, 0.25f, false, 15, 16, 0, "", "mob.irongolem.hit", "mob.irongolem.death", "mob.irongolem.walk"},
};
const MobInfo& mobInfo(MobType t) { return TABLE[(int)t]; }
bool mobFromName(const std::string& id, MobType& out) { for (int i = 0; i < (int)MobType::Count; ++i) if (id == TABLE[i].id) { out = (MobType)i; return true; } return false; }

float skyDarken(double dayTicks) { double a = std::fmod(dayTicks, 24000.0) / 24000.0 * 6.283185307179586; double sy = std::sin(a); return (float)(11.0 * (1.0 - smoothstep(-0.15, 0.15, sy))); }
bool isDaytime(double dayTicks) { return skyDarken(dayTicks) < 4.0f; }

// ------------------------------------------------------------------ helpers
static bool playerTargetable(const Player& p) { return !p.dead && (p.mode == GameMode::Survival || p.mode == GameMode::Adventure); }
static Vec3d targetPos(Mob& m, AiCtx& c) {
    if (m.target == 1) return c.player.pos; Mob* t = c.mm.find((uint32_t)m.target); return t ? t->pos : m.pos;
}
static bool targetValid(Mob& m, AiCtx& c) {
    if (m.target == 1) return playerTargetable(c.player);
    Mob* t = c.mm.find((uint32_t)m.target); return t && !t->dying() && t->health > 0;
}
static bool lineOfSight(World& w, const Vec3d& a, const Vec3d& b) {
    Vec3d d = b - a; double len = d.length(); if (len < 0.5) return true;
    RayHit h = raycastBlocks(w, a, d, len, false); return !h.hit;
}
static float angleDiff(float a, float b) { float d = std::fmod(b - a + 540.0f, 360.0f) - 180.0f; return d; }
static float yawTo(const Vec3d& from, const Vec3d& to) { return (float)(std::atan2(-(to.x - from.x), (to.z - from.z)) * 57.29577951308232); }

bool mobSetPath(Mob& m, AiCtx& c, const Vec3d& goal, double speed) {
    if (c.mm.pathBudget <= 0) return false;
    --c.mm.pathBudget;
    PathRequest r; r.start = BlockPos(floorInt(m.pos.x), floorInt(m.pos.y + 0.01), floorInt(m.pos.z)); r.goal = BlockPos(floorInt(goal.x), floorInt(goal.y + 0.01), floorInt(goal.z));
    r.height = (int)std::ceil(m.info().h); r.maxNodes = 500; r.maxRange = 36; r.swimmer = m.type == MobType::Spider;
    PathResult pr = findPath(c.w, r);
    if (pr.nodes.size() < 2 && !pr.reached) { m.navActive = false; return false; }
    m.path = std::move(pr.nodes); m.pathIdx = 1; m.navActive = m.path.size() > 1; m.navSpeed = speed; m.navGoal = goal; return true;
}

static bool randomStroll(Mob& m, AiCtx& c, Vec3d& out, int range = 10) {
    for (int tries = 0; tries < 10; ++tries) {
        int x = floorInt(m.pos.x) + c.rng.range(-range, range), z = floorInt(m.pos.z) + c.rng.range(-range, range), y0 = floorInt(m.pos.y);
        for (int dy = 3; dy >= -4; --dy) if (pathStandable(c.w, x, y0 + dy, z, (int)std::ceil(m.info().h), false, true)) { out = Vec3d(x + 0.5, y0 + dy, z + 0.5); return true; }
    }
    return false;
}

// ------------------------------------------------------------------ goals
struct FloatGoal : Goal { FloatGoal() { prio = 0; flags = GF_JUMP; } bool canUse(Mob& m, AiCtx&) override { return m.inWater || m.inLava; } void tick(Mob& m, AiCtx& c) override { if (c.rng.nextFloat() < 0.8f) m.wantJump = true; } };

struct PanicGoal : Goal {
    PanicGoal() { prio = 1; flags = GF_MOVE; }
    bool canUse(Mob& m, AiCtx&) override { return m.panic > 0; }
    void start(Mob& m, AiCtx& c) override { Vec3d t; if (randomStroll(m, c, t, 8)) mobSetPath(m, c, t, 1.4); }
    void tick(Mob& m, AiCtx& c) override { --m.panic; if (!m.navActive && m.panic > 0) start(m, c); }
    void stop(Mob& m, AiCtx&) override { m.navActive = false; }
};

struct MeleeGoal : Goal {
    double speed; bool leap;
    MeleeGoal(int p, double s, bool l = false) : speed(s), leap(l) { prio = p; flags = GF_MOVE | GF_LOOK; }
    bool canUse(Mob& m, AiCtx& c) override { return m.target != 0 && targetValid(m, c) && !(m.type == MobType::Wolf && !m.angry) && !m.ignited; }
    void start(Mob& m, AiCtx&) override { m.repath = 0; }
    void stop(Mob& m, AiCtx&) override { m.navActive = false; }
    void tick(Mob& m, AiCtx& c) override {
        Vec3d tp = targetPos(m, c); m.lookAt = Vec3d(tp.x, tp.y + 1.5, tp.z); m.lookTimer = 5;
        double dx = tp.x - m.pos.x, dz = tp.z - m.pos.z, dy = tp.y - m.pos.y; double h2 = dx * dx + dz * dz; double tw = m.target == 1 ? 0.6 : 0.8;
        if (--m.repath <= 0) { m.repath = 4 + c.rng.nextInt(7); mobSetPath(m, c, tp, speed); }
        double reach = m.info().w * 2.0 * m.info().w * 2.0 + tw;
        if (leap && m.onGround && h2 > 4 && h2 < 16 && c.rng.nextInt(10) == 0 && std::fabs(dy) < 2) { double d = std::sqrt(h2); m.vel.x = dx / d * 0.5; m.vel.z = dz / d * 0.5; m.vel.y = 0.4; }
        if (h2 + dy * dy * 0.25 <= reach && std::fabs(dy) < 2.2 && m.attackCd <= 0) {
            m.attackCd = 20; m.attackAnim = 1.0f; float dmg = m.info().attack;
            if (m.target == 1) { c.mm.hurtPlayer(c.player, dmg, m.pos, m.type == MobType::IronGolem ? 1.0f : 0.4f); if (m.type == MobType::IronGolem) c.player.vel.y += 0.4; }
            else if (Mob* t = c.mm.find((uint32_t)m.target)) c.mm.attack(*t, dmg, m.pos, false, m.type == MobType::IronGolem ? 1.0f : 0.4f);
            c.mm.playSound(m.type == MobType::IronGolem ? "mob.irongolem.throw" : nullptr, m.pos);
        }
    }
};

struct BowGoal : Goal {
    BowGoal() { prio = 2; flags = GF_MOVE | GF_LOOK; }
    bool canUse(Mob& m, AiCtx& c) override { return m.target != 0 && targetValid(m, c); }
    void stop(Mob& m, AiCtx&) override { m.bowRaised = false; m.navActive = false; m.moveForward = 0; }
    void tick(Mob& m, AiCtx& c) override {
        Vec3d tp = targetPos(m, c); m.lookAt = Vec3d(tp.x, tp.y + 1.5, tp.z); m.lookTimer = 5;
        double dx = tp.x - m.pos.x, dz = tp.z - m.pos.z; double d = std::sqrt(dx * dx + dz * dz); bool los = lineOfSight(c.w, m.eye(), Vec3d(tp.x, tp.y + 1.5, tp.z));
        if (d > 15 || !los) { if (--m.repath <= 0) { m.repath = 10; mobSetPath(m, c, tp, 1.0); } }
        else { m.navActive = false; if (d < 6) m.moveForward = -0.6f; else m.moveForward = 0; if (--m.strafeTimer <= 0) { m.strafeTimer = 20 + c.rng.nextInt(30); m.strafeDir = c.rng.nextBool() ? 1 : -1; } }
        m.bowRaised = los && d < 16;
        if (--m.shootCd <= 0 && los && d < 16) { m.shootCd = 40; c.mm.shootArrow(m, Vec3d(tp.x, tp.y + 1.2, tp.z)); }
    }
};

struct SwellGoal : Goal {
    SwellGoal() { prio = 2; flags = GF_MOVE; }
    bool canUse(Mob& m, AiCtx& c) override { if (m.target == 0 || !targetValid(m, c)) return m.fuse > 0; Vec3d t = targetPos(m, c); return (t - m.pos).lengthSq() < 9.0 || (m.fuse > 0 && (t - m.pos).lengthSq() < 49.0); }
    void start(Mob& m, AiCtx& c) override { m.navActive = false; c.mm.playSound("random.fuse", m.pos, 1.0f, 0.5f); }
    void tick(Mob& m, AiCtx& c) override {
        m.navActive = false; m.moveForward = 0; bool near = m.target != 0 && targetValid(m, c) && (targetPos(m, c) - m.pos).lengthSq() < 9.0;
        if (near || m.ignited) m.fuse++; else m.fuse = std::max(0, m.fuse - 1);
        if (m.fuse >= m.fuseMax) { m.health = 0; c.mm.explode(m.pos + Vec3d(0, 0.5, 0), 3.0f, c.player); m.deathTime = 100; }
    }
    void stop(Mob& m, AiCtx&) override { if (!m.ignited) m.fuse = 0; }
};

struct NearestPlayerGoal : Goal {
    NearestPlayerGoal() { prio = 1; flags = GF_TARGET; }
    bool canUse(Mob& m, AiCtx& c) override {
        if (m.target != 0) return false; if (!playerTargetable(c.player)) return false;
        if (c.rng.nextInt(10) != 0) return false;
        double d = (c.player.pos - m.pos).length(); if (d > m.info().follow) return false;
        if (m.type == MobType::Spider) { float light = (float)std::max(c.w.blockLight(floorInt(m.pos.x), floorInt(m.pos.y), floorInt(m.pos.z)), c.w.skyLight(floorInt(m.pos.x), floorInt(m.pos.y), floorInt(m.pos.z)) - (int)skyDarken(c.dayTicks)); if (light >= 8 && !m.angry) return false; }
        if (m.type != MobType::Zombie && !lineOfSight(c.w, m.eye(), c.player.eye())) return false;
        return true;
    }
    void start(Mob& m, AiCtx&) override { m.target = 1; }
};

struct HurtByGoal : Goal {
    HurtByGoal() { prio = 1; flags = GF_TARGET; }
    bool canUse(Mob& m, AiCtx&) override { return m.hurtByPlayer > 0; }
    void start(Mob& m, AiCtx& c) override { m.target = 1; m.angry = true; m.hurtByPlayer = 0; if (m.type == MobType::Wolf) c.mm.playSound("mob.wolf.growl", m.pos); }
};

struct EndermanLookGoal : Goal {
    EndermanLookGoal() { prio = 1; flags = GF_TARGET; }
    bool canUse(Mob& m, AiCtx& c) override {
        if (m.target != 0 || !playerTargetable(c.player) || c.rng.nextInt(5) != 0) return false;
        Vec3d to = m.eye() - c.player.eye(); double d = to.length(); if (d > 64 || d < 0.1) return false;
        Vec3d look = c.player.lookDir(); double dot = (look.x * to.x + look.y * to.y + look.z * to.z) / d;
        return dot > 1.0 - 0.025 / d && lineOfSight(c.w, c.player.eye(), m.eye());
    }
    void start(Mob& m, AiCtx& c) override { m.target = 1; m.angry = true; c.mm.playSound("mob.endermen.scream", m.pos); }
};

struct GolemTargetGoal : Goal {
    GolemTargetGoal() { prio = 1; flags = GF_TARGET; }
    bool canUse(Mob& m, AiCtx& c) override {
        if (m.target != 0 || c.rng.nextInt(10) != 0) return false;
        for (auto& o : c.mm.mobs) if (o->info().hostile && !o->dying() && (o->pos - m.pos).lengthSq() < 256) { m.target = (int)o->uid; return false; }
        return false;
    }
};

struct StrollGoal : Goal {
    StrollGoal(int p) { prio = p; flags = GF_MOVE; }
    bool canUse(Mob& m, AiCtx& c) override { return !m.navActive && c.rng.nextInt(120) == 0; }
    void start(Mob& m, AiCtx& c) override { Vec3d t; if (randomStroll(m, c, t)) mobSetPath(m, c, t, m.type == MobType::Villager ? 0.6 : 1.0); }
    bool canContinue(Mob& m, AiCtx&) override { return m.navActive; }
    void stop(Mob& m, AiCtx&) override { m.navActive = false; }
};

struct LookPlayerGoal : Goal {
    LookPlayerGoal(int p) { prio = p; flags = GF_LOOK; }
    bool canUse(Mob& m, AiCtx& c) override { return !c.player.dead && c.rng.nextInt(50) == 0 && (c.player.pos - m.pos).lengthSq() < 36; }
    bool canContinue(Mob& m, AiCtx& c) override { return m.lookTimer > 0 && (c.player.pos - m.pos).lengthSq() < 49; }
    void start(Mob& m, AiCtx& c) override { m.lookTimer = 40 + c.rng.nextInt(40); }
    void tick(Mob& m, AiCtx& c) override { --m.lookTimer; m.lookAt = c.player.eye(); }
};

struct RandomLookGoal : Goal {
    RandomLookGoal(int p) { prio = p; flags = GF_LOOK; }
    bool canUse(Mob& m, AiCtx& c) override { return c.rng.nextInt(60) == 0; }
    bool canContinue(Mob& m, AiCtx&) override { return m.lookTimer > 0; }
    void start(Mob& m, AiCtx& c) override { m.lookTimer = 20 + c.rng.nextInt(20); double a = c.rng.nextDouble() * 6.2832; m.lookAt = Vec3d(m.pos.x + std::cos(a) * 5, m.pos.y + 1.5, m.pos.z + std::sin(a) * 5); }
    void tick(Mob& m, AiCtx&) override { --m.lookTimer; }
};

struct AvoidZombieGoal : Goal {
    AvoidZombieGoal() { prio = 1; flags = GF_MOVE; }
    bool canUse(Mob& m, AiCtx& c) override { for (auto& o : c.mm.mobs) if (o->type == MobType::Zombie && !o->dying() && (o->pos - m.pos).lengthSq() < 64) { m.panic = std::max(m.panic, 40); return true; } return false; }
    bool canContinue(Mob& m, AiCtx&) override { return m.panic > 0; }
    void start(Mob& m, AiCtx& c) override { Vec3d t; if (randomStroll(m, c, t, 9)) mobSetPath(m, c, t, 0.9); }
    void tick(Mob& m, AiCtx& c) override { --m.panic; if (!m.navActive) start(m, c); }
};

struct TeleportGoal : Goal {
    TeleportGoal() { prio = 3; flags = GF_TARGET; }
    bool canUse(Mob& m, AiCtx& c) override {
        if (m.teleportCd > 0) { --m.teleportCd; return false; }
        bool wet = m.inWater; if (wet) return true;
        if (m.target != 0 && c.rng.nextInt(80) == 0) return true;
        return m.target == 0 && c.rng.nextInt(400) == 0;
    }
    void start(Mob& m, AiCtx& c) override {
        m.teleportCd = 40;
        for (int i = 0; i < 24; ++i) {
            Vec3d base = (m.target != 0 && targetValid(m, c)) ? targetPos(m, c) : m.pos; double r = (m.target != 0 ? 6 : 24);
            int x = floorInt(base.x + (c.rng.nextDouble() - 0.5) * 2 * r), z = floorInt(base.z + (c.rng.nextDouble() - 0.5) * 2 * r);
            int y0 = floorInt(m.pos.y) + 8; for (int dy = 0; dy < 20; ++dy) if (pathStandable(c.w, x, y0 - dy, z, 3, false, true)) {
                c.mm.playSound("mob.endermen.portal", m.pos); m.pos = Vec3d(x + 0.5, y0 - dy, z + 0.5); m.vel = Vec3d(); m.navActive = false; c.mm.playSound("mob.endermen.portal", m.pos); return; }
        }
    }
    bool canContinue(Mob&, AiCtx&) override { return false; }
};

void buildGoals(Mob& m) {
    auto add = [&](Goal* g) { m.goals.emplace_back(g); };
    switch (m.type) {
        case MobType::Pig: case MobType::Cow: case MobType::Sheep: case MobType::Chicken: case MobType::Rabbit:
            add(new FloatGoal()); add(new PanicGoal()); add(new StrollGoal(5)); add(new LookPlayerGoal(6)); add(new RandomLookGoal(7)); break;
        case MobType::Cat: add(new FloatGoal()); add(new StrollGoal(5)); add(new LookPlayerGoal(6)); add(new RandomLookGoal(7)); break;
        case MobType::Wolf: add(new FloatGoal()); add(new HurtByGoal()); add(new MeleeGoal(2, 1.2)); add(new StrollGoal(5)); add(new LookPlayerGoal(6)); add(new RandomLookGoal(7)); break;
        case MobType::Zombie: add(new FloatGoal()); add(new MeleeGoal(2, 1.0)); add(new NearestPlayerGoal()); add(new StrollGoal(7)); add(new LookPlayerGoal(8)); add(new RandomLookGoal(8)); break;
        case MobType::Skeleton: add(new FloatGoal()); add(new BowGoal()); add(new NearestPlayerGoal()); add(new StrollGoal(7)); add(new LookPlayerGoal(8)); add(new RandomLookGoal(8)); break;
        case MobType::Creeper: add(new FloatGoal()); add(new SwellGoal()); add(new MeleeGoal(4, 1.0)); add(new NearestPlayerGoal()); add(new StrollGoal(7)); add(new LookPlayerGoal(8)); add(new RandomLookGoal(8)); break;
        case MobType::Spider: add(new FloatGoal()); add(new MeleeGoal(4, 1.2, true)); add(new NearestPlayerGoal()); add(new HurtByGoal()); add(new StrollGoal(7)); add(new LookPlayerGoal(8)); add(new RandomLookGoal(8)); break;
        case MobType::Enderman: add(new FloatGoal()); add(new MeleeGoal(2, 1.0)); add(new EndermanLookGoal()); add(new HurtByGoal()); add(new TeleportGoal()); add(new StrollGoal(7)); add(new LookPlayerGoal(8)); add(new RandomLookGoal(8)); break;
        case MobType::Villager: add(new FloatGoal()); add(new AvoidZombieGoal()); add(new StrollGoal(5)); add(new LookPlayerGoal(6)); add(new RandomLookGoal(7)); break;
        case MobType::IronGolem: add(new FloatGoal()); add(new MeleeGoal(1, 1.0)); add(new GolemTargetGoal()); add(new HurtByGoal()); add(new StrollGoal(5)); add(new LookPlayerGoal(6)); add(new RandomLookGoal(7)); break;
        default: break;
    }
    std::stable_sort(m.goals.begin(), m.goals.end(), [](auto& a, auto& b) { return a->prio < b->prio; });
}

void runGoals(Mob& m, AiCtx& c) {
    m.moveForward = 0; m.wantJump = false;
    if (m.target != 0 && !targetValid(m, c)) { m.target = 0; m.angry = m.type == MobType::Wolf ? false : m.angry; }
    unsigned used = 0;
    for (auto& g : m.goals) {
        if (g->running) {
            if ((g->flags & used) || !g->canContinue(m, c)) { g->stop(m, c); g->running = false; }
            else { g->tick(m, c); used |= g->flags; continue; }
        }
        if (!g->running && (g->flags & used) == 0 && g->canUse(m, c)) { g->running = true; g->start(m, c); g->tick(m, c); used |= g->flags; }
    }
}

// ------------------------------------------------------------------ movement
void steerAndMove(Mob& m, AiCtx& c) {
    const MobInfo& inf = m.info(); World& w = c.w;
    m.prevPos = m.pos; m.prevYaw = m.yaw; m.prevHeadYaw = m.headYaw; m.prevLimbAmount = m.limbAmount; m.prevSwell = m.swell;
    // fluids
    AABB bb = m.box().inflate(-0.001); m.inWater = false; m.inLava = false;
    for (int y = floorInt(bb.y0); y <= floorInt(bb.y1) && !(m.inWater || m.inLava); ++y) { BlockState s = w.getBlock(floorInt(m.pos.x), y, floorInt(m.pos.z)); if (stateId(s) == B::WATER) m.inWater = true; else if (stateId(s) == B::LAVA) m.inLava = true; }
    // desired heading
    double fwd = 0, strafe = 0; bool turnToMove = false; float wantYaw = m.yaw;
    if (m.navActive && m.pathIdx < m.path.size()) {
        const BlockPos& n = m.path[m.pathIdx]; double tx = n.x + 0.5, tz = n.z + 0.5, dx = tx - m.pos.x, dz = tz - m.pos.z, d = std::sqrt(dx * dx + dz * dz);
        if (d < 0.3 && std::fabs(m.pos.y - n.y) < 1.2) { ++m.pathIdx; if (m.pathIdx >= m.path.size()) m.navActive = false; }
        else { wantYaw = (float)(std::atan2(-dx, dz) * 57.29577951308232); turnToMove = true; fwd = m.navSpeed;
            if (n.y > m.pos.y + 0.4 && m.onGround && d < 1.3) m.wantJump = true; }
    }
    if (m.moveForward != 0) { fwd = m.moveForward; }
    // strafing (skeleton) keeps facing the target while sidestepping
    if (m.type == MobType::Skeleton && m.bowRaised && !m.navActive) { strafe = 0.5 * m.strafeDir; }
    // body turns toward the movement direction or the look target
    if (turnToMove && fwd > 0) { float d = angleDiff(m.yaw, wantYaw); m.yaw += clampv(d, -30.0f, 30.0f); }
    else if (m.lookTimer > 0 || m.target != 0) { float d = angleDiff(m.yaw, yawTo(m.pos, m.lookAt)); if (m.target != 0 || std::fabs(angleDiff(m.yaw, m.headYaw)) > 50) m.yaw += clampv(d, -20.0f, 20.0f); }
    // head
    if (m.lookTimer > 0 || m.target != 0) { float hy = yawTo(m.pos, m.lookAt); float dh = angleDiff(m.headYaw, hy); m.headYaw += clampv(dh, -30.0f, 30.0f); Vec3d dl = m.lookAt - m.eye(); double hd = std::sqrt(dl.x * dl.x + dl.z * dl.z); m.pitch = (float)clampv(-std::atan2(dl.y, hd) * 57.29577951308232, -40.0, 40.0); }
    else { float dh = angleDiff(m.headYaw, m.yaw); m.headYaw += clampv(dh, -15.0f, 15.0f); m.pitch *= 0.9f; }
    float rel = angleDiff(m.yaw, m.headYaw); if (rel > 75) m.headYaw = m.yaw + 75; if (rel < -75) m.headYaw = m.yaw - 75;
    // physics (vanilla: accel = (speed*modifier)^2 on the ground because the forward impulse is scaled by the speed as well)
    double s = inf.speed * (m.panic > 0 ? 1.0 : 1.0); double yr = m.yaw * 0.017453292519943295;
    double ix = -std::sin(yr) * fwd + std::cos(yr) * strafe * -1.0, iz = std::cos(yr) * fwd + std::sin(yr) * strafe * -1.0;
    double accel;
    float bf = stateId(w.getBlock(floorInt(m.pos.x), floorInt(m.pos.y - 0.5), floorInt(m.pos.z))) == B::ICE ? 0.98f : 0.6f;
    if (m.inWater || m.inLava) accel = 0.02 * std::min(1.0, s * 4); else if (m.onGround) accel = s * s * std::fabs(fwd == 0 ? strafe : fwd) * 1.0 / std::max(0.001, std::fabs(fwd == 0 ? strafe : fwd) > 0 ? 1.0 : 1.0); else accel = 0.02 * s;
    double mag = std::sqrt(ix * ix + iz * iz); if (mag > 1e-6) { double k = (m.inWater || m.inLava || !m.onGround) ? accel / mag : (s * s * std::min(1.0, mag * 1.0)) / mag * std::max(std::fabs(fwd), std::fabs(strafe)) ; m.vel.x += ix * k; m.vel.z += iz * k; }
    if (m.wantJump) { if (m.inWater || m.inLava) m.vel.y += 0.04; else if (m.onGround) { m.vel.y = 0.42; } }
    AABB box = m.box(); bool slow = m.inWater || m.inLava;
    MoveResult r = moveEntity(w, box, m.vel, 0.6, false, m.onGround);
    m.pos = Vec3d((box.x0 + box.x1) / 2, box.y0, (box.z0 + box.z1) / 2);
    if (r.hitX) m.vel.x = 0; if (r.hitZ) m.vel.z = 0;
    if (r.moved.y < 0) m.fallDist -= r.moved.y;
    if (r.hitY) { if (r.onGround) { if (m.fallDist > 3.0 && !slow) { m.health -= (float)std::ceil(m.fallDist - 3.0); m.hurtTime = 10; } m.fallDist = 0; } m.vel.y = 0; }
    m.onGround = r.onGround; if (slow) m.fallDist = 0;
    if (m.inWater) { m.vel.x *= 0.8; m.vel.z *= 0.8; m.vel.y = m.vel.y * 0.8 - 0.02; } else if (m.inLava) { m.vel = m.vel * 0.5; m.vel.y -= 0.02; }
    else { double fr = m.onGround ? bf * 0.91 : 0.91; m.vel.y = (m.vel.y - (m.type == MobType::Chicken && m.vel.y < 0 ? 0.02 : 0.08)) * 0.98; m.vel.x *= fr; m.vel.z *= fr; }
    // limb animation
    double dist = std::hypot(m.pos.x - m.prevPos.x, m.pos.z - m.prevPos.z); float amt = (float)std::min(1.0, dist * 4.0);
    m.limbAmount += (amt - m.limbAmount) * 0.4f; m.limbSwing += (float)dist * 3.2f;
    if (m.attackAnim > 0) m.attackAnim = std::max(0.0f, m.attackAnim - 0.1f);
    // footsteps
    if (m.onGround && dist > 0.01 && *inf.step) { m.stepDist += (int)(dist * 100); if (m.stepDist > 90) { m.stepDist = 0; c.mm.playSound(inf.step, m.pos, 0.25f, 1.0f); } }
}

} // namespace mc
