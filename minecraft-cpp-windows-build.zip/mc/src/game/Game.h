#pragma once
// The game application: screens (menus, HUD, inventories), world session management, input handling and the 20 TPS update loop.
#include "../audio/Audio.h"
#include "../engine/ThreadPool.h"
#include "../engine/Window.h"
#include "../player/Player.h"
#include "../renderer/UIRenderer.h"
#include "../renderer/WorldRenderer.h"
#include "../save/SaveSystem.h"
#include "../world/ChunkManager.h"
#include "Settings.h"
#include <glm/glm.hpp>
#include <memory>
#include <unordered_map>

namespace mc {

enum class Screen { MainMenu, WorldSelect, CreateWorld, Options, Loading, Playing, Pause, Container, Creative, Death };

struct ItemEntity { Vec3d pos, vel; ItemStack st; int age = 0, delay = 10; };
struct Particle { Vec3d pos, vel; float life = 0, size = 0.1f; int layer = 0; float u0 = 0, v0 = 0; uint8_t r = 255, g = 255, b = 255; };

class Game {
public:
    Game(std::string assetDir, std::string savesDir) : assets_(std::move(assetDir)), saves_(std::move(savesDir)) {}
    int run();
private:
    // lifecycle
    void frame(double dt);
    void startWorld(const std::string& name, uint64_t seed, GameMode mode, bool isNew);
    void stopWorld(bool save);
    void saveWorld();
    void setScreen(Screen s);
    void applySettings();
    // menus
    void drawBackground();
    bool button(float x, float y, float w, float h, const std::string& label, bool enabled = true);
    bool slider(float x, float y, float w, float h, const std::string& label, float& value);
    void text(const std::string& s, float gx, float gy, uint32_t color = 0xFFFFFFFF, int sc = 1, bool center = false, bool shadow = true);
    void drawMainMenu(); void drawWorldSelect(); void drawCreateWorld(); void drawOptions(); void drawLoading(); void drawPause(); void drawDeath();
    // gameplay
    void tickGame();
    void handleGameplayInput(double dt);
    void updateTargetAndBreaking();
    void tryPlaceOrUse();
    void breakBlock(const BlockPos& p);
    void spawnDrops(const BlockPos& p, BlockState s, bool withTool);
    void spawnItem(const Vec3d& pos, const ItemStack& st, const Vec3d& vel);
    void spawnBreakParticles(const BlockPos& p, BlockState s);
    void tickItems(); void tickParticles();
    void openContainer(const BlockPos& p, BlockState s);
    void closeContainer();
    void useBucket();
    bool canPlaceAt(const BlockPos& p, BlockState s) const;
    void fillLoot(std::vector<ItemStack>& slots, const BlockPos& p);
    void saveContainers(); void loadContainers();
    void die();
    // rendering
    void renderWorld(double partial);
    void drawHUD();
    void drawHotbar(); void drawStatusBars(); void drawDebug(); void drawContainerScreen(); void drawCreativeScreen(); void drawCursorItem(float mx, float my);
    void drawHeart(float x, float y, int s, int kind); void drawFood(float x, float y, int s, int kind);
    void layoutMenu();
    glm::mat4 rotView() const;
    // state
    std::string assets_, saves_, optionsPath_;
    Settings set_; Window win_; UIRenderer ui_; WorldRenderer wr_; AudioSystem audio_; std::unique_ptr<ThreadPool> pool_;
    std::unique_ptr<World> world_; std::unique_ptr<SaveSystem> save_; std::unique_ptr<ChunkManager> cm_;
    Player player_; LevelData level_; Screen screen_ = Screen::MainMenu, prevScreen_ = Screen::MainMenu;
    int gs_ = 2; float mx_ = 0, my_ = 0; bool click_ = false, rclick_ = false, mouseHeld_ = false;
    double lastTime_ = 0, accumulator_ = 0, fpsTimer_ = 0; int frames_ = 0, fps_ = 0; float partial_ = 0;
    bool debug_ = false, ownsAudio_ = false;
    // menu state
    std::vector<std::string> worldList_; int selectedWorld_ = -1; std::string newName_ = "Новый мир", newSeed_; int newMode_ = 0; int focusField_ = 0; bool confirmDelete_ = false;
    // world session
    bool loadingNew_ = true; BlockPos spawnSearch_; bool spawnReady_ = false; int autosaveTimer_ = 0; double saveMsgTimer_ = 0;
    // interaction
    RayHit hit_; bool hasHit_ = false; BlockPos breakPos_; float breakProgress_ = 0; bool breaking_ = false; int placeCooldown_ = 0; int eatTicks_ = 0; float stepAccum_ = 0;
    std::vector<ItemEntity> items_; std::vector<Particle> particles_; Rng rng_{0xC0FFEE};
    int hurtFlash_ = 0; std::string heldName_; int heldNameTimer_ = 0; int lastSelected_ = -1; bool wasEyesInWater_ = false;
    // containers
    std::unique_ptr<Menu> menu_; BlockPos menuPos_; std::string menuTitle_; std::vector<std::pair<float, float>> slotPos_; int menuSheetKind_ = 0;
    std::unordered_map<BlockPos, std::vector<ItemStack>, BlockPosHash> chests_; std::unordered_map<BlockPos, FurnaceState, BlockPosHash> furnaces_;
    int creativeScroll_ = 0; ItemStack creativeCursor_; std::vector<ItemId> creativeItems_;
    FrameParams fp_;
};

} // namespace mc
