#pragma once
// Fixed-size worker pool used for chunk generation, decoration and meshing.
#include <atomic>
#include <condition_variable>
#include <deque>
#include <functional>
#include <mutex>
#include <thread>
#include <vector>

namespace mc {

class ThreadPool {
public:
    explicit ThreadPool(unsigned n = 0) {
        if (n == 0) { n = std::thread::hardware_concurrency(); n = n > 2 ? n - 1 : 1; }
        for (unsigned i = 0; i < n; ++i) workers_.emplace_back([this] { run(); });
    }
    ~ThreadPool() { { std::lock_guard<std::mutex> l(m_); stop_ = true; } cv_.notify_all(); for (auto& t : workers_) t.join(); }
    void submit(std::function<void()> f) { { std::lock_guard<std::mutex> l(m_); q_.push_back(std::move(f)); } cv_.notify_one(); }
    size_t pending() { std::lock_guard<std::mutex> l(m_); return q_.size(); }
    unsigned size() const { return (unsigned)workers_.size(); }
private:
    void run() {
        for (;;) {
            std::function<void()> f;
            { std::unique_lock<std::mutex> l(m_); cv_.wait(l, [this] { return stop_ || !q_.empty(); }); if (stop_ && q_.empty()) return; f = std::move(q_.front()); q_.pop_front(); }
            f();
        }
    }
    std::vector<std::thread> workers_; std::deque<std::function<void()>> q_; std::mutex m_; std::condition_variable cv_; bool stop_ = false;
};

} // namespace mc
