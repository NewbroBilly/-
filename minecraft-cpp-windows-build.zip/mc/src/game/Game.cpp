#include "Game.h"
#include "../inventory/Inventory.h"
#include <algorithm>
#include <cctype>
#include <chrono>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <glm/gtc/matrix_transform.hpp>

namespace fs = std::filesystem;
namespace mc {

static double nowSec() { return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count(); }

// ====================================================================== lifecycle
void Game::applySettings() {
    win_.setVsync(set_.vsync); audio_.setVolume(set_.volume); wr_.maxJobs = 6;
}

int Game::run() {
    fs::create_directories(saves_);
    fs::path opt = fs::path(saves_).parent_path() / "options.txt"; optionsPath_ = opt.empty() ? "options.txt" : opt.string();
    set_.load(optionsPath_); Lang::load(assets_, set_.lang);
    if (!win_.create(1280, 720, "Minecraft C++")) return 1;
    Window* wp = &win_;
    static Window* g_win = wp;
    if (!gl::load([](const char* n) -> void* { return g_win->procAddress(n); })) { std::fprintf(stderr, "OpenGL function loading failed\n"); return 2; }
    std::printf("OpenGL %s on %s\n", glGetString(GL_VERSION), glGetString(GL_RENDERER));
    Blocks::init(); Items::init(); Recipes::init();
    for (int i = 0; i < 10; ++i) Blocks::textureIndex("block/destroy_stage_" + std::to_string(i));
    Items::init();
    pool_ = std::make_unique<ThreadPool>();
    if (!wr_.init(assets_, pool_.get())) return 3;
    if (!ui_.init(assets_, &wr_.textures())) { std::fprintf(stderr, "UI init failed (assets/font missing?)\n"); return 4; }
    audio_.init(assets_); audio_.startMusic("menu"); applySettings();
    if (set_.fullscreen) win_.toggleFullscreen();
    creativeItems_.clear(); for (const ItemInfo& i : Items::all()) if (i.id != 0 && i.name != "bedrock") creativeItems_.push_back(i.id);
    setScreen(Screen::MainMenu);
    lastTime_ = nowSec();
    while (!win_.shouldClose()) {
        double t = nowSec(); double dt = std::min(0.25, t - lastTime_); lastTime_ = t;
        win_.poll(); frame(dt); win_.swap();
        ++frames_; fpsTimer_ += dt; if (fpsTimer_ >= 1.0) { fps_ = frames_; frames_ = 0; fpsTimer_ = 0; }
    }
    if (world_) stopWorld(true);
    set_.save(optionsPath_);
    audio_.shutdown(); ui_.shutdown(); wr_.shutdown(); pool_.reset(); win_.destroy();
    return 0;
}

void Game::setScreen(Screen s) {
    prevScreen_ = screen_; screen_ = s;
    win_.setCursorLocked(s == Screen::Playing);
    if (s == Screen::MainMenu || s == Screen::WorldSelect || s == Screen::CreateWorld) { audio_.startMusic("menu"); }
    if (s == Screen::WorldSelect) { worldList_ = SaveSystem::listWorlds(saves_); selectedWorld_ = worldList_.empty() ? -1 : 0; confirmDelete_ = false; }
    if (s == Screen::Playing) audio_.startMusic("game");
}

// ====================================================================== world session
static uint64_t seedFromText(const std::string& t) {
    if (t.empty()) return (uint64_t)std::chrono::steady_clock::now().time_since_epoch().count() * 0x9E3779B97F4A7C15ULL;
    bool num = true; for (size_t i = 0; i < t.size(); ++i) if (!(std::isdigit((unsigned char)t[i]) || (i == 0 && t[i] == '-'))) num = false;
    if (num) { try { return (uint64_t)std::stoll(t); } catch (...) {} }
    int32_t h = 0; for (unsigned char c : t) h = 31 * h + c; return (uint64_t)(int64_t)h;
}

void Game::startWorld(const std::string& name, uint64_t seed, GameMode mode, bool isNew) {
    std::string dir = (fs::path(saves_) / name).string();
    save_ = std::make_unique<SaveSystem>(dir);
    level_ = LevelData(); level_.name = name; level_.seed = seed; level_.mode = mode;
    player_ = Player(); player_.setMode(mode);
    bool loaded = false;
    if (!isNew) { loaded = save_->loadLevel(level_, &player_); seed = level_.seed; }
    world_ = std::make_unique<World>(seed);
    cm_ = std::make_unique<ChunkManager>(*world_, *pool_, seed, save_.get());
    cm_->onUnload = [this](int cx, int cz) { wr_.onChunkUnloaded(cx, cz); };
    world_->onBlockBroken = [this](const BlockPos& p, BlockState s) { spawnDrops(p, s, false); };
    items_.clear(); particles_.clear(); chests_.clear(); furnaces_.clear(); breaking_ = false; menu_.reset();
    loadContainers();
    // spawn: new worlds look for dry land close to the origin
    spawnReady_ = loaded && level_.hasPlayer;
    if (!spawnReady_) {
        BlockPos best(0, 0, 0); bool found = false;
        for (int r = 0; r < 160 && !found; ++r) for (int k = 0; k < 8 && !found; ++k) {
            double a = k * 0.785398 + r * 0.3; int x = (int)(std::cos(a) * r * 24), z = (int)(std::sin(a) * r * 24);
            ColumnInfo c = cm_->terrain().column(x, z);
            if (!isOceanBiome(c.biome) && c.biome != Biome::River && c.biome != Biome::FrozenRiver && c.height >= 65 && c.height < 100) { best = BlockPos(x, 0, z); found = true; }
        }
        spawnSearch_ = best; player_.pos = player_.prevPos = Vec3d(best.x + 0.5, 200, best.z + 0.5);
    }
    player_.vel = Vec3d(); level_.hasPlayer = true; autosaveTimer_ = 0; accumulator_ = 0; loadingNew_ = isNew;
    setScreen(Screen::Loading);
}

void Game::saveWorld() {
    if (!world_ || !save_) return;
    cm_->saveAll(); level_.mode = player_.mode; save_->saveLevel(level_, &player_); saveContainers(); saveMsgTimer_ = 2.0;
}

void Game::stopWorld(bool save) {
    if (!world_) return;
    if (save) saveWorld();
    wr_.clearChunks();
    cm_.reset(); world_.reset(); save_.reset(); menu_.reset(); items_.clear(); particles_.clear();
}

// ====================================================================== UI helpers
void Game::text(const std::string& s, float gx, float gy, uint32_t col, int sc, bool center, bool shadow) {
    float w = ui_.textWidth(s, sc * gs_) / gs_;
    ui_.text(s, (center ? gx - w / 2 : gx) * gs_, gy * gs_, sc * gs_, col, shadow);
}

bool Game::button(float x, float y, float w, float h, const std::string& label, bool enabled) {
    bool hover = enabled && mx_ >= x && mx_ < x + w && my_ >= y && my_ < y + h;
    int tw = 0, th = 0; GLuint sh = ui_.loadSheet("gui/widgets", tw, th);
    if (sh && tw > 0) {
        float v0 = (enabled ? (hover ? 86 : 66) : 46) / (float)th, v1 = v0 + 20.0f / th; float hw = w / 2;
        ui_.sheet(sh, x * gs_, y * gs_, hw * gs_, h * gs_, 0, v0, hw / tw, v1);
        ui_.sheet(sh, (x + hw) * gs_, y * gs_, hw * gs_, h * gs_, (200 - hw) / tw, v0, 200.0f / tw, v1);
    } else ui_.rect(x * gs_, y * gs_, w * gs_, h * gs_, hover ? 0x707070FF : (enabled ? 0x505050FF : 0x303030FF));
    text(label, x + w / 2, y + (h - 12.0f / gs_ * gs_ * 0.75f) / 2 - 1, !enabled ? 0xA0A0A0FF : (hover ? 0xFFFFA0FF : 0xFFFFFFFF), 1, true);
    if (hover && click_) { audio_.play2D("random.click", 0.8f); click_ = false; return true; }
    return false;
}

bool Game::slider(float x, float y, float w, float h, const std::string& label, float& v) {
    bool hover = mx_ >= x && mx_ < x + w && my_ >= y && my_ < y + h; bool changed = false;
    if (hover && mouseHeld_) { float nv = clampv((mx_ - x) / w, 0.0f, 1.0f); if (nv != v) { v = nv; changed = true; } }
    ui_.rect(x * gs_, y * gs_, w * gs_, h * gs_, 0x202020FF); ui_.rect((x + 1) * gs_, (y + 1) * gs_, (w - 2) * gs_, (h - 2) * gs_, 0x404040FF);
    ui_.rect((x + v * (w - 8)) * gs_, y * gs_, 8 * gs_, h * gs_, hover ? 0xB0B0FFFF : 0x9090C0FF);
    text(label, x + w / 2, y + (h - 9) / 2 - 1, 0xFFFFFFFF, 1, true);
    return changed;
}

void Game::drawBackground() {
    int layer = Blocks::textureIndex("block/dirt"); float t = 32.0f * gs_;
    for (float y = 0; y < win_.height; y += t) for (float x = 0; x < win_.width; x += t) ui_.tile(layer, x, y, t, t, 0x404040FF);
}

// ====================================================================== screens
void Game::drawMainMenu() {
    drawBackground(); float cx = win_.width / (2.0f * gs_);
    text("MINECRAFT", cx, 30, 0xFFE070FF, 3, true); text(tr("title.sub"), cx + 70, 62, 0xFFFF55FF, 1, true);
    if (button(cx - 100, 100, 200, 20, tr("menu.singleplayer"))) setScreen(Screen::WorldSelect);
    if (button(cx - 100, 124, 200, 20, tr("menu.options"))) { prevScreen_ = Screen::MainMenu; setScreen(Screen::Options); prevScreen_ = Screen::MainMenu; }
    if (button(cx - 100, 148, 200, 20, tr("menu.quit"))) win_.requestClose();
    text(tr("hint.controls"), cx, win_.height / (float)gs_ - 14, 0xA0A0A0FF, 1, true, false);
}

void Game::drawWorldSelect() {
    drawBackground(); float cx = win_.width / (2.0f * gs_);
    text(tr("world.select"), cx, 12, 0xFFFFFFFF, 1, true);
    if (worldList_.empty()) text(tr("world.none"), cx, 80, 0xC0C0C0FF, 1, true);
    for (size_t i = 0; i < worldList_.size() && i < 8; ++i) {
        float y = 32 + i * 26; bool sel = (int)i == selectedWorld_;
        bool hover = mx_ >= cx - 110 && mx_ < cx + 110 && my_ >= y && my_ < y + 24;
        ui_.rect((cx - 110) * gs_, y * gs_, 220 * gs_, 24 * gs_, sel ? 0xFFFFFFAA : (hover ? 0x80808088 : 0x00000099));
        ui_.rect((cx - 109) * gs_, (y + 1) * gs_, 218 * gs_, 22 * gs_, 0x101010FF);
        LevelData ld; std::string sub; if (SaveSystem::readLevelHeader((fs::path(saves_) / worldList_[i]).string(), ld)) sub = Lang::trf("world.lastplayed", std::to_string((int64_t)ld.seed));
        text(worldList_[i], cx - 104, y + 3); text(sub, cx - 104, y + 14, 0x909090FF, 1, false, false);
        if (hover && click_) { selectedWorld_ = (int)i; click_ = false; }
    }
    float by = win_.height / (float)gs_ - 56;
    if (button(cx - 154, by, 150, 20, tr("world.play"), selectedWorld_ >= 0)) {
        LevelData ld; std::string n = worldList_[selectedWorld_];
        if (SaveSystem::readLevelHeader((fs::path(saves_) / n).string(), ld)) startWorld(n, ld.seed, ld.mode, false);
    }
    if (button(cx + 4, by, 150, 20, tr("world.new"))) { newName_ = "Новый мир"; newSeed_.clear(); newMode_ = 0; focusField_ = 0; setScreen(Screen::CreateWorld); }
    if (button(cx - 154, by + 24, 150, 20, confirmDelete_ ? "OK?" : tr("world.delete"), selectedWorld_ >= 0)) {
        if (!confirmDelete_) confirmDelete_ = true; else { std::error_code ec; fs::remove_all(fs::path(saves_) / worldList_[selectedWorld_], ec); setScreen(Screen::WorldSelect); }
    }
    if (button(cx + 4, by + 24, 150, 20, tr("menu.back"))) setScreen(Screen::MainMenu);
}

void Game::drawCreateWorld() {
    drawBackground(); float cx = win_.width / (2.0f * gs_);
    text(tr("world.new"), cx, 12, 0xFFFFFFFF, 1, true);
    auto field = [&](float y, const std::string& label, std::string& val, int id) {
        text(label, cx, y - 11, 0xA0A0A0FF, 1, true);
        bool hover = mx_ >= cx - 100 && mx_ < cx + 100 && my_ >= y && my_ < y + 20; if (hover && click_) { focusField_ = id; click_ = false; }
        ui_.rect((cx - 101) * gs_, (y - 1) * gs_, 202 * gs_, 22 * gs_, focusField_ == id ? 0xFFFFFFFF : 0xA0A0A0FF); ui_.rect((cx - 100) * gs_, y * gs_, 200 * gs_, 20 * gs_, 0x000000FF);
        text(val + (focusField_ == id && ((int)(nowSec() * 2) & 1) ? "_" : ""), cx - 96, y + 4);
    };
    field(44, tr("world.name"), newName_, 0); field(86, tr("world.seed"), newSeed_, 1);
    // typing
    std::string& tgt = focusField_ == 0 ? newName_ : newSeed_;
    tgt += win_.typed; for (int k : win_.keyEvents) if (k == Key::Backspace && !tgt.empty()) { do tgt.pop_back(); while (!tgt.empty() && (tgt.back() & 0xC0) == 0x80); }
    if (tgt.size() > 40) tgt.resize(40);
    static const char* modes[4] = {"mode.survival", "mode.creative", "mode.adventure", "mode.spectator"};
    if (button(cx - 100, 116, 200, 20, Lang::trf("world.mode", tr(modes[newMode_])))) newMode_ = (newMode_ + 1) % 4;
    bool nameOk = !newName_.empty();
    if (button(cx - 100, 144, 200, 20, tr("world.create"), nameOk)) {
        std::string n = newName_; for (char& c : n) if (c == '/' || c == '\\' || c == ':') c = '_';
        std::string base = n; int k = 2; while (fs::exists(fs::path(saves_) / n)) n = base + " " + std::to_string(k++);
        startWorld(n, seedFromText(newSeed_), (GameMode)newMode_, true);
    }
    if (button(cx - 100, 168, 200, 20, tr("menu.back"))) setScreen(Screen::WorldSelect);
}

void Game::drawOptions() {
    if (world_) { ui_.rect(0, 0, (float)win_.width, (float)win_.height, 0x000000A0); } else drawBackground();
    float cx = win_.width / (2.0f * gs_); text(tr("opt.title"), cx, 12, 0xFFFFFFFF, 1, true);
    auto onoff = [](bool b) { return tr(b ? "on" : "off"); };
    float l = cx - 155, r = cx + 5, y = 34;
    if (button(l, y, 150, 20, tr("opt.language"))) { set_.lang = set_.lang == "ru" ? "en" : "ru"; Lang::load(assets_, set_.lang); }
    float rd = (set_.renderDistance - 3) / 29.0f; if (slider(r, y, 150, 20, Lang::trf("opt.renderDistance", std::to_string(set_.renderDistance)), rd)) set_.renderDistance = 3 + (int)std::lround(rd * 29);
    y += 24; float fv = (set_.fov - 50) / 60.0f; if (slider(l, y, 150, 20, Lang::trf("opt.fov", std::to_string((int)set_.fov)), fv)) set_.fov = 50 + std::round(fv * 60);
    float sv = set_.sensitivity; if (slider(r, y, 150, 20, Lang::trf("opt.sensitivity", std::to_string((int)(sv * 200))), sv)) set_.sensitivity = sv;
    y += 24; float vv = set_.volume; if (slider(l, y, 150, 20, Lang::trf("opt.volume", std::to_string((int)(vv * 100))), vv)) { set_.volume = vv; audio_.setVolume(vv); }
    if (button(r, y, 150, 20, Lang::trf("opt.guiScale", set_.guiScale ? std::to_string(set_.guiScale) : tr("opt.auto")))) set_.guiScale = (set_.guiScale + 1) % 5;
    y += 24; if (button(l, y, 150, 20, Lang::trf("opt.vsync", onoff(set_.vsync)))) { set_.vsync = !set_.vsync; win_.setVsync(set_.vsync); }
    if (button(r, y, 150, 20, Lang::trf("opt.fullscreen", onoff(set_.fullscreen)))) { set_.fullscreen = !set_.fullscreen; win_.toggleFullscreen(); }
    y += 24; if (button(l, y, 150, 20, Lang::trf("opt.occlusion", onoff(set_.occlusion)))) set_.occlusion = !set_.occlusion;
    if (button(cx - 100, y + 40, 200, 20, tr("menu.done"))) { set_.save(optionsPath_); setScreen(prevScreen_ == Screen::Options ? Screen::MainMenu : prevScreen_); }
}

void Game::drawLoading() {
    drawBackground(); float cx = win_.width / (2.0f * gs_);
    int need = 0, have = 0; int pcx = floorInt(player_.pos.x) >> 4, pcz = floorInt(player_.pos.z) >> 4;
    for (int dz = -3; dz <= 3; ++dz) for (int dx = -3; dx <= 3; ++dx) { ++need; Chunk* c = world_->chunk(pcx + dx, pcz + dz); if (c && c->status.load() == ChunkStatus::Lit) ++have; }
    text(tr("loading"), cx, 90, 0xFFFFFFFF, 1, true);
    ui_.rect((cx - 100) * gs_, 110 * gs_, 200 * gs_, 8 * gs_, 0x000000FF); ui_.rect((cx - 99) * gs_, 111 * gs_, 198.0f * gs_ * have / need, 6 * gs_, 0x60E060FF);
    cm_->update(pcx, pcz, 4, 6.0); wr_.update(*world_, player_.pos);
    int meshed = wr_.stats.chunksMeshed; (void)meshed;
    if (have >= need) {
        if (!spawnReady_) {
            int y = world_->surfaceY(floorInt(player_.pos.x), floorInt(player_.pos.z));
            for (int yy = WORLD_MAX_Y - 1; yy > WORLD_MIN_Y; --yy) { BlockState s = world_->getBlock(floorInt(player_.pos.x), yy, floorInt(player_.pos.z)); if (blockOf(s).solid) { y = yy; break; } }
            player_.pos = player_.prevPos = Vec3d(floor(player_.pos.x) + 0.5, y + 1.0, floor(player_.pos.z) + 0.5); player_.spawn = BlockPos(floorInt(player_.pos.x), y + 1, floorInt(player_.pos.z)); spawnReady_ = true;
        }
        setScreen(Screen::Playing);
    }
}

void Game::drawPause() {
    float cx = win_.width / (2.0f * gs_); text(tr("pause.title"), cx, 40, 0xFFFFFFFF, 1, true);
    if (button(cx - 100, 70, 200, 20, tr("pause.resume"))) setScreen(Screen::Playing);
    if (button(cx - 100, 94, 200, 20, tr("pause.options"))) { setScreen(Screen::Options); prevScreen_ = Screen::Pause; }
    if (button(cx - 100, 118, 200, 20, tr("pause.quit"))) { stopWorld(true); setScreen(Screen::MainMenu); }
}

void Game::drawDeath() {
    ui_.rect(0, 0, (float)win_.width, (float)win_.height, 0x80101080);
    float cx = win_.width / (2.0f * gs_); text(tr("death.title"), cx, 60, 0xFFFFFFFF, 3, true);
    text(Lang::trf("death.score", std::to_string(player_.xpTotal)), cx, 105, 0xFFFFFFFF, 1, true);
    if (button(cx - 100, 130, 200, 20, tr("death.respawn"))) { player_.respawn(); setScreen(Screen::Playing); }
    if (button(cx - 100, 154, 200, 20, tr("pause.quit"))) { stopWorld(true); setScreen(Screen::MainMenu); }
}

// ====================================================================== frame
glm::mat4 Game::rotView() const {
    Vec3d d = player_.lookDir();
    return glm::lookAt(glm::vec3(0.0f), glm::vec3((float)d.x, (float)d.y, (float)d.z), glm::vec3(0, 1, 0));
}

void Game::frame(double dt) {
    int W = win_.width, H = win_.height;
    gs_ = set_.guiScale > 0 ? set_.guiScale : clampv(std::min(W / 320, H / 240), 1, 4);
    mx_ = (float)(win_.mouseX / gs_); my_ = (float)(win_.mouseY / gs_);
    click_ = win_.mousePressed(0); rclick_ = win_.mousePressed(1); mouseHeld_ = win_.mouseDown(0);
    audio_.update();
    bool inWorld = world_ && screen_ != Screen::MainMenu && screen_ != Screen::WorldSelect && screen_ != Screen::CreateWorld && screen_ != Screen::Loading && !(screen_ == Screen::Options && !world_);
    if (!inWorld) {
        glViewport(0, 0, W, H); glClearColor(0.1f, 0.1f, 0.1f, 1); glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        ui_.begin(W, H);
        switch (screen_) {
            case Screen::MainMenu: drawMainMenu(); break; case Screen::WorldSelect: drawWorldSelect(); break; case Screen::CreateWorld: drawCreateWorld(); break;
            case Screen::Options: drawOptions(); break; case Screen::Loading: drawLoading(); break; default: break;
        }
        ui_.end(); return;
    }
    if (screen_ == Screen::Playing) handleGameplayInput(dt);
    if (screen_ == Screen::Playing || screen_ == Screen::Container || screen_ == Screen::Creative) {
        accumulator_ += dt; int n = 0;
        while (accumulator_ >= 0.05 && n < 5) { tickGame(); accumulator_ -= 0.05; ++n; }
        if (n == 5) accumulator_ = 0;
    }
    partial_ = (float)(accumulator_ / 0.05);
    cm_->update(floorInt(player_.pos.x) >> 4, floorInt(player_.pos.z) >> 4, set_.renderDistance, 3.0);
    wr_.update(*world_, player_.pos);
    audio_.setListener(player_.pos, player_.yaw);
    updateTargetAndBreaking();
    renderWorld(partial_);
    ui_.begin(W, H);
    drawHUD();
    switch (screen_) {
        case Screen::Pause: ui_.rect(0, 0, (float)W, (float)H, 0x00000090); drawPause(); break;
        case Screen::Options: drawOptions(); break;
        case Screen::Container: drawContainerScreen(); break;
        case Screen::Creative: drawCreativeScreen(); break;
        case Screen::Death: drawDeath(); break;
        default: break;
    }
    ui_.end();
    if (screen_ == Screen::Playing && win_.keyPressed(Key::Escape)) setScreen(Screen::Pause);
    else if (screen_ == Screen::Pause && win_.keyPressed(Key::Escape)) setScreen(Screen::Playing);
    else if (screen_ == Screen::Container && (win_.keyPressed(Key::Escape) || win_.keyPressed('E'))) closeContainer();
    else if (screen_ == Screen::Creative && (win_.keyPressed(Key::Escape) || win_.keyPressed('E'))) { creativeCursor_.clear(); setScreen(Screen::Playing); }
    else if (screen_ == Screen::Options && win_.keyPressed(Key::Escape)) { set_.save(optionsPath_); setScreen(prevScreen_ == Screen::Options ? Screen::Pause : prevScreen_); }
}

void Game::renderWorld(double partial) {
    Vec3d eye = player_.eye(partial);
    fp_.width = win_.width; fp_.height = win_.height; fp_.cam = eye; fp_.dayTicks = (double)level_.dayTime;
    fp_.underwater = player_.eyesInWater; fp_.renderDistanceBlocks = set_.renderDistance * 16.0f; fp_.occlusion = set_.occlusion; fp_.time = (float)nowSec();
    fp_.rotView = rotView();
    float aspect = (float)win_.width / std::max(1, win_.height);
    fp_.proj = glm::perspective(glm::radians(set_.fov + (player_.sprinting ? 6.0f : 0.0f)), aspect, 0.05f, std::max(300.0f, set_.renderDistance * 16.0f * 2.0f));
    wr_.render(*world_, fp_);
    if (screen_ != Screen::Death && hasHit_ && player_.mode != GameMode::Spectator) {
        float bx[6] = {0, 0, 0, 1, 1, 1}; BlockState s = world_->getBlock(hit_.pos); if (!Blocks::getBox(s, bx)) { bx[0] = bx[1] = bx[2] = 0; bx[3] = bx[4] = bx[5] = 1; }
        wr_.drawSelection(fp_, hit_.pos, bx);
        if (breaking_ && breakProgress_ > 0.0f) wr_.drawCrack(fp_, hit_.pos, std::min(9, (int)(breakProgress_ * 10.0f)));
    }
    // dropped items + particles as camera-facing quads
    std::vector<Vertex> v; double yaw = player_.yaw * 0.0174533; float rx = (float)-std::cos(yaw), rz = (float)-std::sin(yaw);
    auto quad = [&](const Vec3d& p, float half, int layer, float u0, float v0, float u1, float v1, uint8_t sky, uint8_t blk, uint8_t r, uint8_t g, uint8_t b) {
        float cx = (float)(p.x - eye.x), cy = (float)(p.y - eye.y), cz = (float)(p.z - eye.z);
        const float sx[4] = {-1, 1, 1, -1}, sy[4] = {-1, -1, 1, 1}; const float U[4] = {u0, u1, u1, u0}, V[4] = {v1, v1, v0, v0};
        for (int i = 0; i < 4; ++i) { Vertex x{}; x.x = cx + rx * sx[i] * half; x.y = cy + sy[i] * half; x.z = cz + rz * sx[i] * half; x.u = U[i]; x.v = V[i]; x.sky = sky; x.blk = blk; x.ao = 255; x.shade = 255; x.r = r; x.g = g; x.b = b; x.a = 0; x.layer = (uint16_t)layer; v.push_back(x); }
    };
    for (const ItemEntity& it : items_) {
        Vec3d p = it.pos + Vec3d(0, 0.2 + std::sin((it.age + partial) * 0.1) * 0.06, 0); uint8_t l = world_->lightRaw(floorInt(it.pos.x), floorInt(it.pos.y + 0.3), floorInt(it.pos.z));
        const ItemInfo& info = Items::get(it.st.id); int layer = info.texture;
        quad(p, 0.2f, layer, 0, 0, 1, 1, (uint8_t)((l >> 4) * 17), (uint8_t)((l & 15) * 17), 255, 255, 255);
    }
    for (const Particle& pa : particles_) { uint8_t l = world_->lightRaw(floorInt(pa.pos.x), floorInt(pa.pos.y), floorInt(pa.pos.z)); quad(pa.pos, pa.size, pa.layer, pa.u0, pa.v0, pa.u0 + 0.25f, pa.v0 + 0.25f, (uint8_t)((l >> 4) * 17), (uint8_t)((l & 15) * 17), pa.r, pa.g, pa.b); }
    wr_.drawDynamic(fp_, v, fp_.dayTicks);
}

// ====================================================================== input
void Game::handleGameplayInput(double) {
    float f = std::pow(set_.sensitivity * 0.6f + 0.2f, 3.0f) * 8.0f * 0.15f;
    if (player_.mode != GameMode::Spectator || true) { player_.yaw += (float)win_.dx * f; player_.pitch = clampv(player_.pitch + (float)win_.dy * f, -90.0f, 90.0f); }
    if (player_.yaw > 360) player_.yaw -= 360; if (player_.yaw < -360) player_.yaw += 360;
    for (int i = 0; i < 9; ++i) if (win_.keyPressed('1' + i)) player_.inv.selected = i;
    if (win_.scroll != 0) player_.inv.selected = ((player_.inv.selected - (int)(win_.scroll > 0 ? 1 : -1)) % 9 + 9) % 9;
    if (win_.keyPressed(Key::F3)) debug_ = !debug_;
    if (win_.keyPressed(Key::F11)) { set_.fullscreen = !set_.fullscreen; win_.toggleFullscreen(); }
    if (win_.keyPressed(Key::F4)) { player_.setMode((GameMode)(((int)player_.mode + 1) % 4)); level_.mode = player_.mode; }
    if (win_.keyPressed('E') && player_.mode != GameMode::Spectator) {
        if (player_.mode == GameMode::Creative) { creativeScroll_ = 0; setScreen(Screen::Creative); }
        else { menu_ = Menu::playerMenu(player_.inv); menuTitle_ = "inv.crafting"; menuPos_ = BlockPos(0, -1000, 0); layoutMenu(); setScreen(Screen::Container); }
    }
    if (win_.keyPressed('Q') && player_.mode != GameMode::Spectator) {
        ItemStack& h = player_.inv.hand();
        if (!h.empty()) { int n = win_.key(Key::LeftCtrl) ? h.count : 1; Vec3d d = player_.lookDir(); spawnItem(player_.eye() + d * 0.3, ItemStack(h.id, n, h.damage), d * 0.3 + Vec3d(0, 0.1, 0)); h.count -= n; if (h.count <= 0) h.clear(); items_.back().delay = 40; }
    }
    if (rclick_ && player_.mode != GameMode::Spectator) { tryPlaceOrUse(); placeCooldown_ = 4; }
    if (win_.mousePressed(2) && hasHit_ && player_.mode == GameMode::Creative) {
        BlockState s = world_->getBlock(hit_.pos); ItemId it = (ItemId)stateId(s); if (it) { int slot = -1; for (int i = 0; i < 9; ++i) if (player_.inv.slots[i].id == it) slot = i; if (slot < 0) { slot = player_.inv.selected; player_.inv.slots[slot] = ItemStack(it, Items::get(it).maxStack); } player_.inv.selected = slot; }
    }
}

void Game::updateTargetAndBreaking() {
    hasHit_ = false;
    if (screen_ == Screen::Death || player_.dead || player_.mode == GameMode::Spectator) return;
    Vec3d eye = player_.eye(partial_);
    hit_ = raycastBlocks(*world_, eye, player_.lookDir(), player_.reach(), false); hasHit_ = hit_.hit;
}

// ====================================================================== simulation tick (20 TPS)
void Game::tickGame() {
    PlayerInput in;
    if (screen_ == Screen::Playing && win_.cursorLocked() && !player_.dead) {
        in.forward = (win_.key('W') ? 1.f : 0.f) - (win_.key('S') ? 1.f : 0.f); in.strafe = (win_.key('A') ? 1.f : 0.f) - (win_.key('D') ? 1.f : 0.f);
        in.jump = win_.key(Key::Space); in.sneak = win_.key(Key::LeftShift); in.sprint = win_.key(Key::LeftCtrl);
    }
    bool wasGround = player_.onGround; float oldHealth = player_.health; bool inW = player_.inWater; Vec3d before = player_.pos;
    player_.tick(*world_, in);
    world_->tick(); ++level_.gameTime; level_.dayTime = (level_.dayTime + 1) % 24000;
    // footsteps / splash / landing
    if (player_.onGround && !player_.flying) {
        double d = std::hypot(player_.pos.x - before.x, player_.pos.z - before.z); stepAccum_ += (float)d;
        if (stepAccum_ > (player_.sprinting ? 2.2f : 1.85f) && d > 0.01) { stepAccum_ = 0; BlockState b = world_->getBlock(floorInt(player_.pos.x), floorInt(player_.pos.y - 0.2), floorInt(player_.pos.z)); audio_.playBlock(blockOf(b), "step", player_.pos.x, player_.pos.y, player_.pos.z, player_.sneaking ? 0.3f : 1.0f); }
    }
    if (!wasGround && player_.onGround && player_.fallDamageTaken == 0) { /* soft landing */ }
    if (player_.inWater && !inW) audio_.play("liquid.splash", player_.pos.x, player_.pos.y, player_.pos.z, 0.6f);
    if (player_.health < oldHealth) { hurtFlash_ = 10; audio_.play2D("damage.hit", 0.9f); player_.fallDamageTaken = 0; }
    if (hurtFlash_ > 0) --hurtFlash_;
    if (player_.dead && screen_ != Screen::Death) die();
    for (auto& kv : furnaces_) kv.second.tick();
    tickItems(); tickParticles();
    if (placeCooldown_ > 0) --placeCooldown_;
    // breaking progress
    bool canBreak = screen_ == Screen::Playing && win_.mouseDown(0) && hasHit_ && player_.canMineBlocks();
    if (canBreak) {
        BlockPos p = hit_.pos; BlockState s = world_->getBlock(p); const BlockInfo& b = blockOf(s); ItemStack& hand = player_.inv.hand();
        if (!breaking_ || p != breakPos_) { breaking_ = true; breakPos_ = p; breakProgress_ = 0; }
        bool creative = player_.mode == GameMode::Creative;
        bool allowed = true;
        if (player_.mode == GameMode::Adventure) { allowed = !hand.empty() && Items::get(hand.id).tool != ToolType::None && Items::get(hand.id).tool == b.tool; }
        float delta = !allowed ? 0.0f : creative ? 1.0f : Items::breakDelta(b, hand, player_.onGround, player_.eyesInWater);
        if (placeCooldown_ > 0 && creative) delta = 0;
        breakProgress_ += delta;
        if (delta > 0 && (int)(level_.gameTime % 4) == 0 && !creative) audio_.playBlock(b, "dig", p.x + 0.5, p.y + 0.5, p.z + 0.5, 0.45f);
        if (breakProgress_ >= 1.0f) { breakBlock(p); breaking_ = false; breakProgress_ = 0; placeCooldown_ = 5; }
    } else { breaking_ = false; breakProgress_ = 0; }
    // hold right mouse: repeat placing / eating
    if (screen_ == Screen::Playing && win_.mouseDown(1) && player_.mode != GameMode::Spectator) {
        ItemStack& hand = player_.inv.hand(); const ItemInfo& it = hand.empty() ? Items::get(0) : Items::get(hand.id);
        if (it.food > 0 && (player_.food < 20.0f || it.name == "golden_apple")) {
            if (++eatTicks_ % 4 == 0) audio_.play2D("random.eat", 0.5f, 0.9f + 0.2f * rng_.nextFloat());
            if (eatTicks_ >= 32) { player_.eat(it); if (player_.mode != GameMode::Creative && --hand.count <= 0) hand.clear(); eatTicks_ = 0; audio_.play2D("random.burp", 0.6f); }
        } else { eatTicks_ = 0; if (placeCooldown_ == 0 && hasHit_ && !(it.block == 0)) { tryPlaceOrUse(); placeCooldown_ = 4; } }
    } else eatTicks_ = 0;
    if (++autosaveTimer_ >= 6000) { autosaveTimer_ = 0; saveWorld(); }
    if (saveMsgTimer_ > 0) saveMsgTimer_ -= 0.05;
    if (player_.inv.selected != lastSelected_) { lastSelected_ = player_.inv.selected; const ItemStack& h = player_.inv.hand(); heldName_ = h.empty() ? "" : Items::get(h.id).name; heldNameTimer_ = 40; }
    if (heldNameTimer_ > 0) --heldNameTimer_;
}

void Game::die() {
    if (player_.mode == GameMode::Survival || player_.mode == GameMode::Adventure) {
        for (ItemStack& s : player_.inv.slots) if (!s.empty()) { spawnItem(player_.pos + Vec3d(0, 0.5, 0), s, Vec3d((rng_.nextFloat() - 0.5f) * 0.4, 0.2, (rng_.nextFloat() - 0.5f) * 0.4)); s.clear(); }
    }
    setScreen(Screen::Death);
}

// ====================================================================== blocks
static bool isContainerBlock(BlockId id) { return id == B::CRAFTING_TABLE || id == B::FURNACE || id == B::CHEST; }

void Game::spawnItem(const Vec3d& pos, const ItemStack& st, const Vec3d& vel) { ItemEntity e; e.pos = pos; e.vel = vel; e.st = st; items_.push_back(e); }

void Game::spawnDrops(const BlockPos& p, BlockState s, bool withTool) {
    const BlockInfo& b = blockOf(s); std::vector<ItemStack> drops;
    ItemStack tool = withTool ? player_.inv.hand() : ItemStack();
    if (b.id == B::CHEST) { auto it = chests_.find(p); if (it != chests_.end()) { for (auto& st : it->second) if (!st.empty()) drops.push_back(st); chests_.erase(it); } drops.emplace_back((ItemId)B::CHEST, 1); }
    else if (b.id == B::FURNACE) { auto it = furnaces_.find(p); if (it != furnaces_.end()) { for (ItemStack* st : {&it->second.input, &it->second.fuel, &it->second.output}) if (!st->empty()) drops.push_back(*st); furnaces_.erase(it); } drops.emplace_back((ItemId)B::FURNACE, 1); }
    else if (b.id == B::SNOW_LAYER) { if (Items::canHarvest(b, tool)) drops.emplace_back(Items::byName("snowball"), 1); }
    else Items::rollDrops(b, tool, rng_, drops);
    for (auto& d : drops) spawnItem(Vec3d(p.x + 0.5, p.y + 0.3, p.z + 0.5), d, Vec3d((rng_.nextFloat() - 0.5f) * 0.2, 0.15, (rng_.nextFloat() - 0.5f) * 0.2));
}

void Game::spawnBreakParticles(const BlockPos& p, BlockState s) {
    const BlockInfo& b = blockOf(s); if (b.shape == Shape::None) return;
    uint32_t tint = b.tint == Tint::Grass ? biomeInfo(Biome::Plains).grass : b.tint == Tint::Foliage ? biomeInfo(Biome::Plains).foliage : 0xFFFFFF;
    for (int i = 0; i < 14; ++i) {
        Particle pa; pa.pos = Vec3d(p.x + rng_.nextFloat(), p.y + rng_.nextFloat(), p.z + rng_.nextFloat()); pa.vel = Vec3d((rng_.nextFloat() - 0.5f) * 0.25, rng_.nextFloat() * 0.2, (rng_.nextFloat() - 0.5f) * 0.25);
        pa.life = 20 + rng_.nextInt(20); pa.size = 0.06f + 0.04f * rng_.nextFloat(); pa.layer = b.tex[rng_.nextInt(2) ? DIR_SOUTH : DIR_UP]; pa.u0 = rng_.nextInt(4) * 0.25f; pa.v0 = rng_.nextInt(4) * 0.25f;
        pa.r = (tint >> 16) & 255; pa.g = (tint >> 8) & 255; pa.b = tint & 255; particles_.push_back(pa);
    }
}

void Game::breakBlock(const BlockPos& p) {
    BlockState s = world_->getBlock(p); const BlockInfo& b = blockOf(s); if (s == 0 || b.fluid) return;
    audio_.playBlock(b, "dig", p.x + 0.5, p.y + 0.5, p.z + 0.5, 1.0f);
    spawnBreakParticles(p, s);
    bool creative = player_.mode == GameMode::Creative;
    if (!creative) {
        spawnDrops(p, s, true);
        int xp = 0; if (b.id == B::COAL_ORE || b.id == B::DEEPSLATE_COAL_ORE) xp = rng_.range(0, 2); else if (b.id == B::DIAMOND_ORE || b.id == B::DEEPSLATE_DIAMOND_ORE || b.id == B::EMERALD_ORE || b.id == B::DEEPSLATE_EMERALD_ORE) xp = rng_.range(3, 7);
        else if (b.id == B::LAPIS_ORE || b.id == B::DEEPSLATE_LAPIS_ORE || b.id == B::QUARTZ_ORE) xp = rng_.range(2, 5); else if (b.id == B::REDSTONE_ORE || b.id == B::DEEPSLATE_REDSTONE_ORE) xp = rng_.range(1, 5);
        if (xp > 0 && Items::canHarvest(b, player_.inv.hand())) player_.addXp(xp);
        if (b.hardness > 0 && !player_.inv.hand().empty()) player_.inv.damageHeldTool(1);
        player_.exhaustion += 0.005f;
    }
    world_->setBlock(p, 0, SET_ALL);
}

bool Game::canPlaceAt(const BlockPos& p, BlockState ns) const {
    if (p.y < WORLD_MIN_Y || p.y >= WORLD_MAX_Y) return false;
    const BlockInfo& b = blockOf(ns);
    if (b.solid) { AABB blk(p.x, p.y, p.z, p.x + 1, p.y + 1, p.z + 1); if (player_.mode != GameMode::Spectator && player_.box().intersects(blk)) return false; }
    if (!world_->canSurvive(p, ns)) return false;
    return true;
}

static int facingMeta(float yawDeg) {                     // front of the block faces the player
    double y = yawDeg * 0.0174533; double lx = -std::sin(y), lz = std::cos(y);
    if (std::fabs(lx) > std::fabs(lz)) return lx > 0 ? 2 /*front west*/ : 3 /*east*/; return lz > 0 ? 0 /*north*/ : 1 /*south*/;
}

void Game::tryPlaceOrUse() {
    ItemStack& hand = player_.inv.hand();
    if (hasHit_) {
        BlockState ts = world_->getBlock(hit_.pos);
        if (isContainerBlock(stateId(ts)) && (!player_.sneaking || hand.empty())) { openContainer(hit_.pos, ts); return; }
    }
    if (hand.empty()) return;
    const ItemInfo& it = Items::get(hand.id);
    if (it.name == "bucket" || it.fluidBucket) { useBucket(); return; }
    if (!hasHit_ || player_.mode == GameMode::Adventure || !it.block) return;
    BlockPos target = hit_.pos; BlockState ts = world_->getBlock(target); BlockPos place = target;
    // double slab: clicking the top of a bottom slab with the same slab
    const BlockInfo& tb = blockOf(ts);
    if (tb.shape == Shape::Box && tb.name.size() > 5 && tb.name.compare(tb.name.size() - 5, 5, "_slab") == 0 && it.block == tb.id && stateMeta(ts) == 0 && hit_.face == DIR_UP) {
        std::string full = tb.name.substr(0, tb.name.size() - 5); if (full == "oak") full = "oak_planks"; else if (full == "stone_brick") full = "stone_bricks";
        BlockId fid = Blocks::byName(full); if (fid && canPlaceAt(target, makeState(fid))) { world_->setBlock(target, makeState(fid)); audio_.playBlock(Blocks::get(fid), "dig", target.x + 0.5, target.y + 0.5, target.z + 0.5, 0.6f); if (player_.mode != GameMode::Creative && --hand.count <= 0) hand.clear(); return; }
    }
    if (!tb.replaceable && !tb.fluid) place = BlockPos(target.x + DIR_DX[hit_.face], target.y + DIR_DY[hit_.face], target.z + DIR_DZ[hit_.face]);
    BlockState cur = world_->getBlock(place); const BlockInfo& cb = blockOf(cur);
    if (!(cur == 0 || cb.replaceable || cb.fluid)) return;
    const BlockInfo& nb = Blocks::get(it.block); int meta = 0;
    if (nb.hasFacing) meta = facingMeta(player_.yaw);
    if (nb.shape == Shape::Box && nb.name.size() > 5 && nb.name.compare(nb.name.size() - 5, 5, "_slab") == 0) meta = (hit_.face == DIR_DOWN || (hit_.face != DIR_UP && hit_.point.y - place.y > 0.5)) ? 1 : 0;
    BlockState ns = makeState(it.block, meta);
    if (!canPlaceAt(place, ns)) return;
    world_->setBlock(place, ns);
    if (it.block == B::CHEST) chests_[place] = std::vector<ItemStack>(27);
    audio_.playBlock(nb, "dig", place.x + 0.5, place.y + 0.5, place.z + 0.5, 0.7f);
    if (player_.mode != GameMode::Creative && --hand.count <= 0) hand.clear();
}

void Game::useBucket() {
    ItemStack& hand = player_.inv.hand(); const ItemInfo& it = Items::get(hand.id);
    RayHit h = raycastBlocks(*world_, player_.eye(), player_.lookDir(), player_.reach(), true); if (!h.hit) return;
    BlockState s = world_->getBlock(h.pos);
    if (it.name == "bucket") {
        if (blockOf(s).fluid && stateMeta(s) == 0) {
            ItemId filled = Items::byName(stateId(s) == B::WATER ? "water_bucket" : "lava_bucket");
            world_->setBlock(h.pos, 0, SET_ALL); audio_.play("liquid.splash", h.pos.x, h.pos.y, h.pos.z, 0.5f);
            if (player_.mode != GameMode::Creative) { if (--hand.count <= 0) hand = ItemStack(filled, 1); else player_.inv.add(ItemStack(filled, 1)); }
        }
        return;
    }
    BlockPos place = h.pos; if (!blockOf(s).replaceable && !blockOf(s).fluid) place = BlockPos(h.pos.x + DIR_DX[h.face], h.pos.y + DIR_DY[h.face], h.pos.z + DIR_DZ[h.face]);
    BlockState cur = world_->getBlock(place); if (!(cur == 0 || blockOf(cur).replaceable || blockOf(cur).fluid)) return;
    world_->setBlock(place, makeState(it.fluidBucket, 0), SET_ALL);
    if (player_.mode != GameMode::Creative) hand = ItemStack(Items::byName("bucket"), 1);
}

// ====================================================================== entities
void Game::tickItems() {
    for (size_t i = 0; i < items_.size();) {
        ItemEntity& e = items_[i]; ++e.age; if (e.delay > 0) --e.delay;
        AABB box(e.pos.x - 0.125, e.pos.y, e.pos.z - 0.125, e.pos.x + 0.125, e.pos.y + 0.25, e.pos.z + 0.125);
        BlockState in = world_->getBlock(floorInt(e.pos.x), floorInt(e.pos.y + 0.1), floorInt(e.pos.z));
        if (blockOf(in).fluid) { e.vel.y += 0.02; e.vel = e.vel * 0.9; } else e.vel.y -= 0.04;
        MoveResult r = moveEntity(*world_, box, e.vel, 0, false, false);
        e.pos = Vec3d((box.x0 + box.x1) / 2, box.y0, (box.z0 + box.z1) / 2);
        if (r.hitX) e.vel.x = 0; if (r.hitZ) e.vel.z = 0; if (r.hitY) e.vel.y = 0;
        e.vel.y *= 0.98; double fr = r.onGround ? 0.6 * 0.98 : 0.98; e.vel.x *= fr; e.vel.z *= fr;
        bool remove = e.age > 6000 || e.pos.y < WORLD_MIN_Y - 32;
        if (!remove && e.delay <= 0 && !player_.dead && player_.mode != GameMode::Spectator) {
            Vec3d d = (player_.pos + Vec3d(0, 0.8, 0)) - e.pos;
            if (d.lengthSq() < 1.5 * 1.5) {
                if (d.lengthSq() < 1.0) { int left = player_.inv.add(e.st); if (left < e.st.count) { audio_.play2D("random.pop", 0.35f, 1.0f + rng_.nextFloat() * 0.5f); } e.st.count = left; if (left <= 0) remove = true; }
                else e.vel = e.vel + d * 0.04;
            }
        }
        if (remove) { items_[i] = items_.back(); items_.pop_back(); } else ++i;
    }
}

void Game::tickParticles() {
    for (size_t i = 0; i < particles_.size();) {
        Particle& p = particles_[i]; p.vel.y -= 0.04; p.pos = p.pos + p.vel; p.vel = p.vel * 0.98; p.life -= 1;
        if (blockOf(world_->getBlock(floorInt(p.pos.x), floorInt(p.pos.y), floorInt(p.pos.z))).solid) { p.vel = Vec3d(0, 0, 0); p.pos.y += 0.02; }
        if (p.life <= 0) { particles_[i] = particles_.back(); particles_.pop_back(); } else ++i;
    }
}

// ====================================================================== containers
void Game::fillLoot(std::vector<ItemStack>& slots, const BlockPos& p) {
    slots.assign(27, ItemStack());
    Rng r(featureSeed(world_->seed, p.x, p.y, p.z ^ 0x10077)); static const char* loot[] = {"bread", "iron_ingot", "gold_ingot", "coal", "bone", "string", "gunpowder", "redstone", "wheat", "apple", "bucket", "flint", "iron_pickaxe", "iron_sword", "diamond", "saddle_none", "feather", "leather", "lapis_lazuli", "stick"};
    int n = r.range(4, 8);
    for (int i = 0; i < n; ++i) { const char* name = loot[r.nextInt(20)]; ItemId id = Items::byName(name); if (!id) id = Items::byName("coal"); int cnt = (name == std::string("diamond") || name == std::string("iron_pickaxe") || name == std::string("iron_sword") || name == std::string("bucket")) ? 1 : r.range(1, 4); if (name == std::string("diamond") && r.nextInt(3)) continue; slots[r.nextInt(27)] = ItemStack(id, cnt); }
}

void Game::openContainer(const BlockPos& p, BlockState s) {
    BlockId id = stateId(s); menuPos_ = p;
    if (id == B::CRAFTING_TABLE) { menu_ = Menu::craftingTable(player_.inv); menuTitle_ = "inv.craftingTable"; }
    else if (id == B::FURNACE) { menu_ = Menu::furnace(player_.inv, furnaces_[p]); menuTitle_ = "inv.furnace"; }
    else { auto it = chests_.find(p); if (it == chests_.end()) { fillLoot(chests_[p], p); it = chests_.find(p); } menu_ = Menu::chest(player_.inv, it->second); menuTitle_ = "inv.chest"; }
    layoutMenu(); audio_.play2D("random.click", 0.6f); setScreen(Screen::Container);
}

void Game::closeContainer() { if (menu_) menu_->close(player_.inv); menu_.reset(); setScreen(Screen::Playing); }

void Game::layoutMenu() {
    slotPos_.clear(); if (!menu_) return;
    auto inv = [&](int y0) { for (int r = 0; r < 3; ++r) for (int c = 0; c < 9; ++c) slotPos_.push_back({8.0f + 18 * c, y0 + 18.0f * r}); for (int c = 0; c < 9; ++c) slotPos_.push_back({8.0f + 18 * c, (float)y0 + 58}); };
    switch (menu_->type) {
        case Menu::PlayerCrafting: menuSheetKind_ = 0; slotPos_.push_back({154, 28}); for (int i = 0; i < 4; ++i) slotPos_.push_back({98.0f + 18 * (i % 2), 18.0f + 18 * (i / 2)}); for (int i = 0; i < 4; ++i) slotPos_.push_back({8, 8.0f + 18 * i}); inv(84); slotPos_.push_back({77, 62}); break;
        case Menu::CraftingTable: menuSheetKind_ = 1; slotPos_.push_back({124, 35}); for (int i = 0; i < 9; ++i) slotPos_.push_back({30.0f + 18 * (i % 3), 17.0f + 18 * (i / 3)}); inv(84); break;
        case Menu::Furnace: menuSheetKind_ = 2; slotPos_.push_back({56, 17}); slotPos_.push_back({56, 53}); slotPos_.push_back({116, 35}); inv(84); break;
        case Menu::Chest: menuSheetKind_ = 3; for (int r = 0; r < 3; ++r) for (int c = 0; c < 9; ++c) slotPos_.push_back({8.0f + 18 * c, 18.0f + 18 * r}); inv(85); break;
    }
}

void Game::drawCursorItem(float mx, float my) {
    if (menu_ && !menu_->cursor.empty()) { ui_.itemIcon(menu_->cursor, (mx - 8) * gs_, (my - 8) * gs_, 16.0f * gs_); if (menu_->cursor.count > 1) text(std::to_string(menu_->cursor.count), mx + 8 - 6.0f * std::to_string(menu_->cursor.count).size(), my + 1, 0xFFFFFFFF); }
}

void Game::drawContainerScreen() {
    if (!menu_) return; ui_.rect(0, 0, (float)win_.width, (float)win_.height, 0x000000A0);
    float W = 176, H = menu_->type == Menu::Chest ? 168.0f : 166.0f;
    float ox = std::floor(win_.width / (2.0f * gs_) - W / 2), oy = std::floor(win_.height / (2.0f * gs_) - H / 2);
    static const char* sheets[4] = {"gui/container/inventory", "gui/container/crafting_table", "gui/container/furnace", "gui/container/generic_54"};
    int tw = 0, th = 0; GLuint sh = ui_.loadSheet(sheets[menuSheetKind_], tw, th);
    if (sh && tw > 0) {
        if (menu_->type == Menu::Chest) { ui_.sheet(sh, ox * gs_, oy * gs_, 176 * gs_, 71 * gs_, 0, 0, 176.0f / tw, 71.0f / th); ui_.sheet(sh, ox * gs_, (oy + 71) * gs_, 176 * gs_, 97 * gs_, 0, 125.0f / th * 0 + 125.0f / th, 176.0f / tw, 222.0f / th); }
        else ui_.sheet(sh, ox * gs_, oy * gs_, W * gs_, H * gs_, 0, 0, W / tw, H / th);
    } else { ui_.rect(ox * gs_, oy * gs_, W * gs_, H * gs_, 0xC6C6C6FF); for (auto& sp : slotPos_) ui_.rect((ox + sp.first - 1) * gs_, (oy + sp.second - 1) * gs_, 18 * gs_, 18 * gs_, 0x8B8B8BFF); }
    text(tr(menuTitle_), ox + 8, oy + 6, 0x404040FF, 1, false, false);
    if (menu_->type == Menu::Furnace) {                                   // flame + progress arrow
        FurnaceState& f = furnaces_[menuPos_];
        if (sh && f.burnTotal > 0 && f.burnTime > 0) { float fr = (float)f.burnTime / f.burnTotal; float hgt = 14 * fr; ui_.sheet(sh, (ox + 56) * gs_, (oy + 36 + 14 - hgt) * gs_, 14 * gs_, hgt * gs_, 176.0f / tw, (14 - hgt) / th, 190.0f / tw, 14.0f / th); }
        if (sh && f.cookTime > 0) { float w = 24.0f * f.cookTime / std::max(1, f.cookTotal); ui_.sheet(sh, (ox + 79) * gs_, (oy + 34) * gs_, w * gs_, 17 * gs_, 176.0f / tw, 14.0f / th, (176 + w) / tw, 31.0f / th); }
    }
    int hover = -1;
    for (size_t i = 0; i < menu_->slots.size() && i < slotPos_.size(); ++i) {
        float sx = ox + slotPos_[i].first, sy = oy + slotPos_[i].second; ItemStack& st = *menu_->slots[i].stack;
        bool h = mx_ >= sx && mx_ < sx + 16 && my_ >= sy && my_ < sy + 16; if (h) { hover = (int)i; ui_.rect(sx * gs_, sy * gs_, 16 * gs_, 16 * gs_, 0xFFFFFF80); }
        if (!st.empty()) {
            ui_.itemIcon(st, sx * gs_, sy * gs_, 16.0f * gs_);
            if (st.count > 1) { std::string c = std::to_string(st.count); text(c, sx + 17 - 7.0f * c.size() * 0.75f - 1, sy + 8, 0xFFFFFFFF); }
            int md = Items::get(st.id).maxDamage; if (md > 0 && st.damage > 0) { float f = 1.0f - (float)st.damage / md; ui_.rect((sx + 2) * gs_, (sy + 13) * gs_, 13 * gs_, 2 * gs_, 0x000000FF); ui_.rect((sx + 2) * gs_, (sy + 13) * gs_, 13 * f * gs_, 1 * gs_, f > 0.5f ? 0x40FF40FF : (f > 0.25f ? 0xFFFF40FF : 0xFF4040FF)); }
        }
    }
    if (hover >= 0 && (click_ || rclick_)) { menu_->click(hover, click_ ? 0 : 1, win_.key(Key::LeftShift)); audio_.play2D("random.click", 0.3f, 1.4f); }
    else if ((click_ || rclick_) && !menu_->cursor.empty() && (mx_ < ox || mx_ > ox + W || my_ < oy || my_ > oy + H)) {       // click outside: drop cursor stack
        ItemStack c = menu_->cursor; if (rclick_) c.count = 1; Vec3d d = player_.lookDir(); spawnItem(player_.eye() + d * 0.3, c, d * 0.3); items_.back().delay = 40;
        menu_->cursor.count -= c.count; if (menu_->cursor.count <= 0) menu_->cursor.clear();
    }
    if (hover >= 0 && !menu_->slots[hover].stack->empty()) { std::string n = Items::get(menu_->slots[hover].stack->id).name; for (char& c : n) if (c == '_') c = ' '; ui_.rect((mx_ + 6) * gs_, (my_ - 12) * gs_, (ui_.textWidth(n, gs_) / gs_ + 4) * gs_, 12 * gs_ * 0.8f, 0x100010F0); text(n, mx_ + 8, my_ - 11); }
    drawCursorItem(mx_, my_);
}

void Game::drawCreativeScreen() {
    ui_.rect(0, 0, (float)win_.width, (float)win_.height, 0x000000A0);
    float W = 176, H = 156; float ox = std::floor(win_.width / (2.0f * gs_) - W / 2), oy = std::floor(win_.height / (2.0f * gs_) - H / 2);
    ui_.rect(ox * gs_, oy * gs_, W * gs_, H * gs_, 0xC6C6C6FF); text(tr("inv.creative"), ox + 8, oy + 5, 0x404040FF, 1, false, false);
    int total = (int)creativeItems_.size(), rows = (total + 8) / 9; int maxScroll = std::max(0, rows - 5);
    creativeScroll_ = clampv(creativeScroll_ - (int)win_.scroll, 0, maxScroll);
    int hoverItem = -1;
    for (int r = 0; r < 5; ++r) for (int c = 0; c < 9; ++c) {
        float sx = ox + 8 + 18 * c, sy = oy + 18 + 18 * r; ui_.rect((sx - 1) * gs_, (sy - 1) * gs_, 18 * gs_, 18 * gs_, 0x8B8B8BFF);
        int idx = (creativeScroll_ + r) * 9 + c; if (idx >= total) continue;
        ItemStack st(creativeItems_[idx], 1); ui_.itemIcon(st, sx * gs_, sy * gs_, 16.0f * gs_);
        if (mx_ >= sx && mx_ < sx + 16 && my_ >= sy && my_ < sy + 16) { hoverItem = idx; ui_.rect(sx * gs_, sy * gs_, 16 * gs_, 16 * gs_, 0xFFFFFF80); }
    }
    if (hoverItem >= 0 && (click_ || rclick_)) { ItemId id = creativeItems_[hoverItem]; creativeCursor_ = ItemStack(id, click_ ? Items::get(id).maxStack : 1); }
    // scrollbar
    float sbx = ox + W - 12; ui_.rect(sbx * gs_, (oy + 18) * gs_, 6 * gs_, 90 * gs_, 0x555555FF); if (maxScroll > 0) ui_.rect(sbx * gs_, (oy + 18 + 76.0f * creativeScroll_ / maxScroll) * gs_, 6 * gs_, 14 * gs_, 0xE0E0E0FF);
    // hotbar row
    for (int i = 0; i < 9; ++i) {
        float sx = ox + 8 + 18 * i, sy = oy + 18 + 18 * 5 + 14; ItemStack& st = player_.inv.slots[i]; ui_.rect((sx - 1) * gs_, (sy - 1) * gs_, 18 * gs_, 18 * gs_, i == player_.inv.selected ? 0xFFFFFFFF : 0x8B8B8BFF); ui_.rect(sx * gs_, sy * gs_, 16 * gs_, 16 * gs_, 0x555555FF);
        if (!st.empty()) { ui_.itemIcon(st, sx * gs_, sy * gs_, 16.0f * gs_); if (st.count > 1) { std::string c = std::to_string(st.count); text(c, sx + 17 - 5.25f * c.size() - 1, sy + 8); } }
        if (mx_ >= sx && mx_ < sx + 16 && my_ >= sy && my_ < sy + 16) {
            if (click_) { if (!creativeCursor_.empty()) { st = creativeCursor_; creativeCursor_.clear(); } else { creativeCursor_ = st; st.clear(); } }
            if (rclick_) st.clear();
        }
    }
    if (!creativeCursor_.empty()) ui_.itemIcon(creativeCursor_, (mx_ - 8) * gs_, (my_ - 8) * gs_, 16.0f * gs_);
}

// ====================================================================== persistence of containers
void Game::saveContainers() {
    if (!save_) return; std::ofstream f((fs::path(save_->dir()) / "containers.dat").string(), std::ios::binary); if (!f) return;
    auto w32 = [&](int32_t v) { f.write((const char*)&v, 4); };
    auto ws = [&](const ItemStack& s) { uint16_t id = s.id; int16_t c = (int16_t)s.count, d = (int16_t)s.damage; f.write((const char*)&id, 2); f.write((const char*)&c, 2); f.write((const char*)&d, 2); };
    w32((int32_t)chests_.size()); for (auto& kv : chests_) { w32(kv.first.x); w32(kv.first.y); w32(kv.first.z); for (int i = 0; i < 27; ++i) ws(i < (int)kv.second.size() ? kv.second[i] : ItemStack()); }
    w32((int32_t)furnaces_.size()); for (auto& kv : furnaces_) { w32(kv.first.x); w32(kv.first.y); w32(kv.first.z); ws(kv.second.input); ws(kv.second.fuel); ws(kv.second.output); w32(kv.second.burnTime); w32(kv.second.burnTotal); w32(kv.second.cookTime); }
}
void Game::loadContainers() {
    if (!save_) return; std::ifstream f((fs::path(save_->dir()) / "containers.dat").string(), std::ios::binary); if (!f) return;
    auto r32 = [&]() { int32_t v = 0; f.read((char*)&v, 4); return v; };
    auto rs = [&]() { uint16_t id = 0; int16_t c = 0, d = 0; f.read((char*)&id, 2); f.read((char*)&c, 2); f.read((char*)&d, 2); return ItemStack(id, c, d); };
    int n = r32(); for (int i = 0; i < n && f; ++i) { BlockPos p(r32(), r32(), r32()); std::vector<ItemStack> v(27); for (auto& s : v) s = rs(); chests_[p] = v; }
    n = r32(); for (int i = 0; i < n && f; ++i) { BlockPos p(r32(), r32(), r32()); FurnaceState fs; fs.input = rs(); fs.fuel = rs(); fs.output = rs(); fs.burnTime = r32(); fs.burnTotal = r32(); fs.cookTime = r32(); furnaces_[p] = fs; }
}

// ====================================================================== HUD
void Game::drawHUD() {
    int W = win_.width, H = win_.height;
    if (player_.eyesInWater) ui_.rect(0, 0, (float)W, (float)H, 0x1030A050);
    if (hurtFlash_ > 0) ui_.rect(0, 0, (float)W, (float)H, 0xFF000000 | 0x00000000 | (uint32_t)(hurtFlash_ * 9));
    if (screen_ == Screen::Death) return;
    if (screen_ == Screen::Playing || screen_ == Screen::Pause || screen_ == Screen::Container || screen_ == Screen::Creative) {
        if (player_.mode != GameMode::Spectator) { drawHotbar(); drawStatusBars(); }
        float cx = W / 2.0f, cy = H / 2.0f, t = (float)gs_;
        if (screen_ == Screen::Playing) { ui_.rect(cx - 5 * t, cy - 0.5f * t, 11 * t, 1 * t, 0xFFFFFFC0); ui_.rect(cx - 0.5f * t, cy - 5 * t, 1 * t, 11 * t, 0xFFFFFFC0); }
        if (heldNameTimer_ > 0 && !heldName_.empty() && player_.mode != GameMode::Spectator) { std::string n = heldName_; for (char& c : n) if (c == '_') c = ' '; uint32_t a = (uint32_t)clampv(heldNameTimer_ * 12, 0, 255); text(n, W / (2.0f * gs_), H / (float)gs_ - 59 - (player_.mode == GameMode::Survival ? 0 : -12), 0xFFFFFF00 | a, 1, true); }
        if (saveMsgTimer_ > 0) text(tr("hud.saved"), 4, 4, 0xFFFF55FF);
        if (debug_) drawDebug();
    }
}

void Game::drawHotbar() {
    int W = win_.width, H = win_.height; float x0 = std::floor(W / 2.0f - 91.0f * gs_), y0 = (float)H - 22.0f * gs_;
    int tw = 0, th = 0; GLuint sh = ui_.loadSheet("gui/widgets", tw, th);
    if (sh && tw > 0) { ui_.sheet(sh, x0, y0, 182.0f * gs_, 22.0f * gs_, 0, 0, 182.0f / tw, 22.0f / th); ui_.sheet(sh, x0 - gs_ + player_.inv.selected * 20.0f * gs_, y0 - gs_, 24.0f * gs_, 24.0f * gs_, 0, 22.0f / th, 24.0f / tw, 46.0f / th); }
    else { ui_.rect(x0, y0, 182.0f * gs_, 22.0f * gs_, 0x000000A0); ui_.rect(x0 + player_.inv.selected * 20.0f * gs_, y0, 22.0f * gs_, 22.0f * gs_, 0xFFFFFF80); }
    for (int i = 0; i < 9; ++i) {
        const ItemStack& st = player_.inv.slots[i]; if (st.empty()) continue; float sx = x0 + (3 + 20 * i) * gs_, sy = y0 + 3.0f * gs_;
        ui_.itemIcon(st, sx, sy, 16.0f * gs_);
        if (st.count > 1) { std::string c = std::to_string(st.count); ui_.text(c, sx + 17.0f * gs_ - ui_.textWidth(c, gs_) * 0.85f, sy + 8.0f * gs_, gs_, 0xFFFFFFFF, true); }
        int md = Items::get(st.id).maxDamage; if (md > 0 && st.damage > 0) { float f = 1.0f - (float)st.damage / md; ui_.rect(sx + 2 * gs_, sy + 13 * gs_, 13.0f * gs_, 2.0f * gs_, 0x000000FF); ui_.rect(sx + 2 * gs_, sy + 13 * gs_, 13.0f * f * gs_, 1.0f * gs_, f > 0.5f ? 0x40FF40FF : (f > 0.25f ? 0xFFFF40FF : 0xFF4040FF)); }
    }
}

// pixel-art icons (own artwork): 7x7 hearts and drumsticks drawn from bitmaps
void Game::drawHeart(float x, float y, int s, int kind) {              // kind 0 empty, 1 half, 2 full
    static const char* P[7] = {".XX.XX.", "XXXXXXX", "XXXXXXX", "XXXXXXX", ".XXXXX.", "..XXX..", "...X..."};
    for (int r = 0; r < 7; ++r) for (int c = 0; c < 7; ++c) if (P[r][c] == 'X') {
        uint32_t col = kind == 2 || (kind == 1 && c < 4) ? 0xE02020FF : 0x3A1010FF; if ((kind == 2 || (kind == 1 && c < 4)) && r == 1 && c == 1) col = 0xFF8080FF;
        ui_.rect(x + c * s, y + r * s, (float)s, (float)s, col);
    }
}
void Game::drawFood(float x, float y, int s, int kind) {
    static const char* P[7] = {"...XXX.", "..XXXXX", ".XXXXXX", ".XXXXXX", "..XXXX.", ".XX.X..", "XX....."};
    for (int r = 0; r < 7; ++r) for (int c = 0; c < 7; ++c) if (P[r][c] == 'X') {
        bool full = kind == 2 || (kind == 1 && c < 4); uint32_t col = full ? (r >= 5 ? 0xE8E0C8FF : 0xC07030FF) : 0x302010FF; ui_.rect(x + c * s, y + r * s, (float)s, (float)s, col);
    }
}

void Game::drawStatusBars() {
    if (player_.mode == GameMode::Creative) return;
    int W = win_.width, H = win_.height; float x0 = std::floor(W / 2.0f - 91.0f * gs_), y0 = (float)H - 22.0f * gs_; int s = gs_; (void)s;
    float yh = y0 - 11.0f * gs_; int hp = (int)std::ceil(player_.health);
    for (int i = 0; i < 10; ++i) { int kind = hp >= (i + 1) * 2 ? 2 : (hp == i * 2 + 1 ? 1 : 0); float jit = (player_.health <= 4 && (level_.gameTime / 2 + i) % 4 == 0) ? gs_ : 0; drawHeart(x0 + i * 8.0f * gs_, yh - jit, gs_, kind); }
    int fd = (int)std::ceil(player_.food);
    for (int i = 0; i < 10; ++i) { int kind = fd >= (i + 1) * 2 ? 2 : (fd == i * 2 + 1 ? 1 : 0); drawFood(x0 + 182.0f * gs_ - (i + 1) * 8.0f * gs_ - gs_, yh, gs_, kind); }
    int ap = player_.inv.armorPoints();
    if (ap > 0) for (int i = 0; i < 10; ++i) { uint32_t c = ap >= (i + 1) * 2 ? 0xC0C8D0FF : (ap == i * 2 + 1 ? 0x80868CFF : 0x303438FF); ui_.rect(x0 + i * 8.0f * gs_, yh - 10.0f * gs_, 7.0f * gs_, 7.0f * gs_, c); ui_.rect(x0 + i * 8.0f * gs_ + gs_, yh - 10.0f * gs_ + gs_, 5.0f * gs_, 5.0f * gs_, 0x00000040); }
    if (player_.eyesInWater || player_.air < 300) { int bubbles = (int)std::ceil(std::max(0, player_.air) / 30.0); for (int i = 0; i < bubbles && i < 10; ++i) ui_.rect(x0 + 182.0f * gs_ - (i + 1) * 8.0f * gs_, yh - 10.0f * gs_, 6.0f * gs_, 6.0f * gs_, 0x70C0FFFF); }
    // experience bar + level
    float yx = y0 - 6.0f * gs_; ui_.rect(x0, yx, 182.0f * gs_, 4.0f * gs_, 0x203020FF); ui_.rect(x0, yx, 182.0f * gs_ * player_.xpProgress, 4.0f * gs_, 0x80FF20FF);
    if (player_.xpLevel > 0) { std::string l = std::to_string(player_.xpLevel); ui_.text(l, W / 2.0f - ui_.textWidth(l, gs_) / 2, yx - 9.0f * gs_, gs_, 0x80FF20FF, true); }
}

void Game::drawDebug() {
    int bx = floorInt(player_.pos.x), by = floorInt(player_.pos.y), bz = floorInt(player_.pos.z);
    Chunk* c = world_->chunk(bx >> 4, bz >> 4); Biome bio = c ? (Biome)c->biome[(bz & 15) * 16 + (bx & 15)] : Biome::Plains;
    static const char* dirs[4] = {"S (+Z)", "W (-X)", "N (-Z)", "E (+X)"}; int di = ((int)std::floor(player_.yaw / 90.0f + 0.5f) % 4 + 4) % 4;
    char buf[512]; std::snprintf(buf, sizeof buf, "Minecraft C++ (OpenGL %d.%d)  %d fps\nXYZ: %.3f / %.3f / %.3f\nBlock: %d %d %d  Chunk: %d %d\nFacing: %s  yaw %.1f pitch %.1f\n%s: %s\nLight: sky %d block %d\nChunks: %zu loaded, %d lit, drawn %d, sections %d (culled %d), quads %ld\nMesh jobs: %d  Items: %zu  Particles: %zu\nSeed: %lld  Mode: %d  Time: %llu",
        win_.glMajor, win_.glMinor, fps_, player_.pos.x, player_.pos.y, player_.pos.z, bx, by, bz, bx >> 4, bz >> 4, dirs[di], player_.yaw, player_.pitch, tr("debug.biome").c_str(), biomeInfo(bio).name,
        world_->skyLight(bx, by, bz), world_->blockLight(bx, by, bz), world_->chunks().size(), cm_->litCount(), wr_.stats.chunksDrawn, wr_.stats.sectionsDrawn, wr_.stats.sectionsCulled, wr_.stats.quads, wr_.stats.meshesPending, items_.size(), particles_.size(),
        (long long)world_->seed, (int)player_.mode, (unsigned long long)level_.dayTime);
    std::string s = buf; float y = 2; size_t p = 0;
    while (p <= s.size()) { size_t e = s.find('\n', p); if (e == std::string::npos) e = s.size(); std::string ln = s.substr(p, e - p); float w = ui_.textWidth(ln, 1) / 1.0f; ui_.rect(1, y * gs_ - 1, (w + 2) * 1.0f * gs_ * 0.75f + 2, 10.0f * gs_, 0x00000070); ui_.text(ln, 3, y * gs_, std::max(1, gs_ - 1), 0xE0E0E0FF, true); y += 10.0f * gs_ / gs_ * 1.0f; p = e + 1; }
}

} // namespace mc
