cmake_minimum_required(VERSION 3.16)
project(MinecraftCpp VERSION 0.1.0 LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
if(NOT CMAKE_BUILD_TYPE AND NOT CMAKE_CONFIGURATION_TYPES)
  set(CMAKE_BUILD_TYPE Release)
endif()
# everything (exe, tests, DLLs if any) lands in build/bin[/Release]
set(CMAKE_RUNTIME_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR}/bin)
if(MSVC)
  # static C runtime: the .exe runs on any Windows PC without the Visual C++ redistributable
  set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
endif()
option(MC_BUILD_GAME  "Build the OpenGL game (needs GLFW/GLM/stb, downloaded automatically)" ON)
option(MC_BUILD_TESTS "Build the headless test-suite and developer tools" ON)
option(MC_FETCH_OPENAL "Download OpenAL Soft when it is not installed on the system" ON)

if(MSVC)
  add_compile_options(/W3 /utf-8 /permissive- /Zc:__cplusplus)
else()
  add_compile_options(-Wall -Wextra -Wno-unused-parameter -Wno-misleading-indentation)
endif()
find_package(Threads REQUIRED)

# ------------------------------------------------------------------ simulation core (no graphics, fully testable headless)
add_library(mccore STATIC
  src/core/Noise.cpp
  src/world/Block.cpp src/world/World.cpp src/world/ChunkManager.cpp
  src/terrain/TerrainGenerator.cpp src/terrain/Decorator.cpp
  src/lighting/LightEngine.cpp
  src/fluid/FluidSimulation.cpp
  src/physics/Physics.cpp
  src/player/Player.cpp
  src/inventory/Item.cpp src/inventory/Inventory.cpp
  src/save/SaveSystem.cpp)
target_include_directories(mccore PUBLIC src)
target_link_libraries(mccore PUBLIC Threads::Threads)

# ------------------------------------------------------------------ tests + tools
if(MC_BUILD_TESTS)
  enable_testing()
  foreach(t test_core test_gameplay test_mesh test_stream)
    add_executable(${t} tests/${t}.cpp src/renderer/Mesher.cpp)
    target_link_libraries(${t} PRIVATE mccore)
    add_test(NAME ${t} COMMAND ${t})
  endforeach()
  add_executable(mapgen tools/mapgen.cpp)
  target_link_libraries(mapgen PRIVATE mccore)
endif()

# ------------------------------------------------------------------ the game
if(MC_BUILD_GAME)
  include(FetchContent)
  # Dependencies are downloaded as zip archives (no git needed). First configure needs internet access.
  if(POLICY CMP0135)
    cmake_policy(SET CMP0135 NEW)
  endif()
  FetchContent_Declare(glm  URL https://github.com/g-truc/glm/archive/refs/tags/1.0.1.zip)
  set(GLFW_BUILD_DOCS OFF CACHE BOOL "" FORCE)
  set(GLFW_BUILD_TESTS OFF CACHE BOOL "" FORCE)
  set(GLFW_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
  set(GLFW_INSTALL OFF CACHE BOOL "" FORCE)
  FetchContent_Declare(glfw URL https://github.com/glfw/glfw/archive/refs/tags/3.4.zip)
  FetchContent_Declare(stb  URL https://github.com/nothings/stb/archive/refs/heads/master.zip)
  FetchContent_MakeAvailable(glm glfw stb)

  find_package(OpenAL QUIET)
  if(NOT OpenAL_FOUND AND MC_FETCH_OPENAL)
    set(ALSOFT_UTILS OFF CACHE BOOL "" FORCE)
    set(ALSOFT_EXAMPLES OFF CACHE BOOL "" FORCE)
    set(ALSOFT_INSTALL OFF CACHE BOOL "" FORCE)
    set(ALSOFT_TESTS OFF CACHE BOOL "" FORCE)
    set(ALSOFT_BACKEND_WASAPI ON CACHE BOOL "" FORCE)
    set(LIBTYPE STATIC CACHE STRING "" FORCE)
    FetchContent_Declare(openal URL https://github.com/kcat/openal-soft/archive/refs/tags/1.23.1.zip)
    FetchContent_MakeAvailable(openal)
    set(MC_OPENAL_TARGET OpenAL)
    set(MC_OPENAL_INCLUDE ${openal_SOURCE_DIR}/include)
  elseif(OpenAL_FOUND)
    set(MC_OPENAL_TARGET OpenAL::OpenAL)
  endif()

  add_library(stb_vorbis STATIC ${stb_SOURCE_DIR}/stb_vorbis.c)
  target_compile_options(stb_vorbis PRIVATE $<$<NOT:$<C_COMPILER_ID:MSVC>>:-w>)

  add_executable(minecraft
    src/main.cpp
    src/engine/Window.cpp
    src/renderer/GL.cpp src/renderer/Shader.cpp src/renderer/TextureArray.cpp src/renderer/ImageLoader.cpp
    src/renderer/Mesher.cpp src/renderer/WorldRenderer.cpp src/renderer/UIRenderer.cpp
    src/audio/Audio.cpp
    src/game/Game.cpp src/game/Settings.cpp)
  target_include_directories(minecraft PRIVATE src ${stb_SOURCE_DIR})
  target_compile_definitions(minecraft PRIVATE GLFW_INCLUDE_NONE MC_HAVE_STB)
  target_link_libraries(minecraft PRIVATE mccore glfw glm::glm stb_vorbis)
  if(MC_OPENAL_TARGET)
    target_link_libraries(minecraft PRIVATE ${MC_OPENAL_TARGET})
    target_compile_definitions(minecraft PRIVATE MC_HAS_OPENAL AL_LIBTYPE_STATIC)
    if(MC_OPENAL_INCLUDE)
      target_include_directories(minecraft PRIVATE ${MC_OPENAL_INCLUDE})
    endif()
  else()
    message(WARNING "OpenAL not found: the game will run without sound (install libopenal-dev / openal-soft)")
  endif()
  # assets next to the executable so the game also works when started from the build directory
  add_custom_command(TARGET minecraft POST_BUILD
    COMMAND ${CMAKE_COMMAND} -E copy_directory ${CMAKE_SOURCE_DIR}/assets $<TARGET_FILE_DIR:minecraft>/assets)
endif()

# ------------------------------------------------------------------ distributable folder: cmake --install build --prefix dist
if(MC_BUILD_GAME)
  install(TARGETS minecraft RUNTIME DESTINATION .)
  install(DIRECTORY ${CMAKE_SOURCE_DIR}/assets DESTINATION .)
endif()
