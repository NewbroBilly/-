#include "../src/renderer/Mesher.h"
#include "../src/terrain/Decorator.h"
#include "../src/lighting/LightEngine.h"
#include <chrono>
#include <cstdio>
using namespace mc;
int main() {
    Blocks::init();
    uint64_t seed = 4242; TerrainGenerator tg(seed); Decorator dec(seed, tg); World w(seed);
    int ox = 100, oz = -200; const int R = 9;   // chunk (ox+4, oz+4) is the centre
    std::vector<std::shared_ptr<Chunk>> cs;
    for (int z = 0; z < R; ++z) for (int x = 0; x < R; ++x) { cs.push_back(std::make_shared<Chunk>(ox + x, oz + z)); tg.generate(*cs.back()); }
    auto at = [&](int x, int z) { return cs[z * R + x].get(); };
    for (int z = 1; z < R - 1; ++z) for (int x = 1; x < R - 1; ++x) { Chunk* nb[9]; for (int dz = -1; dz <= 1; ++dz) for (int dx = -1; dx <= 1; ++dx) nb[(dz + 1) * 3 + dx + 1] = at(x + dx, z + dz); dec.decorate(*at(x, z), nb); }
    for (int z = 1; z < R - 1; ++z) for (int x = 1; x < R - 1; ++x) w.addChunk(cs[z * R + x]);
    auto t0 = std::chrono::steady_clock::now();
    for (int z = 1; z < R - 1; ++z) for (int x = 1; x < R - 1; ++x) w.lighting().initChunk(*at(x, z));
    double lms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    printf("lighting: %.1f ms for %d chunks (%.1f ms/chunk)\n", lms, (R - 2) * (R - 2), lms / ((R - 2) * (R - 2)));
    Chunk& c = *at(4, 4);
    t0 = std::chrono::steady_clock::now();
    auto in = buildMeshInput(w, c);
    double sms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    MeshOutput out; t0 = std::chrono::steady_clock::now(); meshChunk(*in, out);
    double mms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    printf("snapshot %.2f ms, meshing %.2f ms\n", sms, mms);
    size_t total = 0; for (int p = 0; p < 3; ++p) { printf("pass %d: %zu quads\n", p, out.verts[p].size() / 4); total += out.verts[p].size() / 4; }
    int bad = 0; for (int p = 0; p < 3; ++p) for (auto& v : out.verts[p]) if (v.x < -0.01f || v.x > 16.01f || v.z < -0.01f || v.z > 16.01f || v.y < -0.01f || v.y > 384.01f) ++bad;
    printf("vertices outside chunk bounds: %d\n", bad);
    // naive face count for comparison
    long naive = 0; for (int y = 0; y < WORLD_HEIGHT; ++y) for (int z = 0; z < 16; ++z) for (int x = 0; x < 16; ++x) { BlockState s = in->at(x, y, z); if (!s || blockOf(s).shape != Shape::Cube) continue; for (int d = 0; d < 6; ++d) { BlockState n = in->at(x + DIR_DX[d], y + DIR_DY[d], z + DIR_DZ[d]); if (!blockOf(n).opaque) ++naive; } }
    printf("greedy quads (all shapes) %zu vs naive cube faces %ld\n", total, naive);
    int vis = 0; for (int s = 0; s < 24; ++s) if (out.secVis[s] != 0x7FFF) ++vis; printf("sections with restricted visibility: %d\n", vis);
    bool ok = bad == 0 && total > 500 && total < (size_t)naive + 5000;
    printf(ok ? "MESH OK\n" : "MESH PROBLEM\n"); return ok ? 0 : 1;
}
