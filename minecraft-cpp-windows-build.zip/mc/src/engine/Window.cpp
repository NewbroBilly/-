#include "Window.h"
#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>
#include <cstdio>

namespace mc {

static Window* self(GLFWwindow* w) { return static_cast<Window*>(glfwGetWindowUserPointer(w)); }

bool Window::create(int w, int h, const std::string& title) {
    if (!glfwInit()) { std::fprintf(stderr, "glfwInit failed\n"); return false; }
    // OpenGL 4.5 core first, fall back to 3.3 core (all shaders are #version 330).
    const int versions[2][2] = {{4, 5}, {3, 3}};
    for (auto& v : versions) {
        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, v[0]); glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, v[1]);
        glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE); glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GLFW_TRUE);
        win_ = glfwCreateWindow(w, h, title.c_str(), nullptr, nullptr);
        if (win_) { glMajor = v[0]; glMinor = v[1]; break; }
    }
    if (!win_) { std::fprintf(stderr, "could not create an OpenGL 3.3+ window\n"); return false; }
    glfwMakeContextCurrent(win_); glfwSetWindowUserPointer(win_, this); glfwSwapInterval(1);
    glfwSetKeyCallback(win_, onKey); glfwSetMouseButtonCallback(win_, onMouse); glfwSetCursorPosCallback(win_, onCursor);
    glfwSetScrollCallback(win_, onScroll); glfwSetCharCallback(win_, onChar); glfwSetFramebufferSizeCallback(win_, onResize);
    glfwGetFramebufferSize(win_, &width, &height); glfwGetWindowSize(win_, &ww_, &wh_);
    return true;
}
void Window::destroy() { if (win_) glfwDestroyWindow(win_); win_ = nullptr; glfwTerminate(); }
bool Window::shouldClose() const { return glfwWindowShouldClose(win_); }
void Window::requestClose() { glfwSetWindowShouldClose(win_, GLFW_TRUE); }
void Window::swap() { glfwSwapBuffers(win_); }
void Window::setVsync(bool on) { glfwSwapInterval(on ? 1 : 0); }
void* Window::procAddress(const char* n) const { return reinterpret_cast<void*>(glfwGetProcAddress(n)); }

void Window::poll() {
    for (int i = 0; i < 512; ++i) accPressed_[i] = false; for (int i = 0; i < 8; ++i) { accMouseP_[i] = accMouseR_[i] = false; }
    accDx_ = accDy_ = accScroll_ = 0; accTyped_.clear(); accKeys_.clear();
    glfwPollEvents();
    dx = accDx_; dy = accDy_; scroll = accScroll_; typed = accTyped_; keyEvents = accKeys_;
    for (int i = 0; i < 512; ++i) pressed_[i] = accPressed_[i];
    for (int i = 0; i < 8; ++i) { mousePressed_[i] = accMouseP_[i]; mouseReleased_[i] = accMouseR_[i]; }
}

void Window::setCursorLocked(bool l) {
    locked_ = l; glfwSetInputMode(win_, GLFW_CURSOR, l ? GLFW_CURSOR_DISABLED : GLFW_CURSOR_NORMAL);
    if (l && glfwRawMouseMotionSupported()) glfwSetInputMode(win_, GLFW_RAW_MOUSE_MOTION, GLFW_TRUE);
    first_ = true;
}

void Window::toggleFullscreen() {
    fullscreen_ = !fullscreen_;
    if (fullscreen_) { glfwGetWindowSize(win_, &ww_, &wh_); GLFWmonitor* m = glfwGetPrimaryMonitor(); const GLFWvidmode* vm = glfwGetVideoMode(m); glfwSetWindowMonitor(win_, m, 0, 0, vm->width, vm->height, vm->refreshRate); }
    else glfwSetWindowMonitor(win_, nullptr, 100, 100, ww_ ? ww_ : 1280, wh_ ? wh_ : 720, 0);
}

void Window::onKey(GLFWwindow* w, int key, int, int action, int) {
    Window* s = self(w); if (key < 0 || key >= 512) return;
    if (action == GLFW_PRESS) { s->keys_[key] = true; s->accPressed_[key] = true; s->accKeys_.push_back(key); }
    else if (action == GLFW_RELEASE) s->keys_[key] = false;
    else if (action == GLFW_REPEAT) s->accKeys_.push_back(key);
}
void Window::onMouse(GLFWwindow* w, int b, int action, int) {
    Window* s = self(w); if (b < 0 || b >= 8) return;
    if (action == GLFW_PRESS) { s->mouse_[b] = true; s->accMouseP_[b] = true; } else if (action == GLFW_RELEASE) { s->mouse_[b] = false; s->accMouseR_[b] = true; }
}
void Window::onCursor(GLFWwindow* w, double x, double y) {
    Window* s = self(w);
    if (s->first_) { s->lastX_ = x; s->lastY_ = y; s->first_ = false; }
    s->accDx_ += x - s->lastX_; s->accDy_ += y - s->lastY_; s->lastX_ = x; s->lastY_ = y;
    int fbw, fbh, ww, wh; glfwGetFramebufferSize(w, &fbw, &fbh); glfwGetWindowSize(w, &ww, &wh);
    double k = ww > 0 ? (double)fbw / ww : 1.0; s->mouseX = x * k; s->mouseY = y * k;
}
void Window::onScroll(GLFWwindow* w, double, double y) { self(w)->accScroll_ += y; }
void Window::onChar(GLFWwindow* w, unsigned cp) {
    std::string& t = self(w)->accTyped_;
    if (cp < 0x80) t += (char)cp;
    else if (cp < 0x800) { t += (char)(0xC0 | (cp >> 6)); t += (char)(0x80 | (cp & 0x3F)); }
    else if (cp < 0x10000) { t += (char)(0xE0 | (cp >> 12)); t += (char)(0x80 | ((cp >> 6) & 0x3F)); t += (char)(0x80 | (cp & 0x3F)); }
    else { t += (char)(0xF0 | (cp >> 18)); t += (char)(0x80 | ((cp >> 12) & 0x3F)); t += (char)(0x80 | ((cp >> 6) & 0x3F)); t += (char)(0x80 | (cp & 0x3F)); }
}
void Window::onResize(GLFWwindow* w, int fw, int fh) { Window* s = self(w); s->width = fw; s->height = fh; }

} // namespace mc
