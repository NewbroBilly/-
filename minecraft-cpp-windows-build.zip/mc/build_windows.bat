@echo off
REM One-click Windows build -> dist\Minecraft\minecraft.exe
REM Needs: Visual Studio 2022 (or Build Tools) with "Desktop development with C++", and CMake (https://cmake.org/download/). Internet is required once.
setlocal
where cmake >nul 2>nul || (echo CMake not found. Install it from https://cmake.org/download/ and tick "Add to PATH". & pause & exit /b 1)
cmake -S . -B build -A x64 || (echo Configure failed & pause & exit /b 1)
cmake --build build --config Release --parallel || (echo Build failed & pause & exit /b 1)
cmake --install build --config Release --prefix dist\Minecraft || (echo Install failed & pause & exit /b 1)
echo.
echo Done: dist\Minecraft\minecraft.exe
start "" dist\Minecraft
pause
