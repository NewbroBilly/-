#pragma once
#include "Mob.h"

namespace mc {

struct Arrow { Vec3d pos, vel, prev; int life = 0; float damage = 2; bool stuck = false; int owner = 0; };

class MobManager {
public:
    explicit MobManager(World& w) : w_(w), rng(0x5EED) {}
    std::vector<std::unique_ptr<Mob>> mobs; std::vector<Arrow> arrows;
    Rng rng; int pathBudget = 0;
    // hooks for the game layer
    std::function<void(const std::string&, const Vec3d&, float, float)> onSound;
    std::function<void(const ItemStack&, const Vec3d&)> onDrop;
    std::function<void(int)> onXp;
    std::function<void(const Vec3d&, float)> onExplosion;

    Mob* spawn(MobType t, const Vec3d& pos, float yaw = 0);
    void tick(Player& p, uint64_t dayTicks, bool spawning = true);
    bool attack(Mob& m, float damage, const Vec3d& from, bool byPlayer, float knockback = 0.4f);     // true if it died
    Mob* pick(const Vec3d& origin, const Vec3d& dir, double maxDist, double& dist);
    Mob* find(uint32_t uid);
    void explode(const Vec3d& c, float power, Player& player, bool destroyBlocks = true);
    void hurtPlayer(Player& p, float dmg, const Vec3d& from, float knock = 0.4f);
    void shootArrow(Mob& shooter, const Vec3d& target);
    int count(bool hostile) const;
    bool save(const std::string& path) const;
    bool load(const std::string& path);
    void playSound(const char* ev, const Vec3d& p, float vol = 1.0f, float pitch = 1.0f) { if (ev && *ev && onSound) onSound(ev, p, vol, pitch); }
    World& world() { return w_; }
    void clear() { mobs.clear(); arrows.clear(); }
private:
    void killMob(Mob& m);
    void trySpawn(Player& p, uint64_t dayTicks);
    void scanSpawners(const Player& p);
    void tickArrows(Player& p);
    World& w_; int spawnTimer_ = 100, scanTimer_ = 0; uint32_t nextUid_ = 1;
    struct SpawnerRec { BlockPos pos; int timer = 100; }; std::vector<SpawnerRec> spawners_;
};

float skyDarken(double dayTicks);                       // 0 day .. 11 night
bool isDaytime(double dayTicks);

} // namespace mc
