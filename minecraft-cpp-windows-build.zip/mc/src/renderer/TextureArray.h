#pragma once
#include "GL.h"
#include <string>
#include <vector>
namespace mc {
// All block + item textures as layers of one GL_TEXTURE_2D_ARRAY (no atlas bleeding, tiles can repeat for greedy quads).
class TextureArray {
public:
    bool build(const std::string& assetDir, const std::vector<std::string>& names, int tileSize = 0);
    void bind(int unit) const { glActiveTexture(GL_TEXTURE0 + unit); glBindTexture(GL_TEXTURE_2D_ARRAY, id_); }
    int layers() const { return layers_; } int tileSize() const { return tile_; } int missing() const { return missing_; }
    void destroy() { if (id_) glDeleteTextures(1, &id_); id_ = 0; }
private:
    GLuint id_ = 0; int layers_ = 0, tile_ = 16, missing_ = 0;
};
}
