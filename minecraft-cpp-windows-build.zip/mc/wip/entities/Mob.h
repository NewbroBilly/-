#pragma once
// Mobs: data, goal-based AI (like Minecraft's GoalSelector), steering along A* paths, vanilla-style physics.
#include "../ai/Pathfinder.h"
#include "../physics/Physics.h"
#include "../player/Player.h"
#include <functional>
#include <memory>
#include <string>
#include <vector>

namespace mc {

enum class MobType : uint8_t { Pig, Cow, Sheep, Chicken, Wolf, Cat, Rabbit, Zombie, Skeleton, Creeper, Spider, Enderman, Villager, IronGolem, Count };

struct MobInfo {
    const char* id; const char* ru;
    float w, h, health, speed;            // speed = vanilla movement-speed attribute
    bool hostile; float attack, follow; int xp;
    const char* say; const char* hurt; const char* death; const char* step;   // sound events (derived from assets/sounds/mob/...)
};
const MobInfo& mobInfo(MobType t);
bool mobFromName(const std::string& id, MobType& out);

class Goal;
class MobManager;
struct AiCtx { World& w; Player& player; MobManager& mm; Rng& rng; double dayTicks; };

enum GoalFlag : unsigned { GF_MOVE = 1, GF_LOOK = 2, GF_JUMP = 4, GF_TARGET = 8 };
class Goal {
public:
    int prio = 0; unsigned flags = 0; bool running = false;
    virtual ~Goal() = default;
    virtual bool canUse(struct Mob& m, AiCtx& c) = 0;
    virtual bool canContinue(struct Mob& m, AiCtx& c) { return canUse(m, c); }
    virtual void start(struct Mob&, AiCtx&) {}
    virtual void tick(struct Mob&, AiCtx&) {}
    virtual void stop(struct Mob&, AiCtx&) {}
};

struct Mob {
    uint32_t uid = 0; MobType type = MobType::Pig;
    Vec3d pos, prevPos, vel; float yaw = 0, prevYaw = 0, headYaw = 0, prevHeadYaw = 0, pitch = 0;
    float health = 10; bool onGround = false, inWater = false, inLava = false; double fallDist = 0;
    int hurtTime = 0, deathTime = -1, invul = 0, age = 0, burning = 0;
    float limbSwing = 0, limbAmount = 0, prevLimbAmount = 0, swell = 0, prevSwell = 0, attackAnim = 0;
    // navigation
    std::vector<BlockPos> path; size_t pathIdx = 0; bool navActive = false; double navSpeed = 1.0; Vec3d navGoal; int repath = 0;
    bool wantJump = false; float moveForward = 0;          // set by goals each tick
    // AI state
    int target = 0;                                        // 0 none, 1 player, otherwise uid of a mob
    int panic = 0, attackCd = 0, fuse = 0, fuseMax = 30, shootCd = 40, strafeDir = 1, strafeTimer = 0, lookTimer = 0, teleportCd = 0, talkTimer = 80, stepDist = 0, spawnerTimer = 0;
    bool angry = false, bowRaised = false, ignited = false; int hurtByPlayer = 0; Vec3d lookAt;
    std::vector<std::unique_ptr<Goal>> goals;
    const MobInfo& info() const { return mobInfo(type); }
    AABB box() const { const MobInfo& i = info(); return AABB(pos.x - i.w / 2, pos.y, pos.z - i.w / 2, pos.x + i.w / 2, pos.y + i.h, pos.z + i.w / 2); }
    Vec3d eye() const { return Vec3d(pos.x, pos.y + info().h * 0.85, pos.z); }
    bool dying() const { return deathTime >= 0; }
};

void buildGoals(Mob& m);
void runGoals(Mob& m, AiCtx& c);
void steerAndMove(Mob& m, AiCtx& c);          // follows m.path / m.moveForward and applies physics
bool mobSetPath(Mob& m, AiCtx& c, const Vec3d& goal, double speed);

} // namespace mc
