// Sandbox renderer test: creates a headless EGL (Mesa/llvmpipe) GL 3.3 context, builds a real generated world,
// renders it through WorldRenderer and writes PPM screenshots. Not part of the game build.
#include "../src/renderer/WorldRenderer.h"
#include "../src/renderer/UIRenderer.h"
#include "../src/terrain/Decorator.h"
#include "../src/lighting/LightEngine.h"
#include "../src/inventory/Item.h"
#include "../src/physics/Physics.h"
#include <dlfcn.h>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <thread>
#include <glm/gtc/matrix_transform.hpp>
using namespace mc;

typedef void* EGLDisplay; typedef void* EGLConfig; typedef void* EGLContext; typedef void* EGLSurface; typedef int EGLint; typedef unsigned EGLBoolean; typedef unsigned EGLenum;
static void writePPM(const char* path, int w, int h, const std::vector<uint8_t>& rgba) {
    FILE* f = fopen(path, "wb"); fprintf(f, "P6\n%d %d\n255\n", w, h);
    for (int y = h - 1; y >= 0; --y) for (int x = 0; x < w; ++x) fwrite(&rgba[((size_t)y * w + x) * 4], 1, 3, f);
    fclose(f);
}

int main(int argc, char** argv) {
    uint64_t seed = argc > 1 ? strtoull(argv[1], 0, 10) : 4242;
    int mode = argc > 2 ? atoi(argv[2]) : 0;            // 0 = forest, 1 = night, 2 = underwater/other
    const char* out = argc > 3 ? argv[3] : "/tmp/shot";
    void* egl = dlopen("libEGL.so.1", RTLD_NOW); if (!egl) { fprintf(stderr, "no libEGL\n"); return 2; }
    auto sym = [&](const char* n) { return dlsym(egl, n); };
    auto eglGetProcAddress = (void* (*)(const char*))sym("eglGetProcAddress");
    auto getPlat = (EGLDisplay (*)(EGLenum, void*, const EGLint*))eglGetProcAddress("eglGetPlatformDisplayEXT");
    EGLDisplay dpy = getPlat ? getPlat(0x31DD, nullptr, nullptr) : nullptr;
    if (!dpy) dpy = ((EGLDisplay (*)(void*))sym("eglGetDisplay"))(nullptr);
    EGLint maj, min; if (!((EGLBoolean (*)(EGLDisplay, EGLint*, EGLint*))sym("eglInitialize"))(dpy, &maj, &min)) { fprintf(stderr, "eglInitialize failed\n"); return 2; }
    ((EGLBoolean (*)(EGLenum))sym("eglBindAPI"))(0x30A2);
    EGLint cfgAttr[] = {0x3040, 0x0008, 0x3033, 0x0001, 0x3038}; EGLConfig cfg; EGLint n = 0;
    ((EGLBoolean (*)(EGLDisplay, const EGLint*, EGLConfig*, EGLint, EGLint*))sym("eglChooseConfig"))(dpy, cfgAttr, &cfg, 1, &n);
    EGLint ctxAttr[] = {0x3098, 3, 0x30FB, 3, 0x30FD, 1, 0x3038};
    EGLContext ctx = ((EGLContext (*)(EGLDisplay, EGLConfig, EGLContext, const EGLint*))sym("eglCreateContext"))(dpy, cfg, nullptr, ctxAttr);
    if (!ctx) { fprintf(stderr, "context creation failed (%d configs)\n", n); return 2; }
    if (!((EGLBoolean (*)(EGLDisplay, EGLSurface, EGLSurface, EGLContext))sym("eglMakeCurrent"))(dpy, nullptr, nullptr, ctx)) { fprintf(stderr, "makeCurrent failed\n"); return 2; }
    if (!gl::load([](const char* nme) -> void* { static void* e = dlopen("libEGL.so.1", RTLD_NOW); return ((void* (*)(const char*))dlsym(e, "eglGetProcAddress"))(nme); })) return 3;
    printf("GL: %s | %s\n", glGetString(GL_VERSION), glGetString(GL_RENDERER));
    const int W = 960, H = 540;
    GLuint fbo, rbc, rbd; glGenFramebuffers(1, &fbo); glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glGenRenderbuffers(1, &rbc); glBindRenderbuffer(GL_RENDERBUFFER, rbc); glRenderbufferStorage(GL_RENDERBUFFER, GL_RGBA8, W, H); glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_RENDERBUFFER, rbc);
    glGenRenderbuffers(1, &rbd); glBindRenderbuffer(GL_RENDERBUFFER, rbd); glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, W, H); glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, rbd);
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) { fprintf(stderr, "FBO incomplete\n"); return 4; }

    Blocks::init(); for (int i = 0; i < 10; ++i) Blocks::textureIndex("block/destroy_stage_" + std::to_string(i)); Items::init();
    TerrainGenerator tg(seed); Decorator dec(seed, tg); World w(seed); ThreadPool pool(1);
    // choose a land spot
    int sx = 0, sz = 0;
    for (int k = 0; k < 900; ++k) { int tx = (k % 30 - 15) * 160, tz = (k / 30 - 15) * 160; ColumnInfo c = tg.column(tx, tz);
        bool want = mode == 0 ? (c.biome == Biome::Forest || c.biome == Biome::BirchForest) : mode == 1 ? (c.biome == Biome::Taiga || c.biome == Biome::SnowyTaiga) : (c.biome == Biome::Jungle || c.biome == Biome::Savanna || c.biome == Biome::Desert);
        if (want && c.height > 66 && c.height < 85) { sx = tx; sz = tz; break; } }
    int ccx = sx >> 4, ccz = sz >> 4; const int R = 8; auto t0 = std::chrono::steady_clock::now();
    std::vector<std::shared_ptr<Chunk>> cs; auto at = [&](int x, int z) -> Chunk* { int i = (z - (ccz - R - 3)) * (2 * R + 7) + (x - (ccx - R - 3)); return cs[i].get(); };
    for (int z = ccz - R - 3; z <= ccz + R + 3; ++z) for (int x = ccx - R - 3; x <= ccx + R + 3; ++x) { cs.push_back(std::make_shared<Chunk>(x, z)); tg.generate(*cs.back()); }
    for (int z = ccz - R - 2; z <= ccz + R + 2; ++z) for (int x = ccx - R - 2; x <= ccx + R + 2; ++x) { Chunk* nb[9]; for (int dz = -1; dz <= 1; ++dz) for (int dx = -1; dx <= 1; ++dx) nb[(dz + 1) * 3 + dx + 1] = at(x + dx, z + dz); dec.decorate(*at(x, z), nb); }
    for (int z = ccz - R - 2; z <= ccz + R + 2; ++z) for (int x = ccx - R - 2; x <= ccx + R + 2; ++x) w.addChunk(cs[(z - (ccz - R - 3)) * (2 * R + 7) + (x - (ccx - R - 3))]);
    for (int z = ccz - R - 1; z <= ccz + R + 1; ++z) for (int x = ccx - R - 1; x <= ccx + R + 1; ++x) { w.lighting().initChunk(*w.chunk(x, z)); w.chunk(x, z)->status = ChunkStatus::Lit; }
    printf("world built in %.0f ms around (%d,%d)\n", std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count(), sx, sz);
    WorldRenderer wr; if (!wr.init("assets", &pool)) { fprintf(stderr, "renderer init failed\n"); return 5; }
    wr.maxJobs = 8;
    int sy = w.surfaceY(sx, sz); Vec3d cam(sx + 0.5, sy + 2.6, sz + 0.5);
    for (int i = 0; i < 600; ++i) { wr.update(w, cam); std::this_thread::sleep_for(std::chrono::milliseconds(8)); if (i > 20 && wr.stats.meshesPending == 0 && wr.stats.chunksMeshed >= (2 * R - 1) * (2 * R - 1)) break; }
    wr.update(w, cam);
    printf("meshed chunks: %d\n", wr.stats.chunksMeshed);
    FrameParams fp; fp.width = W; fp.height = H; fp.cam = cam; fp.dayTicks = mode == 1 ? 14500 : 5000; fp.renderDistanceBlocks = R * 16;
    float yaw = 40.0f * 0.0174533f, pitch = 8.0f * 0.0174533f;
    glm::vec3 dir(-std::sin(yaw) * std::cos(pitch), -std::sin(pitch), std::cos(yaw) * std::cos(pitch));
    fp.rotView = glm::lookAt(glm::vec3(0), dir, glm::vec3(0, 1, 0)); fp.proj = glm::perspective(glm::radians(70.0f), (float)W / H, 0.05f, 1000.0f);
    for (int view = 0; view < 2; ++view) {
        if (view == 1) { fp.occlusion = false; }
        auto t1 = std::chrono::steady_clock::now(); wr.render(w, fp); glFinish();
        printf("frame (occlusion=%d): %.0f ms, chunks %d, sections drawn %d, culled %d, quads %ld\n", fp.occlusion, std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t1).count(), wr.stats.chunksDrawn, wr.stats.sectionsDrawn, wr.stats.sectionsCulled, wr.stats.quads);
    }
    fp.occlusion = true; wr.render(w, fp);
    // selection + crack overlays on the block below the camera direction
    RayHit hit = raycastBlocks(w, cam, Vec3d(dir.x, dir.y, dir.z), 40);
    if (hit.hit) { float bx[6] = {0, 0, 0, 1, 1, 1}; wr.drawSelection(fp, hit.pos, bx); wr.drawCrack(fp, hit.pos, 4); printf("ray hit %d %d %d (%s)\n", hit.pos.x, hit.pos.y, hit.pos.z, blockOf(w.getBlock(hit.pos)).name.c_str()); }
    // HUD
    UIRenderer ui; if (ui.init("assets", &wr.textures())) {
        ui.begin(W, H); ui.rect(W / 2 - 1, H / 2 - 9, 2, 18, 0xFFFFFFC0); ui.rect(W / 2 - 9, H / 2 - 1, 18, 2, 0xFFFFFFC0);
        ui.text("Minecraft C++ clone  FPS 60", 8, 8, 2, 0xFFFFFFFF, true); ui.text("Привет, мир! Блоки: земля, камень", 8, 36, 2, 0xFFFFA0FF, true);
        float x0 = W / 2 - 182, y0 = H - 46; ui.rect(x0, y0, 364, 44, 0x00000088);
        BlockId ids[9] = {B::GRASS_BLOCK, B::STONE, B::OAK_PLANKS, B::GLASS, B::OAK_LOG, B::TORCH, B::SAND, B::OAK_LEAVES, B::CRAFTING_TABLE};
        for (int i = 0; i < 9; ++i) { ui.rect(x0 + 2 + i * 40, y0 + 2, 38, 40, i == 2 ? 0xFFFFFF60 : 0x00000055); ui.blockIcon(ids[i], x0 + 8 + i * 40, y0 + 8, 28); }
        ui.end();
    } else printf("UI init failed\n");
    std::vector<uint8_t> px((size_t)W * H * 4); glReadPixels(0, 0, W, H, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
    writePPM((std::string(out) + ".ppm").c_str(), W, H, px);
    printf("GL error: 0x%x\n", glGetError());
    return 0;
}
