#pragma once
// Chunk streaming pipeline: terrain (worker) -> decoration (worker) -> lighting (main) -> meshing (renderer).
#include "World.h"
#include "../engine/ThreadPool.h"
#include "../terrain/Decorator.h"
#include "../save/SaveSystem.h"
#include <deque>
#include <set>

namespace mc {

class ChunkManager {
public:
    ChunkManager(World& w, ThreadPool& pool, uint64_t seed, SaveSystem* save);
    // Stream chunks around (pcx,pcz). radius = number of chunks that must be fully lit (visible); budgetMs limits main-thread work.
    void update(int pcx, int pcz, int radius, double budgetMs);
    void saveAll();                                  // flush every modified chunk
    std::function<void(int, int)> onUnload;          // renderer hook
    size_t inFlight() const { return inflight_; }
    int litCount() const { return lit_; }
    TerrainGenerator& terrain() { return tg_; }
private:
    void drain();
    World& w_; ThreadPool& pool_; SaveSystem* save_;
    TerrainGenerator tg_; Decorator dec_;
    std::mutex m_;
    std::vector<std::shared_ptr<Chunk>> doneTerrain_; std::vector<ChunkPos> doneDecor_;
    std::set<std::pair<int, int>> requested_, decorating_;
    size_t inflight_ = 0; int lit_ = 0;
};

} // namespace mc
