// Headless test of the threaded chunk pipeline + persistence.
#include "../src/world/ChunkManager.h"
#include "../src/lighting/LightEngine.h"
#include <chrono>
#include <cstdio>
#include <filesystem>
#include <thread>
using namespace mc;
static int ok = 0, fail = 0;
#define CHECK(c, m) do { if (c) ++ok; else { ++fail; printf("  FAIL: %s (line %d)\n", m, __LINE__); } } while (0)
static bool pump(ChunkManager& cm, World& w, int cx, int cz, int radius, double maxSec) {
    auto t0 = std::chrono::steady_clock::now();
    for (;;) {
        cm.update(cx, cz, radius, 4.0);
        int need = 0, have = 0; for (int dz = -radius; dz <= radius; ++dz) for (int dx = -radius; dx <= radius; ++dx) { ++need; Chunk* c = w.chunk(cx + dx, cz + dz); if (c && c->status.load() == ChunkStatus::Lit) ++have; }
        if (have == need) return true;
        if (std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count() > maxSec) return false;
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }
}
int main() {
    Blocks::init(); Items::init();
    std::string dir = "/tmp/mc_test_world"; std::filesystem::remove_all(dir);
    uint64_t seed = 987654321;
    uint64_t hashA = 0;
    {
        ThreadPool pool(2); World w(seed); SaveSystem save(dir); ChunkManager cm(w, pool, seed, &save);
        auto t0 = std::chrono::steady_clock::now();
        bool done = pump(cm, w, 40, -30, 4, 60);
        printf("streaming radius 4 (81 chunks lit): %.2f s\n", std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count());
        CHECK(done, "all chunks around the player become Lit");
        printf("loaded chunks: %zu\n", w.chunks().size());
        Chunk* c = w.chunk(40, -30); CHECK(c && c->hasLight(), "centre chunk is lit");
        int sy = w.surfaceY(40 * 16 + 5, -30 * 16 + 5); CHECK(w.skyLight(40 * 16 + 5, sy + 1, -30 * 16 + 5) == 15, "surface is in full sky light");
        // edit blocks, they must persist
        w.setBlock(40 * 16 + 5, sy + 1, -30 * 16 + 5, makeState(B::GLOWSTONE));
        w.setBlock(40 * 16 + 6, sy + 1, -30 * 16 + 5, makeState(B::DIAMOND_BLOCK));
        CHECK(w.blockLight(40 * 16 + 4, sy + 1, -30 * 16 + 5) == 14 && w.blockLight(40 * 16 + 3, sy + 1, -30 * 16 + 5) == 13, "placed glowstone lights its surroundings");
        for (int y = -64; y < 100; y += 7) hashA ^= (uint64_t)w.getBlock(40 * 16 + 5, y, -30 * 16 + 5) * (y + 100);
        // walk away: far chunks must unload, new ones appear
        pump(cm, w, 60, -30, 3, 60);
        CHECK(w.chunk(40, -30) == nullptr, "chunks far away are unloaded");
        CHECK(save.loadChunk(40, -30, *std::make_shared<Chunk>(40, -30)), "modified chunk was written to a region file");
        LevelData ld; ld.name = "test"; ld.seed = seed; ld.gameTime = 777; ld.dayTime = 4321; ld.mode = GameMode::Creative;
        Player p; p.pos = Vec3d(1.5, 70, 2.5); p.health = 13; p.food = 11; p.inv.slots[0] = ItemStack(Items::byName("diamond_pickaxe"), 1, 17); p.inv.slots[5] = ItemStack(B::COBBLESTONE, 33); p.inv.selected = 4;
        CHECK(save.saveLevel(ld, &p), "level.dat saved");
    }
    {
        ThreadPool pool(2); World w(seed); SaveSystem save(dir); ChunkManager cm(w, pool, seed, &save);
        LevelData ld; Player p; CHECK(save.loadLevel(ld, &p), "level.dat loads");
        CHECK(ld.seed == seed && ld.gameTime == 777 && ld.dayTime == 4321 && ld.mode == GameMode::Creative && ld.name == "test", "level fields restored");
        CHECK(p.health == 13 && p.food == 11 && p.inv.selected == 4 && p.inv.slots[0].damage == 17 && p.inv.slots[5].count == 33 && std::fabs(p.pos.y - 70) < 1e-9, "player state + inventory restored");
        CHECK(pump(cm, w, 40, -30, 3, 60), "reload area");
        int sy = w.surfaceY(40 * 16 + 5, -30 * 16 + 5);
        (void)sy;
        CHECK(stateId(w.getBlock(40 * 16 + 5, -64 + 0, -30 * 16 + 5)) == B::BEDROCK, "terrain restored from the region file");
        bool foundGlow = false, foundDia = false; for (int y = -64; y < 200; ++y) { if (stateId(w.getBlock(40 * 16 + 5, y, -30 * 16 + 5)) == B::GLOWSTONE) foundGlow = true; if (stateId(w.getBlock(40 * 16 + 6, y, -30 * 16 + 5)) == B::DIAMOND_BLOCK) foundDia = true; }
        CHECK(foundGlow && foundDia, "player edits survive unload + reload");
        uint64_t h = 0; for (int y = -64; y < 100; y += 7) h ^= (uint64_t)w.getBlock(40 * 16 + 5, y, -30 * 16 + 5) * (y + 100);
        CHECK(h == hashA, "column identical after reload");
    }
    // determinism of the threaded pipeline: two independent runs must match
    uint64_t ha = 0, hb = 0;
    for (int run = 0; run < 2; ++run) {
        ThreadPool pool(run == 0 ? 1 : 3); World w(seed + 1); ChunkManager cm(w, pool, seed + 1, nullptr);
        pump(cm, w, -100, 200, 3, 60);
        uint64_t h = 1469598103934665603ULL;
        for (int dz = -2; dz <= 2; ++dz) for (int dx = -2; dx <= 2; ++dx) { Chunk* c = w.chunk(-100 + dx, 200 + dz); for (int y = -64; y < 200; ++y) for (int z = 0; z < 16; z += 3) for (int x = 0; x < 16; x += 3) h = (h ^ c->get(x, y, z)) * 1099511628211ULL; }
        (run == 0 ? ha : hb) = h;
    }
    CHECK(ha == hb, "world generation is identical with 1 or 3 worker threads (order independent)");
    printf("\n%d checks passed, %d failed\n", ok, fail); return fail ? 1 : 0;
}
