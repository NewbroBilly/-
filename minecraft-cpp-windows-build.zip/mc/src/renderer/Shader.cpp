#include "Shader.h"
#include <cstdio>
#include <vector>
namespace mc {

static GLuint build(GLenum type, const char* src, const char* name) {
    GLuint s = glCreateShader(type); glShaderSource(s, 1, &src, nullptr); glCompileShader(s);
    GLint ok = 0; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) { GLint n = 0; glGetShaderiv(s, GL_INFO_LOG_LENGTH, &n); std::vector<char> log(n > 1 ? n : 2); glGetShaderInfoLog(s, n, nullptr, log.data()); std::fprintf(stderr, "[shader %s] compile error:\n%s\n", name, log.data()); glDeleteShader(s); return 0; }
    return s;
}
bool Shader::compile(const char* vs, const char* fs, const char* name) {
    GLuint v = build(GL_VERTEX_SHADER, vs, name), f = build(GL_FRAGMENT_SHADER, fs, name); if (!v || !f) return false;
    prog_ = glCreateProgram(); glAttachShader(prog_, v); glAttachShader(prog_, f); glLinkProgram(prog_);
    glDeleteShader(v); glDeleteShader(f);
    GLint ok = 0; glGetProgramiv(prog_, GL_LINK_STATUS, &ok);
    if (!ok) { GLint n = 0; glGetProgramiv(prog_, GL_INFO_LOG_LENGTH, &n); std::vector<char> log(n > 1 ? n : 2); glGetProgramInfoLog(prog_, n, nullptr, log.data()); std::fprintf(stderr, "[shader %s] link error:\n%s\n", name, log.data()); return false; }
    return true;
}

const char* SHADER_TERRAIN_VS = R"(#version 330 core
layout(location=0) in vec3 aPos;
layout(location=1) in vec2 aUV;
layout(location=2) in vec4 aLight;
layout(location=3) in vec4 aTint;
layout(location=4) in float aLayer;
uniform mat4 uViewProj;     // projection * rotation-only view (camera-relative rendering)
uniform vec3 uOffset;       // chunk origin - camera position
out vec2 vUV; out vec4 vLight; out vec4 vTint; flat out float vLayer; out float vDist;
void main() {
    vec3 p = aPos + uOffset;
    gl_Position = uViewProj * vec4(p, 1.0);
    vUV = aUV; vLight = aLight; vTint = aTint; vLayer = aLayer; vDist = length(p);
}
)";

const char* SHADER_TERRAIN_FS = R"(#version 330 core
in vec2 vUV; in vec4 vLight; in vec4 vTint; flat in float vLayer; in float vDist;
uniform sampler2DArray uTex;
uniform float uSkyLevel;      // 0..1 daylight scaling of sky light
uniform vec3 uFogColor; uniform float uFogStart; uniform float uFogEnd;
uniform int uPass;            // 0 opaque, 1 cutout, 2 translucent
uniform float uTime;
out vec4 frag;
void main() {
    vec2 uv = vUV;
    vec4 t = texture(uTex, vec3(uv, vLayer));
    if (uPass == 1 && t.a < 0.5) discard;
    vec3 c = t.rgb;
    if (vTint.a > 0.75) c *= vTint.rgb;
    else if (vTint.a > 0.25) c *= mix(vec3(1.0), vTint.rgb, t.a);
    float alpha = (uPass == 2) ? t.a : 1.0;
    float sky = vLight.r * uSkyLevel, blk = vLight.g;
    float l = max(sky, blk);
    float lit = max(l / (4.0 - 3.0 * l), 0.06);
    c *= lit * vLight.b * vLight.a;
    float f = clamp((vDist - uFogStart) / max(uFogEnd - uFogStart, 1.0), 0.0, 1.0);
    c = mix(c, uFogColor, f);
    frag = vec4(c, alpha);
}
)";

const char* SHADER_SKY_VS = R"(#version 330 core
out vec2 vNdc;
void main() {
    vec2 p = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2);
    vNdc = p * 2.0 - 1.0;
    gl_Position = vec4(vNdc, 0.9999, 1.0);
}
)";

const char* SHADER_SKY_FS = R"(#version 330 core
in vec2 vNdc;
uniform mat4 uInvViewProj;
uniform vec3 uSunDir; uniform vec3 uTop; uniform vec3 uHorizon; uniform float uNight;
out vec4 frag;
float hash(vec3 p) { p = fract(p * 0.3183099 + vec3(0.1, 0.2, 0.3)); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
float disc(vec3 d, vec3 axis, float size) {
    vec3 up = abs(axis.y) < 0.99 ? vec3(0, 1, 0) : vec3(1, 0, 0);
    vec3 r = normalize(cross(up, axis)); vec3 u = cross(axis, r);
    float pz = dot(d, axis); if (pz <= 0.0) return 0.0;
    float m = max(abs(dot(d, r)), abs(dot(d, u))) / pz;
    return 1.0 - step(size, m);
}
void main() {
    vec4 w = uInvViewProj * vec4(vNdc, 1.0, 1.0);
    vec3 d = normalize(w.xyz / w.w);
    float h = clamp(d.y, 0.0, 1.0);
    vec3 col = mix(uHorizon, uTop, pow(h, 0.55));
    if (d.y < 0.0) col = mix(uHorizon, uHorizon * 0.8, clamp(-d.y * 4.0, 0.0, 1.0));
    // stars
    if (uNight > 0.01 && d.y > 0.0) { float s = hash(floor(d * 220.0)); col += vec3(step(0.9965, s)) * uNight * (0.6 + 0.4 * hash(floor(d * 90.0))); }
    float sun = disc(d, uSunDir, 0.075);
    float moon = disc(d, -uSunDir, 0.055);
    col = mix(col, vec3(1.0, 0.96, 0.75), sun);
    col = mix(col, vec3(0.86, 0.88, 0.95), moon);
    frag = vec4(col, 1.0);
}
)";

const char* SHADER_LINE_VS = R"(#version 330 core
layout(location=0) in vec3 aPos;
uniform mat4 uViewProj; uniform vec3 uOffset;
void main() { gl_Position = uViewProj * vec4(aPos + uOffset, 1.0); }
)";
const char* SHADER_LINE_FS = R"(#version 330 core
uniform vec4 uColor; out vec4 frag;
void main() { frag = uColor; }
)";

const char* SHADER_UI_VS = R"(#version 330 core
layout(location=0) in vec2 aPos;
layout(location=1) in vec2 aUV;
layout(location=2) in vec4 aColor;
layout(location=3) in vec2 aSel;      // x: mode (0 colour, 1 array layer, 2 sheet), y: layer
uniform vec2 uScreen;
out vec2 vUV; out vec4 vColor; flat out vec2 vSel;
void main() {
    vec2 p = vec2(aPos.x / uScreen.x * 2.0 - 1.0, 1.0 - aPos.y / uScreen.y * 2.0);
    gl_Position = vec4(p, 0.0, 1.0); vUV = aUV; vColor = aColor; vSel = aSel;
}
)";
const char* SHADER_UI_FS = R"(#version 330 core
in vec2 vUV; in vec4 vColor; flat in vec2 vSel;
uniform sampler2DArray uArr; uniform sampler2D uSheet;
out vec4 frag;
void main() {
    vec4 c = vColor;
    if (vSel.x > 2.5) { vec4 t = texture(uArr, vec3(vUV, vSel.y)); c = vec4(t.rgb * mix(vec3(1.0), vColor.rgb, t.a), vColor.a); }
    else if (vSel.x > 1.5) c *= texture(uSheet, vUV);
    else if (vSel.x > 0.5) c *= texture(uArr, vec3(vUV, vSel.y));
    if (c.a < 0.01) discard;
    frag = c;
}
)";

} // namespace mc
